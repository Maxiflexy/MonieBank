package com.digicore.omni.starter.lib.contract;

import com.digicore.omni.starter.lib.model.enumeration.ClientType;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 30 Tue Sept, 2025
 */
public interface IAuthDetailService {

  UserRoleDetails getUserPermissionCodes(String userId, String merchantId, ClientType clientType);

  UserRoleDetails getUserPermissionCodes(String userId, ClientType clientType);

  boolean isUserAndMerchantActive(String userId, String merchantId);

  default boolean isUserAndMerchantActiveWithActiveSession(
      String userId, String merchantId, String xxt) {
    return false;
  }

  default boolean isMerchantUserUsingDefaultPassword(String userId) {
    return false;
  }

  boolean isTerminalAndOutletActiveAndMerchantActive(
      String terminalId, String outletId, String merchantId);

  boolean isBackOfficeUserActive(String userId);

  default boolean isBackOfficeUserActiveWithActiveSession(String userId, String xxt) {
    return false;
  }

  default boolean isBackOfficeUserUsingDefaultPassword(String userId) {
    return false;
  }

  default boolean isTerminalAndOutletActiveAndMerchantActiveWithActiveSession(
      String terminalId, String outletId, String merchantId, String xxt) {
    return false;
  }

  default boolean isTerminalUsingDefaultPin(String terminalId) {
    return false;
  }

  default boolean isTerminalAppUpgradeRequired(String terminalId) {
    return false;
  }

  @Getter
  @Setter
  @AllArgsConstructor
  class UserRoleDetails {
    private final boolean isSuper;
    private final boolean isEnabled;
    private final Set<String> permissions;
  }
}
