package com.digicore.omni.starter.lib.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import org.apache.commons.lang3.StringUtils;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 15 Wed Oct, 2025
 */
public class MoneyFormatterUtil {

  public static String formatMoney(String amountStr) {
    try {
      if (StringUtils.isBlank(amountStr)) return amountStr;
      double amount = Double.parseDouble(amountStr);
      DecimalFormatSymbols symbols = new DecimalFormatSymbols();
      symbols.setGroupingSeparator(',');
      symbols.setDecimalSeparator('.');

      DecimalFormat formatter = new DecimalFormat("#,##0.00", symbols);
      return formatter.format(amount);
    } catch (NumberFormatException e) {
      return amountStr;
    }
  }

  public static BigDecimal toBigDecimal(String value) {
    if (value == null || value.isBlank()) return BigDecimal.ZERO;
    return new BigDecimal(value.replaceAll("[^\\d.\\-]", "")); // removes commas, ₦, etc.
  }
}
