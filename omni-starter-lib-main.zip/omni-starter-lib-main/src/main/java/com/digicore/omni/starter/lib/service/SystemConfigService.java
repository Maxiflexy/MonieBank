package com.digicore.omni.starter.lib.service;

import static com.digicore.omni.starter.lib.constant.SystemConfigKeyConstant.*;

import com.digicore.omni.starter.lib.encryption.PluggableEncryptionService;
import com.digicore.omni.starter.lib.mapper.SystemConfigMapper;
import com.digicore.omni.starter.lib.model.entity.SystemConfig;
import com.digicore.omni.starter.lib.repository.SystemConfigRepository;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 20 Sun Apr, 2025
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class SystemConfigService {

  public static final String OMNICODE = "OMNICODE";
  private final PluggableEncryptionService pluggableEncryptionService;

  private final SystemConfigMapper systemConfigMapper;
  private final SystemConfigRepository systemConfigRepository;

  public Map<String, String> initializeAndLoadConfigs() {
    List<SystemConfig> defaultConfigs = buildDefaultConfigs();

    // Fetch all configs from DB (blocking)
    List<SystemConfig> existingConfigs = systemConfigRepository.findAll();

    Map<String, SystemConfig> existingConfigMap =
        existingConfigs.stream()
            .collect(Collectors.toMap(SystemConfig::getConfigKey, Function.identity()));

    List<SystemConfig> updatedConfigs = mergeConfigs(defaultConfigs, existingConfigMap);

    // Save updated configs (blocking)
    systemConfigRepository.saveAll(updatedConfigs);

    // Load final map from DB (blocking)
    return loadConfigFromDatabase();
  }

  private List<SystemConfig> mergeConfigs(
      List<SystemConfig> defaultConfigs, Map<String, SystemConfig> existingConfigMap) {
    List<SystemConfig> updatedConfigs = new ArrayList<>();

    for (SystemConfig newConfig : defaultConfigs) {
      SystemConfig existingConfig = existingConfigMap.get(newConfig.getConfigKey());

      if (existingConfig != null) {
        //        if (!newConfig.getConfigKey().equals("xtbank.token.secret-key")
        //            && !newConfig.getConfigKey().equals("xtbank.token.public-key")) {
        //          existingConfig.setConfigValue(newConfig.getConfigValue());
        //          existingConfig.setDescription(newConfig.getDescription());
        //          existingConfig.setHidden(newConfig.getHidden());
        //          updatedConfigs.add(existingConfig);
        //        }

        if (newConfig.getConfigKey().equals(OMNI_ENCRYPTION_PUBLIC_KEY)
            || newConfig.getConfigKey().equals(OMNI_ENCRYPTION_PRIVATE_KEY)
            || newConfig.getConfigKey().equals(OMNI_ENCRYPTION_DELIMITER)) {
          existingConfig.setConfigValue(newConfig.getConfigValue());
          existingConfig.setDescription(newConfig.getDescription());
          existingConfig.setHidden(newConfig.getHidden());
          updatedConfigs.add(existingConfig);
        }
      } else {
        // New config, just add
        updatedConfigs.add(newConfig);
      }
    }

    return updatedConfigs;
  }

  public Map<String, String> loadConfigFromDatabase() {
    List<SystemConfig> configs = systemConfigRepository.findAll();

    if (configs.isEmpty()) {
      return new HashMap<>();
    }

    Map<String, String> result = new HashMap<>();

    for (SystemConfig config : configs) {
      // decryptIfNeeded returns Mono<String>, so block to get value synchronously
      String decryptedValue = decryptIfNeeded(config).block();
      result.put(config.getConfigKey(), decryptedValue);
    }

    return result;
  }

  private Mono<String> decryptIfNeeded(SystemConfig config) {
    try {
      if (!StringUtils.isBlank(config.getHidden())) {
        return Mono.fromCallable(
                () ->
                    pluggableEncryptionService
                        .getEngine("AES")
                        .decrypt(config.getConfigValue(), config.getHidden()))
            .subscribeOn(Schedulers.boundedElastic())
            .onErrorReturn(config.getConfigValue());
      } else {
        return Mono.just(config.getConfigValue());
      }
    } catch (Exception e) {
      return Mono.just(config.getConfigValue());
    }
  }

  private List<SystemConfig> buildDefaultConfigs() {
    try {
      Pair omniEncryptionPair = pluggableEncryptionService.getEngine("RSA").generateKey();
      Pair omniTokenPair = pluggableEncryptionService.getEngine("RSA").generateKey();
      String hidden = pluggableEncryptionService.getEngine("AES").generateKey().getKey();
      String deli = pluggableEncryptionService.getEngine("AES").encrypt(OMNICODE, hidden);

      List<SystemConfig> configs = new ArrayList<>();

      configs.add(
          systemConfigMapper.toConfig(
              pluggableEncryptionService.getEngine("AES"),
              OMNI_ENCRYPTION_PUBLIC_KEY,
              omniEncryptionPair.getLeft().toString(),
              "",
              true,
              true,
              false));
      configs.add(
          systemConfigMapper.toConfig(
              pluggableEncryptionService.getEngine("AES"),
              OMNI_ENCRYPTION_PRIVATE_KEY,
              omniEncryptionPair.getRight().toString(),
              "",
              true,
              true,
              false));
      configs.add(
          systemConfigMapper.toConfig(
              pluggableEncryptionService.getEngine("AES"),
              OMNI_TOKEN_PUBLIC_KEY,
              omniTokenPair.getLeft().toString(),
              "",
              true,
              false,
              false));
      configs.add(
          systemConfigMapper.toConfig(
              pluggableEncryptionService.getEngine("AES"),
              OMNI_TOKEN_SECRET_KEY,
              omniTokenPair.getRight().toString(),
              "",
              true,
              false,
              false));

      configs.add(
          systemConfigMapper.toConfig(
              pluggableEncryptionService.getEngine("AES"),
              OMNI_ENCRYPTION_EXCLUDED_PATHS,
              "/api/v1/decrypt,/api/v1/encrypt,/api/v1/actuator/health,/health,/h2-console/,/api/v1/rotate-sra,/api/v1/current-timestamp",
              "",
              false,
              true,
              false));
      configs.add(
          systemConfigMapper.toConfig(
              pluggableEncryptionService.getEngine("AES"),
              OAUTH_RESOURCE_SERVER_RESOURCE_ID,
              "omni-service",
              "",
              false,
              true,
              false));
      configs.add(
          systemConfigMapper.toConfig(
              pluggableEncryptionService.getEngine("AES"),
              OAUTH_RESOURCE_SERVER_RESOURCE_IDS,
              "omni-service,omni-merchant-service,omni-backoffice-service,omni-terminal-service",
              "",
              false,
              true,
              false));
      configs.add(
          systemConfigMapper.toConfig(
              pluggableEncryptionService.getEngine("AES"),
              OMNI_ENCRYPTION_DELIMITER,
              OMNICODE,
              "",
              true,
              true,
              false));

      return configs;

    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }
}
