package com.digicore.omni.starter.lib.encryption;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 17 Thu Apr, 2025
 */
@Component
public class AESEncryptionEngine implements EncryptionEngine {

  private static final String ALGORITHM = "AES";
  private static final String TRANSFORMATION = "AES/CBC/PKCS5PADDING";

  @Override
  public String algorithmName() {
    return ALGORITHM;
  }

  public String encrypt(String data, String base64SecretKey) throws Exception {
    byte[] keyBytes = Base64.getDecoder().decode(base64SecretKey);
    SecretKeySpec keySpec = new SecretKeySpec(keyBytes, ALGORITHM);

    byte[] iv = new byte[16];
    new SecureRandom().nextBytes(iv);
    IvParameterSpec ivSpec = new IvParameterSpec(iv);

    Cipher cipher = Cipher.getInstance(TRANSFORMATION);
    cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
    byte[] encrypted = cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));

    // prepend IV to ciphertext
    byte[] combined = new byte[iv.length + encrypted.length];
    System.arraycopy(iv, 0, combined, 0, iv.length);
    System.arraycopy(encrypted, 0, combined, iv.length, encrypted.length);

    return Base64.getEncoder().encodeToString(combined);
  }

  public String decrypt(String encryptedData, String base64SecretKey) throws Exception {
    byte[] decoded = Base64.getDecoder().decode(encryptedData);
    byte[] iv = new byte[16];
    byte[] cipherBytes = new byte[decoded.length - 16];

    System.arraycopy(decoded, 0, iv, 0, 16);
    System.arraycopy(decoded, 16, cipherBytes, 0, cipherBytes.length);

    byte[] keyBytes = Base64.getDecoder().decode(base64SecretKey);
    SecretKeySpec keySpec = new SecretKeySpec(keyBytes, ALGORITHM);
    IvParameterSpec ivSpec = new IvParameterSpec(iv);

    Cipher cipher = Cipher.getInstance(TRANSFORMATION);
    cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
    byte[] decrypted = cipher.doFinal(cipherBytes);

    return new String(decrypted, StandardCharsets.UTF_8);
  }

  public Pair<String, String> generateKey() throws Exception {
    KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);
    keyGenerator.init(256); // AES-256
    SecretKey secretKey = keyGenerator.generateKey();
    return new ImmutablePair<>(Base64.getEncoder().encodeToString(secretKey.getEncoded()), "");
  }
}
