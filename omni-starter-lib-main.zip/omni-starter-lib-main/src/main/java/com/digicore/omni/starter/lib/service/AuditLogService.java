package com.digicore.omni.starter.lib.service;

import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.digicore.omni.starter.lib.mapper.AuditLogMapper;
import com.digicore.omni.starter.lib.model.response.AuditLogResponse;
import com.digicore.omni.starter.lib.repository.AuditLogRepository;
import java.time.OffsetDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 18 Sat Oct, 2025
 */
@Service
@RequiredArgsConstructor
public class AuditLogService {

  private final AuditLogRepository auditLogRepository;
  private final AuditLogMapper auditLogMapper;

  public Page<AuditLogResponse> fetchPagedAuditLogs(
      String searchTerm,
      List<String> actors,
      String action,
      OffsetDateTime startDate,
      OffsetDateTime endDate,
      Pageable pageable) {
    return auditLogRepository
        .searchPagedAuditLogs(
            normalize(searchTerm), actors, normalize(action), startDate, endDate, pageable)
        .map(auditLogMapper::toAuditLogResponse);
  }

  public AuditLogResponse getAuditLogById(String id) {
    return auditLogMapper.toAuditLogResponse(
        auditLogRepository
            .findProjectedById(id)
            .orElseThrow(
                () ->
                    CommonExceptionOf.Business.NotFound.NOT_FOUND.exception(
                        "Audit log not found with the provided id")));
  }

  private String normalize(String input) {
    return (input == null || input.trim().isEmpty()) ? null : input.trim();
  }
}
