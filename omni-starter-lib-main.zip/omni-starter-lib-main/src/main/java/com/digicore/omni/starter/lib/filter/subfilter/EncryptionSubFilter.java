package com.digicore.omni.starter.lib.filter.subfilter;

import com.digicore.omni.starter.lib.constant.AppConstants;
import com.digicore.omni.starter.lib.filter.SubWebFilter;
import com.digicore.omni.starter.lib.helper.HttpCachingHelper;
import com.digicore.omni.starter.lib.helper.RequestResponseEncryptionHelper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.util.ContentCachingResponseWrapper;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 10 Wed Sept, 2025
 */
@Slf4j
@Component
@Order(6)
@RequiredArgsConstructor
public class EncryptionSubFilter implements SubWebFilter {

  private final RequestResponseEncryptionHelper requestResponseEncryptionHelper;
  private final HttpCachingHelper httpCachingHelper;

  @Override
  public void filter(
      ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
      throws ServletException, IOException {

    HttpServletRequest request = (HttpServletRequest) servletRequest;
    HttpServletResponse response = (HttpServletResponse) servletResponse;

    String path = request.getRequestURI();

    String isService = Optional.ofNullable((String) request.getAttribute("isService")).orElse("");

    if (requestResponseEncryptionHelper.isExcludedEncryptionResponse(path)) {
      response.setHeader("encrypt", "yes");
      filterChain.doFilter(request, response);
      return;
    }

    ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);

    try {
      filterChain.doFilter(request, responseWrapper);

      byte[] responseBody = responseWrapper.getContentAsByteArray();

      if (responseBody.length == 0) {
        responseWrapper.copyBodyToResponse();
        return;
      }

      String originalResponse = new String(responseBody, StandardCharsets.UTF_8);

      request.setAttribute(AppConstants.DECRYPTED_RESPONSE_BODY, originalResponse);

      httpCachingHelper.applyCaching(request, response);

      // If caching returned a 304 Not Modified, STOP
      if (response.getStatus() == HttpServletResponse.SC_NOT_MODIFIED) {
        return;
      }
      response.setContentType("application/json");
      response.setCharacterEncoding("UTF-8");

      if (isService.equalsIgnoreCase("yeah")) {

        response.setContentLength(originalResponse.getBytes(StandardCharsets.UTF_8).length);

        response.getOutputStream().write(originalResponse.getBytes(StandardCharsets.UTF_8));
        response.flushBuffer();

        return;
      }

      String encryptedJson =
          requestResponseEncryptionHelper.prepareEncryptedResponse(originalResponse);

      response.setContentLength(encryptedJson.getBytes(StandardCharsets.UTF_8).length);

      response.getOutputStream().write(encryptedJson.getBytes(StandardCharsets.UTF_8));
      response.flushBuffer();

    } catch (Exception _) {
      try {
        response.resetBuffer();
        requestResponseEncryptionHelper.writeEncryptedErrorResponse(
            response, "Failed to encrypt response");
      } catch (Exception errorException) {
        log.error("Failed to write error response", errorException);
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
      }
    }
  }
}
