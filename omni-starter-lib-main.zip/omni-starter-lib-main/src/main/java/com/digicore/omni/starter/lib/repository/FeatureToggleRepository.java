package com.digicore.omni.starter.lib.repository;

import com.digicore.omni.starter.lib.model.entity.FeatureToggle;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 31 Sun Aug, 2025
 */
@Repository
public interface FeatureToggleRepository extends JpaRepository<FeatureToggle, String> {
  Optional<FeatureToggle> findByName(String name);
}
