package com.digicore.omni.starter.lib.annotation;

import com.digicore.omni.starter.lib.model.enumeration.ClientType;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 02 Thu Jan, 2025
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ClientTypeFilter {

  ClientType[] value();
}
