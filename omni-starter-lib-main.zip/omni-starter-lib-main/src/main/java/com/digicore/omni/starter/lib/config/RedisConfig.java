package com.digicore.omni.starter.lib.config;

import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import java.time.Duration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 01 Wed Oct, 2025
 */
@Configuration
@EnableCaching
public class RedisConfig implements CachingConfigurer {

  @Value("${omni.service.code}-")
  private String keyPrefix;

  @Bean
  @Primary
  public CacheManager cacheManager(
      RedisConnectionFactory redisConnectionFactory,
      CircuitBreakerRegistry circuitBreakerRegistry) {
    RedisCacheConfiguration config =
        RedisCacheConfiguration.defaultCacheConfig()
            .entryTtl(Duration.ofDays(1))
            .prefixCacheNameWith(keyPrefix)
            .serializeKeysWith(
                RedisSerializationContext.SerializationPair.fromSerializer(
                    new StringRedisSerializer()))
            .serializeValuesWith(
                RedisSerializationContext.SerializationPair.fromSerializer(RedisSerializer.json()));

    var cacheManager =
        RedisCacheManager.builder(redisConnectionFactory).cacheDefaults(config).build();
    var circuitBreaker = circuitBreakerRegistry.circuitBreaker("redis");

    return new ResilientRedisCacheManager(cacheManager, circuitBreaker);
  }

  @Bean("aWeekCacheManager")
  public CacheManager aWeekCacheManager(
      RedisConnectionFactory redisConnectionFactory,
      CircuitBreakerRegistry circuitBreakerRegistry) {
    RedisCacheConfiguration config =
        RedisCacheConfiguration.defaultCacheConfig()
            .entryTtl(Duration.ofDays(7))
            .prefixCacheNameWith(keyPrefix)
            .serializeKeysWith(
                RedisSerializationContext.SerializationPair.fromSerializer(
                    new StringRedisSerializer()))
            .serializeValuesWith(
                RedisSerializationContext.SerializationPair.fromSerializer(RedisSerializer.json()));

    var cacheManager =
        RedisCacheManager.builder(redisConnectionFactory).cacheDefaults(config).build();
    var circuitBreaker = circuitBreakerRegistry.circuitBreaker("redis");

    return new ResilientRedisCacheManager(cacheManager, circuitBreaker);
  }

  @Bean("redisTemplateObject")
  public RedisTemplate<String, Object> redisTemplateObject(RedisConnectionFactory cf) {
    RedisTemplate<String, Object> tpl = new RedisTemplate<>();
    tpl.setConnectionFactory(cf);

    var keySer = new PrefixStringRedisSerializer(keyPrefix);
    tpl.setKeySerializer(keySer);
    tpl.setHashKeySerializer(keySer);

    tpl.afterPropertiesSet();
    return tpl;
  }

  @Bean
  @Primary
  public RedisTemplate<String, String> redisTemplateString(RedisConnectionFactory cf) {
    RedisTemplate<String, String> tpl = new RedisTemplate<>();
    tpl.setConnectionFactory(cf);

    var keySer = new PrefixStringRedisSerializer(keyPrefix);
    tpl.setKeySerializer(keySer);
    tpl.setHashKeySerializer(keySer);

    tpl.afterPropertiesSet();
    return tpl;
  }

  class PrefixStringRedisSerializer implements RedisSerializer<String> {
    private final String prefix;
    private final StringRedisSerializer delegate = new StringRedisSerializer();

    public PrefixStringRedisSerializer(String prefix) {
      // normalize to "INT-"
      this.prefix = prefix.endsWith("-") ? prefix : prefix + "-";
    }

    @Override
    public byte[] serialize(String key) {
      if (key == null) return null;
      return delegate.serialize(prefix + key); // <-- only place we add the prefix
    }

    @Override
    public String deserialize(byte[] bytes) {
      // Not really used for keys by RedisTemplate; keep pass-through
      return delegate.deserialize(bytes);
    }
  }
}
