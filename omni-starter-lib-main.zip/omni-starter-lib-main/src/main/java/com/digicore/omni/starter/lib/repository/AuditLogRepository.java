package com.digicore.omni.starter.lib.repository;

import com.digicore.omni.starter.lib.datasource.DataSourceType;
import com.digicore.omni.starter.lib.datasource.UseDataSource;
import com.digicore.omni.starter.lib.model.entity.AuditLog;
import com.digicore.omni.starter.lib.projection.AuditLogProjection;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 19 Sat Apr, 2025
 */
@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, String> {

  @UseDataSource(DataSourceType.READ_REPLICA)
  @Query(
      value =
          """
        SELECT
            a.id AS id,
            a.request_id AS requestId,
            a.action AS action,
            a.actor AS actor,
            a.request_method AS requestMethod,
            a.request_path AS requestPath,
            a.success AS success,
            a.client_ip AS clientIp,
            a.user_agent AS userAgent,
            a.latency_category AS latencyCategory,
            a.duration AS duration,
            a.created_at AS createdAt
        FROM audit_log a
        WHERE (
                (:actors IS NULL OR :actors = '' OR a.actor IN (:actors) OR a.actor_id IN (:actors))
            )
          AND (
                :action IS NULL OR LOWER(a.action) LIKE LOWER(CONCAT('%', :action, '%'))
            )
          AND (
                :searchTerm IS NULL OR (
                    LOWER(a.action) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR
                    LOWER(a.actor) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR
                    LOWER(a.actor_id) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR
                    LOWER(a.request_path) LIKE LOWER(CONCAT('%', :searchTerm, '%'))
                )
            )
          AND (:startDate IS NULL OR a.created_at >= :startDate)
          AND (:endDate IS NULL OR a.created_at <= :endDate)
        ORDER BY a.created_at DESC
        """,
      countQuery =
          """
        SELECT COUNT(a.id)
        FROM audit_log a
        WHERE (
                (:actors IS NULL OR :actors = '' OR a.actor IN (:actors) OR a.actor_id IN (:actors))
            )
          AND (
                :action IS NULL OR LOWER(a.action) LIKE LOWER(CONCAT('%', :action, '%'))
            )
          AND (
                :searchTerm IS NULL OR (
                    LOWER(a.action) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR
                    LOWER(a.actor) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR
                    LOWER(a.actor_id) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR
                    LOWER(a.request_path) LIKE LOWER(CONCAT('%', :searchTerm, '%'))
                )
            )
          AND (:startDate IS NULL OR a.created_at >= :startDate)
          AND (:endDate IS NULL OR a.created_at <= :endDate)
        """,
      nativeQuery = true)
  Page<AuditLogProjection> searchPagedAuditLogs(
      @Param("searchTerm") String searchTerm,
      @Param("actors") List<String> actors,
      @Param("action") String action,
      @Param("startDate") OffsetDateTime startDate,
      @Param("endDate") OffsetDateTime endDate,
      Pageable pageable);

  @Query(value = "SELECT * FROM audit_log a WHERE a.id = :id", nativeQuery = true)
  Optional<AuditLogProjection> findProjectedById(@Param("id") String id);
}
