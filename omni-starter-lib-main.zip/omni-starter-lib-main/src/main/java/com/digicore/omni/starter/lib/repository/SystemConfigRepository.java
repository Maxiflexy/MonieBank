package com.digicore.omni.starter.lib.repository;

import com.digicore.omni.starter.lib.model.entity.SystemConfig;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 19 Sat Apr, 2025
 */
@Repository
public interface SystemConfigRepository extends JpaRepository<SystemConfig, String> {

  Optional<SystemConfig> findByConfigKey(String configKey);

  List<SystemConfig> findByConfigKeyIn(List<String> configKeys);

  boolean existsByConfigKey(String configKey);

  boolean existsByConfigKeyAndIdNot(String configKey, String id);
}
