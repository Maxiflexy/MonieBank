package com.digicore.omni.starter.lib.encryption;

import com.digicore.omni.starter.lib.model.dto.EncryptedPayloadDTO;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 18 Fri Apr, 2025
 */
@Component
@RequiredArgsConstructor
public class HybridEncryptionService {

  private final PluggableEncryptionService encryptionService;

  public String decryptRequest(EncryptedPayloadDTO encryptedRequest, String privateKey)
      throws Exception {
    String decryptedSecretKey =
        encryptionService.getEngine("RSA").decrypt(encryptedRequest.getKey(), privateKey);
    return encryptionService
        .getEngine("AES")
        .decrypt(encryptedRequest.getBody(), decryptedSecretKey);
  }

  public EncryptedPayloadDTO encryptResponse(String responseBody, String publicKey)
      throws Exception {
    Pair<String, String> aesKeyPair = encryptionService.getEngine("AES").generateKey();
    String aesKey = aesKeyPair.getLeft();

    String encryptedBody = encryptionService.getEngine("AES").encrypt(responseBody, aesKey);

    String encryptedKey = encryptionService.getEngine("RSA").encrypt(aesKey, publicKey);

    return EncryptedPayloadDTO.builder().key(encryptedKey).body(encryptedBody).build();
  }
}
