package com.digicore.omni.starter.lib.model.response;

import java.time.OffsetDateTime;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 15 Tue Apr, 2025
 */
@Getter
@Setter
@Builder
public class HealthStatusResponse {

  private OffsetDateTime datetime;
  private OffsetDateTime startDate;
  private String upDuration;
  private String timezone;
  private String status;
  private String db;
  private String profile;
  private String redis;
}
