package com.digicore.omni.starter.lib.util;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 13 Mon Oct, 2025
 */
@Slf4j
@UtilityClass
public class FileUtil {

  private static final String VIDEO_MP4_VALUE = "video/mp4";
  private static final String APK_FILE_VALUE = "application/vnd.android.package-archive";

  int minFileUploadSize = 1000;
  int maxFileUploadSize = 209715200; // 200MB

  public boolean fileTypeForDocumentIsNotValid(MultipartFile file) {
    return !MediaType.TEXT_PLAIN_VALUE.equalsIgnoreCase(file.getContentType())
        && !MediaType.APPLICATION_PDF_VALUE.equalsIgnoreCase(file.getContentType())
        && !MediaType.IMAGE_JPEG_VALUE.equalsIgnoreCase(file.getContentType())
        && !MediaType.IMAGE_PNG_VALUE.equalsIgnoreCase(file.getContentType())
        && !MediaType.APPLICATION_OCTET_STREAM_VALUE.equalsIgnoreCase(file.getContentType())
        && !APK_FILE_VALUE.equalsIgnoreCase(file.getContentType());
  }

  public boolean fileTypeForMultiMediaIsNotValid(MultipartFile file) {
    return !VIDEO_MP4_VALUE.equalsIgnoreCase(file.getContentType())
        && !APK_FILE_VALUE.equalsIgnoreCase(file.getContentType());
  }

  public static String getMediaType(String fileExtension) {
    return switch (fileExtension) {
      case "txt" -> MediaType.TEXT_PLAIN_VALUE;
      case "jpeg" -> MediaType.IMAGE_JPEG_VALUE;
      case "pdf" -> MediaType.APPLICATION_PDF_VALUE;
      case "apk" -> APK_FILE_VALUE;
      default -> MediaType.APPLICATION_OCTET_STREAM_VALUE;
    };
  }

  public boolean fileSizeIsNotValid(MultipartFile file) {
    log.info("File size: {}", file.getSize());
    log.info("File size: {}", minFileUploadSize);
    log.info("File size: {}", maxFileUploadSize);
    return file.getSize() < minFileUploadSize || file.getSize() > maxFileUploadSize;
  }
}
