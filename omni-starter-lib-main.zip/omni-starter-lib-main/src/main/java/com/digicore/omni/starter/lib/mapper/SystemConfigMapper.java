package com.digicore.omni.starter.lib.mapper;

import com.digicore.omni.starter.lib.encryption.EncryptionEngine;
import com.digicore.omni.starter.lib.model.entity.SystemConfig;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 20 Sun Apr, 2025
 */
@Component
@RequiredArgsConstructor
public class SystemConfigMapper {

  public SystemConfig toConfig(
      EncryptionEngine encryptionEngine,
      String key,
      String value,
      String description,
      boolean encode,
      boolean canBeUpdated,
      boolean canBeDeleted) {
    SystemConfig systemConfig = new SystemConfig();
    systemConfig.setConfigKey(key);
    systemConfig.setConfigValue(value);
    systemConfig.setCanBeUpdated(canBeUpdated);
    systemConfig.setCanBeDeleted(canBeDeleted);
    systemConfig.setDescription(description);
    if (encode) {
      String hidden = null;
      try {
        hidden = encryptionEngine.generateKey().getKey();

        systemConfig.setConfigValue(encryptionEngine.encrypt(value, hidden));
        systemConfig.setHidden(hidden);

      } catch (Exception e) {
        throw new RuntimeException(e);
      }
    }

    systemConfig.setCreatedBy("system");

    return systemConfig;
  }
}
