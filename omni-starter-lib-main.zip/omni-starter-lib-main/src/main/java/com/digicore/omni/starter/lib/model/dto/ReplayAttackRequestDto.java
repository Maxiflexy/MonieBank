package com.digicore.omni.starter.lib.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 17 Thu Apr, 2025
 */
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReplayAttackRequestDto {

  @NotBlank private String nonce;

  private long timestamp;
}
