package com.digicore.omni.starter.lib.datasource;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 12 Tue Aug, 2025
 */
public enum DataSourceType {
  PRIMARY,
  READ_REPLICA
}
