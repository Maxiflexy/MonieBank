package com.digicore.omni.starter.lib.config;

import com.digicore.omni.starter.lib.context.IExecutionContext;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 19 Sat Apr, 2025
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class AuditorAwareImpl implements AuditorAware<String> {

  private final ObjectProvider<IExecutionContext> requestProvider;
  private final IExecutionContext executionContext;

  @Override
  public Optional<String> getCurrentAuditor() {
    try {
      if (executionContext != null && executionContext.getUserId() != null) {
        return Optional.ofNullable(executionContext.getUserId());
      }

      if (RequestContextHolder.getRequestAttributes() != null) {
        var request = requestProvider.getIfAvailable();
        if (request != null) {
          return Optional.ofNullable(request.getUserId());
        }
      }
    } catch (Exception e) {
      // Request context not available or scope not active
      log.debug("Request context not available for auditing: {}", e.getMessage());
    }

    // Fallback to SecurityContext (for background processing like Kafka consumers and others)
    try {
      Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
      if (authentication != null && authentication.isAuthenticated()) {
        String name = authentication.getName();
        if (name != null && !name.equals("anonymousUser")) {
          return Optional.of(name);
        }
      }
    } catch (Exception e) {
      log.debug("SecurityContext not available for auditing: {}", e.getMessage());
    }

    return Optional.empty();
  }
}
