package com.digicore.omni.starter.lib.projection;

import java.sql.Timestamp;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 18 Sat Oct, 2025
 */
public interface AuditLogProjection {

  String getId();

  String getRequestId();

  String getAction();

  String getActor();

  String getRequestMethod();

  String getRequestPath();

  Boolean getSuccess();

  String getClientIp();

  String getUserAgent();

  String getLatencyCategory();

  String getDuration();

  Timestamp getCreatedAt();
}
