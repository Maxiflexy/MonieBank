package com.digicore.omni.starter.lib.config;

import static com.digicore.omni.starter.lib.constant.AppConstants.AUDIT_LOG_ACTION;
import static com.digicore.omni.starter.lib.constant.AppConstants.AUDIT_LOG_ACTOR_FIELD;
import static com.digicore.omni.starter.lib.constant.AppConstants.CLAIM_KEY_CLIENT_TYPE;
import static com.digicore.omni.starter.lib.constant.AppConstants.CLIENT_TYPE_FILTER_ATTRIBUTE;
import static com.digicore.omni.starter.lib.constant.AppConstants.USER_CLAIM_KEY_MERCHANT_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.USER_CLAIM_KEY_USERNAME;

import com.digicore.omni.starter.lib.annotation.AuditLoggableFilter;
import com.digicore.omni.starter.lib.annotation.ClientTypeFilter;
import com.digicore.omni.starter.lib.annotation.PermissionFilter;
import com.digicore.omni.starter.lib.contract.IAuthDetailService;
import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.digicore.omni.starter.lib.model.enumeration.ClientType;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerExecutionChain;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 09 Thu Jan, 2025
 */
@Configuration
@RequiredArgsConstructor
public class CustomAuthorizationFilter extends OncePerRequestFilter {

  private final RequestMappingHandlerMapping requestMappingHandlerMapping;

  @Autowired(required = false)
  private IAuthDetailService authDetailService;

  @SneakyThrows
  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {

    HandlerExecutionChain handlerExecutionChain = requestMappingHandlerMapping.getHandler(request);
    if (handlerExecutionChain != null) {
      HandlerMethod handlerMethod = (HandlerMethod) handlerExecutionChain.getHandler();

      AuditLoggableFilter auditLoggableFilter = getAuditLogAnnotation(handlerMethod);

      if (auditLoggableFilter != null) {
        request.setAttribute(AUDIT_LOG_ACTION, auditLoggableFilter.action());
        request.setAttribute(AUDIT_LOG_ACTOR_FIELD, auditLoggableFilter.actorField());
      }
    }

    ClientType clientType = getClientType();

    if (clientType == null) {
      filterChain.doFilter(request, response);
      return;
    }

    if (handlerExecutionChain != null) {
      HandlerMethod handlerMethod = (HandlerMethod) handlerExecutionChain.getHandler();

      ClientTypeFilter clientTypeFilterAnnotation = getClientAuthorizationAnnotation(handlerMethod);

      PermissionFilter permissionFilterAnnotation = getPermissionAnnotation(handlerMethod);

      request.setAttribute(CLIENT_TYPE_FILTER_ATTRIBUTE, clientTypeFilterAnnotation.value());

      if (!Arrays.asList(clientTypeFilterAnnotation.value()).contains(clientType)) {
        throw new AccessDeniedException("Access denied! Invalid client!");
      }

      if (permissionFilterAnnotation != null
          && (ClientType.BACKOFFICE.equals(clientType)
              || ClientType.MERCHANT.equals(clientType)
              || ClientType.TERMINAL.equals(clientType))) {

        Pair<Boolean, Boolean> hasPermissionPair =
            hasRequiredPermission(clientType, permissionFilterAnnotation, request);

        if (Boolean.FALSE.equals(hasPermissionPair.getRight())) {
          throw new AccessDeniedException(
              "Invalid or disabled role. Please reach out to the administrator");
        }

        if (Boolean.FALSE.equals(hasPermissionPair.getLeft())) {
          throw new AccessDeniedException("Insufficient permission");
        }
      }
    }

    filterChain.doFilter(request, response);
  }

  private ClientType getClientType() {

    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

    if (authentication == null) return null;
    Jwt jwt = (Jwt) authentication.getPrincipal();

    String clientType = jwt.getClaim(CLAIM_KEY_CLIENT_TYPE);

    if (StringUtils.isBlank(clientType)) {
      throw CommonExceptionOf.Business.Authorization.UNAUTHORIZED.exception();
    }

    return switch (ClientType.valueOf(clientType)) {
      case MERCHANT -> ClientType.MERCHANT;
      case BACKOFFICE -> ClientType.BACKOFFICE;
      case TERMINAL -> ClientType.TERMINAL;
      case SERVICE -> ClientType.SERVICE;
      default -> throw CommonExceptionOf.Business.Authorization.UNAUTHORIZED.exception();
    };
  }

  private static ClientTypeFilter getClientAuthorizationAnnotation(HandlerMethod handlerMethod) {
    ClientTypeFilter clientTypeFilterAnnotation =
        handlerMethod.getMethodAnnotation(ClientTypeFilter.class);
    if (clientTypeFilterAnnotation == null) {
      clientTypeFilterAnnotation =
          handlerMethod.getBeanType().getAnnotation(ClientTypeFilter.class);
    }

    if (clientTypeFilterAnnotation == null) {
      clientTypeFilterAnnotation = getDefaultClientAccess();
    }
    return clientTypeFilterAnnotation;
  }

  private static ClientTypeFilter getDefaultClientAccess() {

    return new ClientTypeFilter() {
      @Override
      public Class<? extends Annotation> annotationType() {
        return ClientTypeFilter.class;
      }

      @Override
      public ClientType[] value() {
        return new ClientType[] {ClientType.BACKOFFICE};
      }
    };
  }

  private static PermissionFilter getPermissionAnnotation(HandlerMethod handlerMethod) {
    PermissionFilter permissionFilterAnnotation =
        handlerMethod.getMethodAnnotation(PermissionFilter.class);

    if (permissionFilterAnnotation == null) {
      permissionFilterAnnotation =
          handlerMethod.getBeanType().getAnnotation(PermissionFilter.class);
    }
    return permissionFilterAnnotation;
  }

  private Pair<Boolean, Boolean> hasRequiredPermission(
      ClientType clientType, PermissionFilter permissionFilter, HttpServletRequest request) {

    var authentication = SecurityContextHolder.getContext().getAuthentication();
    Jwt jwt = (Jwt) authentication.getPrincipal();

    IAuthDetailService.UserRoleDetails userRoleDetails;
    if (clientType == ClientType.MERCHANT) {
      String userId = jwt.getClaimAsString(USER_CLAIM_KEY_USERNAME);
      String merchantId = jwt.getClaimAsString(USER_CLAIM_KEY_MERCHANT_ID);
      userRoleDetails = authDetailService.getUserPermissionCodes(userId, merchantId, clientType);
    } else if (clientType == ClientType.BACKOFFICE) {
      String userId = jwt.getClaimAsString(USER_CLAIM_KEY_USERNAME);
      userRoleDetails = authDetailService.getUserPermissionCodes(userId, clientType);
    } else {
      return new ImmutablePair<>(false, true);
    }

    if (!userRoleDetails.isEnabled()) {
      return new ImmutablePair<>(false, false);
    }

    if (userRoleDetails.isSuper()) {
      return new ImmutablePair<>(true, true);
    }

    Set<String> userPermissions = userRoleDetails.getPermissions();
    return new ImmutablePair<>(
        Arrays.stream(permissionFilter.value()).anyMatch(userPermissions::contains), true);
  }

  private static AuditLoggableFilter getAuditLogAnnotation(HandlerMethod handlerMethod) {
    AuditLoggableFilter auditLoggableFilter =
        handlerMethod.getMethodAnnotation(AuditLoggableFilter.class);
    if (auditLoggableFilter == null) {
      auditLoggableFilter = handlerMethod.getBeanType().getAnnotation(AuditLoggableFilter.class);
    }
    return auditLoggableFilter;
  }
}
