package com.digicore.omni.starter.lib.filter.subfilter;

import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.digicore.omni.starter.lib.filter.SubWebFilter;
import com.digicore.omni.starter.lib.helper.ClientHelper;
import com.digicore.omni.starter.lib.helper.NonceCleanupTask;
import com.digicore.omni.starter.lib.helper.RequestResponseEncryptionHelper;
import com.digicore.omni.starter.lib.model.dto.ReplayAttackRequestDto;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 02 Tue Sept, 2025
 */
@Slf4j
@Component
@RequiredArgsConstructor
@Order(4)
@Profile("!local")
public class NonceReplaySubFilter implements SubWebFilter {

  public static final String POST = "POST";
  public static final String PUT = "PUT";
  public static final String PATCH = "PATCH";
  private final NonceCleanupTask nonceCleanupTask;
  private final RequestResponseEncryptionHelper requestResponseEncryptionHelper;

  private static final long MAX_TIME_DIFF = 5 * 60 * 1000; // 5 minutes

  @Override
  public void filter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws ServletException, IOException {

    HttpServletRequest httpRequest = (HttpServletRequest) request;
    HttpServletResponse httpResponse = (HttpServletResponse) response;

    String method = httpRequest.getMethod();
    if (POST.equalsIgnoreCase(method)
        || PUT.equalsIgnoreCase(method)
        || PATCH.equalsIgnoreCase(method)) {

      String path = httpRequest.getRequestURI();

      if (requestResponseEncryptionHelper.isExcludedForReplay(path)) {
        chain.doFilter(request, response);
        return;
      }

      log.info("Replay attack check in progress for path: {}", path);

      // Assuming you stored decrypted body in request attribute previously
      String decryptedBody = (String) request.getAttribute("DECRYPTED_REQUEST_BODY");

      log.info("Request: {}", decryptedBody);

      if (StringUtils.isBlank(decryptedBody)) {
        log.warn("No decrypted body found for replay attack check");
        requestResponseEncryptionHelper.writeEncryptedErrorResponse(
            httpResponse, "Missing decrypted request body");
        return;
      }

      try {
        ReplayAttackRequestDto dto =
            ClientHelper.OBJECT_MAPPER.readValue(decryptedBody, ReplayAttackRequestDto.class);

        long now = System.currentTimeMillis();
        if (Math.abs(now - dto.getTimestamp()) > MAX_TIME_DIFF) {
          log.warn(
              "Rejected request due to expired timestamp: request={}, now={}",
              dto.getTimestamp(),
              now);
          throw CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception(
              "Request expired. Please try again.");
        }

        String nonce = dto.getNonce();
        if (StringUtils.isBlank(nonce) || nonceCleanupTask.isNonceUsed(nonce)) {
          log.warn("Rejected request due to missing or reused nonce: {}", nonce);
          throw CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception(
              "Duplicate request detected.");
        }
        nonceCleanupTask.storeNonce(nonce);

      } catch (Exception e) {
        log.error("Failed during replay attack check", e);
        requestResponseEncryptionHelper.writeEncryptedErrorResponse(
            httpResponse, "Invalid request format");
        return;
      }
    }

    chain.doFilter(request, response);
  }
}
