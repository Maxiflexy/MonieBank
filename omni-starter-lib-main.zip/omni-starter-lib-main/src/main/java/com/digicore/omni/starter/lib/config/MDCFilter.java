package com.digicore.omni.starter.lib.config;

import com.digicore.omni.starter.lib.helper.ClientHelper;
import com.github.f4b6a3.ulid.UlidCreator;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 31 Sun Aug, 2025
 */
@Component
@Order(-1000)
@Slf4j
public class MDCFilter extends OncePerRequestFilter {

  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {

    String traceId = UlidCreator.getMonotonicUlid().toString();
    MDC.put("appTraceId", traceId);
    MDC.put("agent", ClientHelper.getUserAgent(request));
    MDC.put("clientIp", ClientHelper.extractClientIp(request));

    try {
      filterChain.doFilter(request, response);
    } finally {
      MDC.clear();
    }
  }
}
