package com.digicore.omni.starter.lib.controller;

import com.digicore.omni.starter.lib.helper.ClientHelper;
import com.digicore.omni.starter.lib.model.dto.EncryptedPayloadDTO;
import com.digicore.omni.starter.lib.model.response.ApiResponseJson;
import com.digicore.omni.starter.lib.model.response.JsonStringWrapper;
import com.digicore.omni.starter.lib.service.ExposedEncryptionService;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Base64;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 18 Fri Apr, 2025
 */
@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
@Profile("!prod")
public class EncryptionController {

  private final ExposedEncryptionService exposedEncryptionService;

  @PostMapping("/decrypt")
  @ResponseStatus(HttpStatus.OK)
  @Operation(
      summary = "Decrypt any encrypted request",
      description = "Decrypt the encrypted given payload")
  public Mono<Object> decrypt(@RequestBody EncryptedPayloadDTO encryptedRequestDTO) {
    return Mono.just(exposedEncryptionService.decrypt(encryptedRequestDTO));
  }

  @PostMapping("/encrypt")
  @ResponseStatus(HttpStatus.OK)
  @Operation(
      summary = "Encrypt any clear json string",
      description = "Encrypt the clear json string payload")
  public Mono<EncryptedPayloadDTO> encrypt(@RequestBody String clearJsonText) {
    return Mono.just(exposedEncryptionService.encrypt(clearJsonText));
  }

  @PostMapping(value = "/stringify", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  public Mono<JsonStringWrapper> stringifyJson(@RequestBody Object jsonObject)
      throws JsonProcessingException {
    return Mono.just(new JsonStringWrapper(exposedEncryptionService.stringifyJson(jsonObject)));
  }

  @GetMapping(value = "/current-timestamp")
  @ResponseStatus(HttpStatus.OK)
  public Mono<JsonStringWrapper> currentTimestamp() {
    return Mono.just(new JsonStringWrapper("" + System.currentTimeMillis()));
  }

  @GetMapping("/sra")
  @ResponseStatus(HttpStatus.OK)
  public ApiResponseJson reason(HttpServletResponse response) {
    Pair<String, String> pair = exposedEncryptionService.encodeExposedKey();
    response.addHeader(
        "asq", StringUtils.reverse(Base64.getEncoder().encodeToString(pair.getKey().getBytes())));
    response.addHeader("sra", pair.getValue());
    return ClientHelper.buildResponse("", "", "", true);
  }
}
