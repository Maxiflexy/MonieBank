package com.digicore.omni.starter.lib.config;

import com.digicore.omni.starter.lib.constant.SystemConfigKeyConstant;
import com.digicore.omni.starter.lib.contract.ConfigInitializer;
import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.digicore.omni.starter.lib.exception.ExceptionCode;
import com.digicore.omni.starter.lib.exception.RequestException;
import com.digicore.omni.starter.lib.helper.ClientHelper;
import com.digicore.omni.starter.lib.helper.RequestResponseEncryptionHelper;
import com.digicore.omni.starter.lib.model.response.ApiError;
import com.digicore.omni.starter.lib.model.response.ApiResponseJson;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolationException;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.nio.file.AccessDeniedException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.safety.Safelist;
import org.slf4j.MDC;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.core.MethodParameter;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.ErrorResponse;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.support.WebExchangeBindException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.server.MethodNotAllowedException;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;
import org.springframework.web.servlet.resource.NoResourceFoundException;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 15 Tue Apr, 2025
 */
@Slf4j
@RequiredArgsConstructor
@RestControllerAdvice
public class ApiAdvice implements RequestBodyAdvice, ResponseBodyAdvice<Object> {

  private final Environment env;

  private final ConfigInitializer configInitializer;
  private final RequestResponseEncryptionHelper requestResponseEncryptionHelper;

  @ExceptionHandler(NoResourceFoundException.class)
  @ResponseStatus(HttpStatus.NOT_FOUND)
  public ResponseEntity<ApiResponseJson> handleNoResourceFoundException(
      NoResourceFoundException e) {
    String errMsg = e.getRootCause() == null ? e.getMessage() : e.getRootCause().getMessage();
    log.error("{} NoResourceFoundException: {}", MDC.get("appTraceId"), errMsg);

    ExceptionCode exceptionCode = CommonExceptionOf.Business.NotFound.NOT_FOUND;
    ApiResponseJson responseJson = new ApiResponseJson(exceptionCode);

    return new ResponseEntity<>(responseJson, HttpStatus.NOT_FOUND);
  }

  @ExceptionHandler(WebExchangeBindException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ApiResponseJson handleValidationException(WebExchangeBindException ex) {
    String errorMessage =
        ex.getAllErrors().stream()
            .map(DefaultMessageSourceResolvable::getDefaultMessage)
            .collect(Collectors.joining("; "));

    log.warn("Validation error: {}", errorMessage);
    return new ApiResponseJson(CommonExceptionOf.Business.BadRequest.BAD_REQUEST);
  }

  @ExceptionHandler(Exception.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public ApiResponseJson handleException(Exception e) {
    log.error("{}: Exception: ", MDC.get("appTraceId"), e);

    ExceptionCode exceptionCode = CommonExceptionOf.System.InternalError.SERVER_ERROR;
    return new ApiResponseJson(exceptionCode);
  }

  @ExceptionHandler(InvalidFormatException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ApiResponseJson handleInvalidFormatException(InvalidFormatException e) {
    log.error(
        "InvalidFormatException: {}",
        e.getCause() == null ? e.getMessage() : e.getCause().getMessage());

    ExceptionCode exceptionCode = CommonExceptionOf.Business.BadRequest.BAD_REQUEST;
    exceptionCode.exception(
        "Invalid Value - "
            + e.getValue()
            + ". Possible Values: "
            + Arrays.toString(e.getTargetType().getEnumConstants()));

    return new ApiResponseJson(exceptionCode);
  }

  @ExceptionHandler(MethodArgumentNotValidException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ApiResponseJson handleValidationException(MethodArgumentNotValidException e) {
    log.error(
        "MethodArgumentNotValidException: {}",
        e.getCause() == null ? e.getMessage() : e.getCause().getMessage());

    return getBindingExceptions(e.getBindingResult().getFieldErrors());
  }

  @ExceptionHandler(MethodNotAllowedException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ApiResponseJson handleMethodNotAllowedException(MethodNotAllowedException e) {
    log.error(
        "MethodNotAllowedException: {}",
        e.getCause() == null ? e.getMessage() : e.getCause().getMessage());
    return new ApiResponseJson(CommonExceptionOf.Business.BadRequest.BAD_REQUEST, e.getMessage());
  }

  @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ApiResponseJson handleHttpRequestMethodNotSupportedException(
      HttpRequestMethodNotSupportedException e) {
    String errMsg = e.getCause() == null ? e.getMessage() : e.getCause().getMessage();
    log.error("HttpRequestMethodNotSupportedException: {}", errMsg);
    return new ApiResponseJson(CommonExceptionOf.Business.BadRequest.BAD_REQUEST, errMsg);
  }

  @ExceptionHandler(MissingServletRequestParameterException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ApiResponseJson handleMissingServletRequestParameterException(
      MissingServletRequestParameterException e) {
    String errMsg = e.getCause() == null ? e.getMessage() : e.getCause().getMessage();
    log.error("MissingServletRequestParameterException: {}", errMsg);
    return new ApiResponseJson(CommonExceptionOf.Business.BadRequest.BAD_REQUEST, errMsg);
  }

  @ExceptionHandler(ConstraintViolationException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ApiResponseJson handleConstraintViolationException(ConstraintViolationException e) {
    log.error(
        "ConstraintViolationException: {}",
        e.getCause() == null ? e.getMessage() : e.getCause().getMessage());
    List<FieldError> errors =
        e.getConstraintViolations().stream()
            .map(
                constraintViolation ->
                    new FieldError(
                        constraintViolation.getRootBeanClass().getName(),
                        constraintViolation.getPropertyPath().toString(),
                        constraintViolation.getMessage()))
            .toList();
    return getBindingExceptions(errors);
  }

  @ExceptionHandler(IllegalArgumentException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ApiResponseJson handleIllegalArgumentException(IllegalArgumentException e) {
    log.error(
        "IllegalArgumentException: {}",
        e.getCause() == null ? e.getMessage() : e.getCause().getMessage());
    return new ApiResponseJson(CommonExceptionOf.Business.BadRequest.BAD_REQUEST, e.getMessage());
  }

  @ExceptionHandler(BindException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ApiResponseJson handleBindingException(BindException e) {
    log.error(
        "BindException: {}", e.getCause() == null ? e.getMessage() : e.getCause().getMessage());
    return getBindingExceptions(e.getBindingResult().getFieldErrors());
  }

  @ExceptionHandler(MethodArgumentTypeMismatchException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ApiResponseJson handleMethodArgumentTypeMismatchException(
      MethodArgumentTypeMismatchException e) {
    log.error(
        "MethodArgumentTypeMismatchException: {}",
        e.getCause() == null ? e.getMessage() : e.getCause().getMessage());
    Throwable throwable = (e.getRootCause() != null) ? e.getRootCause() : e;
    return new ApiResponseJson(
        CommonExceptionOf.Business.BadRequest.BAD_REQUEST, throwable.getMessage());
  }

  @ExceptionHandler(AuthenticationException.class)
  @ResponseStatus(HttpStatus.UNAUTHORIZED)
  public ApiResponseJson handleAuthenticationException(AuthenticationException e) {
    log.error(
        "AuthenticationException: {}",
        e.getCause() == null ? e.getMessage() : e.getCause().getMessage());
    return new ApiResponseJson(
        CommonExceptionOf.Business.Authorization.UNAUTHORIZED, e.getMessage());
  }

  @ExceptionHandler(AccessDeniedException.class)
  @ResponseStatus(HttpStatus.FORBIDDEN)
  public ApiResponseJson handleAccessDeniedException(AccessDeniedException e) {
    log.error(
        "AccessDeniedException: {}",
        e.getCause() == null ? e.getMessage() : e.getCause().getMessage());
    return new ApiResponseJson(CommonExceptionOf.Business.Forbidden.FORBIDDEN, e.getMessage());
  }

  @ExceptionHandler(AuthorizationDeniedException.class)
  @ResponseStatus(HttpStatus.FORBIDDEN)
  public ApiResponseJson handleAuthorizationDeniedException(AuthorizationDeniedException e) {
    String errMsg = e.getCause() == null ? e.getMessage() : e.getCause().getMessage();
    log.error("AuthorizationDeniedException: {}", errMsg);

    return new ApiResponseJson(CommonExceptionOf.Business.Forbidden.FORBIDDEN, e.getMessage());
  }

  @ExceptionHandler(NullPointerException.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public ApiResponseJson handleNullPointerException(NullPointerException e) {
    log.error(
        "NullPointerException: {}",
        e.getCause() == null ? e.getMessage() : e.getCause().getMessage());
    log.error("Error: ", e);
    return new ApiResponseJson(CommonExceptionOf.System.InternalError.SERVER_ERROR, e.getMessage());
  }

  @ExceptionHandler(HttpMessageNotReadableException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ApiResponseJson handleHttpMessageNotReadableException(HttpMessageNotReadableException e) {
    log.error(
        "HttpMessageNotReadableException: {}",
        e.getCause() == null ? e.getMessage() : e.getCause().getMessage());
    String errMsg =
        e.getMessage().contains("Required request body is missing:")
            ? "Invalid body request"
            : e.getMessage();
    ApiResponseJson responseJson =
        new ApiResponseJson(CommonExceptionOf.Business.BadRequest.BAD_REQUEST, errMsg);
    responseJson.setResponseMessage(errMsg);
    return responseJson;
  }

  @ExceptionHandler(RequestException.class)
  public ResponseEntity<ApiResponseJson> handleRequestException(
      RequestException e, HttpServletRequest request, HttpServletResponse response) {
    log.error(
        "RequestException: {}", e.getCause() == null ? e.getMessage() : e.getCause().getMessage());
    var baseResponse = new ApiResponseJson(e.getCode(), e.getMessage());
    var statusAsInt = Integer.parseInt(e.getCode().substring(0, 3));
    HttpStatus status = HttpStatus.valueOf(statusAsInt);
    if (StringUtils.isBlank(response.getHeader("encrypt"))
        || !response.getHeader("encrypt").equalsIgnoreCase("yes")
        || isExcludedEncryptionResponse(request.getRequestURI()))
      return new ResponseEntity<>(baseResponse, status);
    else {
      requestResponseEncryptionHelper.writeEncryptedErrorResponse(response, baseResponse);
      return null;
    }
  }

  public boolean isExcludedEncryptionResponse(String path) {
    List<String> defaultExcluded =
        List.of(
            "/api/v1/sub-merchant/export",
            "/api/v1/merchant-outlet/export",
            "/api/v1/merchant/terminal/export",
            "/api/v1/backoffice/terminal/export",
            "/api/v1/merchant/settlement/filter/export",
            "/api/v1/merchant/user/export",
            "/api/v1/backoffice/settlement/filter/export",
            "/api/v1/merchant/transaction/filter/export",
            "/api/v1/backoffice/transaction/filter/export",
            "/api/v1/sub-merchant/transaction/export",
            "/api/v1/merchant/user/export");

    String dynamicExcluded =
        configInitializer.configCache().get(SystemConfigKeyConstant.OMNI_ENCRYPTION_EXCLUDED_PATHS);

    if (StringUtils.isBlank(dynamicExcluded) || dynamicExcluded.equalsIgnoreCase("all")) {
      return true;
    }

    List<String> dynamicList =
        StringUtils.isBlank(dynamicExcluded) ? List.of() : List.of(dynamicExcluded.split(","));

    List<String> combined = new ArrayList<>(defaultExcluded);
    combined.addAll(dynamicList);

    return combined.stream().anyMatch(path::startsWith);
  }

  private ApiResponseJson getBindingExceptions(List<FieldError> errorList) {

    ApiResponseJson responseJson =
        new ApiResponseJson(CommonExceptionOf.Business.BadRequest.BAD_REQUEST);
    List<ApiError> errors = new ArrayList<>();

    for (FieldError fieldError : errorList) {
      errors.add(
          new ApiError(
              fieldError.isBindingFailure()
                  ? "Invalid data format"
                  : fieldError
                      .getField()
                      .concat(" ")
                      .concat(
                          fieldError.getDefaultMessage() == null
                              ? "is required and must be valid"
                              : fieldError.getDefaultMessage()),
              fieldError.getCode(),
              fieldError.getField()));
    }

    if (!errors.isEmpty()) {
      String responseMessage = String.format("%s", errors.getFirst().getMessage());
      //          String.format("%s: %s", errors.getFirst().getFieldName(),
      // errors.getFirst().getMessage());

      responseJson.setResponseMessage(responseMessage);
    }

    responseJson.setErrors(errors);
    return responseJson;
  }

  @Override
  public boolean supports(
      MethodParameter methodParameter,
      Type targetType,
      Class<? extends HttpMessageConverter<?>> converterType) {
    return true;
  }

  @Override
  public Object afterBodyRead(
      Object body,
      HttpInputMessage inputMessage,
      MethodParameter parameter,
      Type targetType,
      Class<? extends HttpMessageConverter<?>> converterType) {
    return cleanXSSObjectFieldsRecursive(body);
  }

  @Override
  public HttpInputMessage beforeBodyRead(
      HttpInputMessage inputMessage,
      MethodParameter parameter,
      Type targetType,
      Class<? extends HttpMessageConverter<?>> converterType)
      throws IOException {
    return inputMessage;
  }

  @Override
  public Object handleEmptyBody(
      Object body,
      HttpInputMessage inputMessage,
      MethodParameter parameter,
      Type targetType,
      Class<? extends HttpMessageConverter<?>> converterType) {
    return body;
  }

  public boolean supports(MethodParameter mp, Class<? extends HttpMessageConverter<?>> type) {
    return true;
  }

  public Object beforeBodyWrite(
      Object body,
      MethodParameter mp,
      MediaType mt,
      Class<? extends HttpMessageConverter<?>> type,
      ServerHttpRequest shr,
      ServerHttpResponse shr1) {

    var activeProfiles = Arrays.asList(env.getActiveProfiles()); // Get active profiles as a list

    // Check for specific profiles and specific paths
    if (isSwaggerEndpoint(shr.getURI().getPath()) || activeProfiles.contains("integration-test")) {
      return body;
    }

    // Handle String specially
    if (body instanceof String) {
      try {
        shr1.getHeaders().setContentType(MediaType.APPLICATION_JSON);
        return ClientHelper.OBJECT_MAPPER.writeValueAsString(
            new ApiResponseJson(body, "Operation completed successfully"));
      } catch (JsonProcessingException e) {
        return body;
      }
    }

    return body instanceof ApiResponseJson
            || body instanceof Resource
            || body instanceof ProblemDetail
            || body instanceof ErrorResponse
            || requestResponseEncryptionHelper.isApiResponseJsonOrExcluded(
                body, shr.getURI().getPath())
        ? this.cleanXSSObjectFieldsRecursive(body)
        : this.cleanXSSObjectFieldsRecursive(
            new ApiResponseJson(body, "Operation completed successfully"));
  }

  private String cleanXSS(String value) {
    // Remove dangerous script-related patterns
    value = value.replaceAll("(?i)<script.*?>.*?</script.*?>", ""); // Matches <script> tags
    value = value.replaceAll("(?i)<.*?javascript:.*?>.*?</.*?>", ""); // Matches javascript:
    value = value.replaceAll("(?i)<.*?on.*?=.*?>.*?</.*?>", ""); // Matches on* events like onClick

    // Remove potentially dangerous eval and expressions
    value = value.replaceAll("eval\\((.*)\\)", "");
    value = value.replaceAll("[\\\"\\'][\\s]*javascript:(.*?)[\\\"\\']", "\"\"");

    // Return cleaned value
    return Jsoup.clean(value, Safelist.none());
  }

  private Object cleanXSSObjectFieldsRecursive(Object body) {
    if (body == null) {
      return null;
    }

    if (!body.getClass().getPackageName().contains("com.xtremebit")) {
      return body;
    }

    Field[] fields = body.getClass().getDeclaredFields();
    for (Field field : fields) {
      field.setAccessible(true);
      try {
        Object value = field.get(body);
        if (value instanceof String && !((String) value).isEmpty()) {
          String cleanValue = cleanXSS((String) value);
          field.set(body, cleanValue);
        } else if (value != null && value.getClass().getPackageName().contains("com.xtremebit")) {
          cleanXSSObjectFieldsRecursive(value); // Recursive sanitization
        }
      } catch (IllegalAccessException e) {
        //        log.error("Failed to access field: " + field.getName());
      }
    }

    return body;
  }

  private boolean isSwaggerEndpoint(String uriPath) {
    String SWAGGER_UI_PATH = "/swagger-ui";
    String API_DOCS_PATH = "/v3/api-docs";
    return uriPath.contains(SWAGGER_UI_PATH) || uriPath.contains(API_DOCS_PATH);
  }
}
