package com.digicore.omni.starter.lib.service;

import com.digicore.omni.starter.lib.contract.ConfigInitializer;
import java.util.HashMap;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 21 Mon Apr, 2025
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ConfigInitializerImpl implements ConfigInitializer {
  private final SystemConfigService systemConfigService;

  private Map<String, String> configCache = new HashMap<>();

  @Override
  public Map<String, String> configCache() {
    return configCache;
  }

  @EventListener(ApplicationReadyEvent.class)
  @Order(2)
  public void init() {
    log.info("Initializing default configs after application startup");

    try {
      Map<String, String> configs = systemConfigService.initializeAndLoadConfigs();
      configCache = configs;
      log.info("Default configs initialized successfully, loaded {} configs", configs.size());
    } catch (Exception ex) {
      log.error("Failed to initialize default configs", ex);
    }
  }

  public void reloadCache() {
    try {
      Map<String, String> configs = systemConfigService.loadConfigFromDatabase();
      configCache = configs;
      log.info("Default configs reloaded successfully, loaded {} configs", configs.size());
    } catch (Exception ex) {
      log.error("Failed to reload default configs", ex);
    }
  }
}
