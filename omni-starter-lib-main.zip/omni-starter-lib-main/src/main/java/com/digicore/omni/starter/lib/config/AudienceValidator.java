package com.digicore.omni.starter.lib.config;

import java.util.List;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.OAuth2ErrorCodes;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidatorResult;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.util.CollectionUtils;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 19 Sat Apr, 2025
 */
public class AudienceValidator implements OAuth2TokenValidator<Jwt> {

  private final List<String> audiences;

  public AudienceValidator(List<String> audiences) {
    this.audiences = audiences;
  }

  @Override
  public OAuth2TokenValidatorResult validate(Jwt jwt) {
    if (jwt.getAudience() != null && CollectionUtils.containsAny(jwt.getAudience(), audiences)) {
      return OAuth2TokenValidatorResult.success();
    } else {
      OAuth2Error error =
          new OAuth2Error(OAuth2ErrorCodes.INVALID_TOKEN, "The required audience is missing", null);
      return OAuth2TokenValidatorResult.failure(error);
    }
  }
}
