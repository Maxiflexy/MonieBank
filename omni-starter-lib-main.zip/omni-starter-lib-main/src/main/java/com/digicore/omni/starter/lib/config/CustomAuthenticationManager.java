package com.digicore.omni.starter.lib.config;

import static com.digicore.omni.starter.lib.constant.AppConstants.AUDIT_LOG_ACTION;
import static com.digicore.omni.starter.lib.constant.AppConstants.AUDIT_LOG_ACTOR_FIELD;
import static com.digicore.omni.starter.lib.constant.AppConstants.CLAIM_KEY_CLIENT_TYPE;
import static com.digicore.omni.starter.lib.constant.AppConstants.TERMINAL_CLAIM_KEY_MERCHANT_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.TERMINAL_CLAIM_KEY_OUTLET_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.USER_CLAIM_KEY_MERCHANT_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.USER_CLAIM_KEY_USERNAME;
import static com.digicore.omni.starter.lib.constant.SystemConfigKeyConstant.OAUTH_RESOURCE_SERVER_RESOURCE_IDS;
import static com.digicore.omni.starter.lib.constant.SystemConfigKeyConstant.OMNI_TOKEN_PUBLIC_KEY;

import com.digicore.omni.starter.lib.annotation.AuditLoggableFilter;
import com.digicore.omni.starter.lib.contract.ConfigInitializer;
import com.digicore.omni.starter.lib.contract.IAuthDetailService;
import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.digicore.omni.starter.lib.model.enumeration.ClientType;
import com.nimbusds.jwt.JWTParser;
import jakarta.servlet.http.HttpServletRequest;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerExecutionChain;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 01 Mon Sept, 2025
 */
@Component
@RequiredArgsConstructor
@Slf4j
@Getter
@Setter
public class CustomAuthenticationManager implements AuthenticationManager {

  @Value(
      "${omni.token.secret-key:MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7hF4zxPo6mlP2asNH48h3JCs14IGn/WnI/tpE4AnBYIeUVSiXoLn4pd2Oi4JExZAzEoEeP03G5GBCNTMAuZSnlbH7A46nwkxgmPIb3wHgFmg4DpJok9FM5dtGzjdqAlR5rntP5D2TwA9jUTVqjrJyPabqPLfmHUIJQGH90IUu8h+G3TVCGyvoq6cT4kjkl8BdWJI1xekXr8qPxnj1rTtGHEVQbuSuHecuf1JNByDZL4rIDK4IjmXuMtkhFoaKKBn3gd39CXhbn0zDmXrgyDWW5dpLCOy0vrWs1/nbEF3p+br+oLv/G2oQcJ72E5DWVC3ZKP2V7w/j41pdur99cIv5QIDAQAB}")
  private String publicKeyStr;

  private static final String DOWNLOAD_APP_ENDPOINT = "/api/v1/terminal/download-latest-app-build";
  private static final String UPGRADE_COMPLETED_ENDPOINT = "/api/v1/terminal/app-upgrade-completed";

  private final ConfigInitializer configInitializer;
  private final HttpServletRequest request;

  @Autowired(required = false)
  private IAuthDetailService authDetailService;

  @Value("#{'${oauth.resource-server.public-paths:}'.split(',')}")
  private String[] publicPaths;

  private final AntPathMatcher pathMatcher = new AntPathMatcher();

  private final RequestMappingHandlerMapping requestMappingHandlerMapping;

  @SneakyThrows
  @Override
  public Authentication authenticate(Authentication authentication) throws AuthenticationException {
    if (authDetailService == null) return null;

    try {

      HandlerExecutionChain handlerExecutionChain =
          requestMappingHandlerMapping.getHandler(request);

      if (handlerExecutionChain != null) {
        HandlerMethod handlerMethod = (HandlerMethod) handlerExecutionChain.getHandler();

        AuditLoggableFilter auditLoggableFilter = getAuditLogAnnotation(handlerMethod);

        if (auditLoggableFilter != null) {
          request.setAttribute(AUDIT_LOG_ACTION, auditLoggableFilter.action());
          request.setAttribute(AUDIT_LOG_ACTOR_FIELD, auditLoggableFilter.actorField());
        }
      }

      String requestURI = request.getRequestURI();
      boolean shouldSkipFilter =
          Arrays.stream(publicPaths).anyMatch(pattern -> pathMatcher.match(pattern, requestURI));
      if (shouldSkipFilter) {
        return null;
      }

      ClientType clientType = getClientType((String) authentication.getPrincipal());

      if (ClientType.MERCHANT.equals(clientType)) {
        return merchantAuthenticationFlow(
            primaryJwtDecoderWithAudienceValidator()
                .decode((String) authentication.getPrincipal()));
      } else if (ClientType.TERMINAL.equals(clientType)) {
        return terminalAuthenticationFlow(
            primaryJwtDecoderWithAudienceValidator()
                .decode((String) authentication.getPrincipal()));
      } else if (ClientType.BACKOFFICE.equals(clientType)) {
        return backofficeAuthenticationFlow(
            primaryJwtDecoderWithAudienceValidator()
                .decode((String) authentication.getPrincipal()));
      } else if (ClientType.SERVICE.equals(clientType)) {
        request.setAttribute("isService", "yeah");
        return primaryAuthenticationFlow(
            serviceJwtDecoderWithAudienceValidator()
                .decode((String) authentication.getPrincipal()));
      }

      return null;
    } catch (Exception e) {
      log.info("Could not authenticate: {}", e.getMessage());
      throw e;
    }
  }

  private AbstractAuthenticationToken merchantAuthenticationFlow(Jwt jwt) {

    String userId = jwt.getClaimAsString(USER_CLAIM_KEY_USERNAME);
    boolean userAndMerchantActive =
        authDetailService.isUserAndMerchantActiveWithActiveSession(
            userId, jwt.getClaimAsString(USER_CLAIM_KEY_MERCHANT_ID), jwt.getClaimAsString("xxt"));

    if (!userAndMerchantActive) {
      throw CommonExceptionOf.Business.Authorization.MERCHANT_USER_IS_NOT_ACTIVE.exception();
    }

    boolean isMerchantUserUsingDefaultPassword =
        authDetailService.isMerchantUserUsingDefaultPassword(userId);

    if (isMerchantUserUsingDefaultPassword
        && !request.getRequestURI().equalsIgnoreCase("/api/v1/user/change-default-password")) {
      throw CommonExceptionOf.Business.Authorization.USER_IS_USING_DEFAULT_PASSWORD.exception();
    }
    return new JwtAuthenticationToken(jwt, Collections.emptyList());
  }

  private AbstractAuthenticationToken terminalAuthenticationFlow(Jwt jwt) {
    String terminalId = jwt.getClaimAsString(USER_CLAIM_KEY_USERNAME);
    boolean terminalAndOutletActive =
        authDetailService.isTerminalAndOutletActiveAndMerchantActiveWithActiveSession(
            terminalId,
            jwt.getClaimAsString(TERMINAL_CLAIM_KEY_OUTLET_ID),
            jwt.getClaimAsString(TERMINAL_CLAIM_KEY_MERCHANT_ID),
            jwt.getClaimAsString("xxt"));

    if (!terminalAndOutletActive) {
      throw CommonExceptionOf.Business.Authorization.TERMINAL_IS_NOT_ACTIVE.exception();
    }

    boolean isTerminalUsingDefaultPin = authDetailService.isTerminalUsingDefaultPin(terminalId);

    if (isTerminalUsingDefaultPin
        && !request.getRequestURI().equalsIgnoreCase("/api/v1/terminal/change-default-pin")) {
      throw CommonExceptionOf.Business.Authorization.TERMINAL_IS_USING_DEFAULT_PASSWORD.exception();
    }

    boolean isTerminalAppUpgradeRequired =
        authDetailService.isTerminalAppUpgradeRequired(terminalId);

    if (isTerminalAppUpgradeRequired && !isExemptFromUpgradeCheck(request.getRequestURI())) {
      throw CommonExceptionOf.Business.Authorization.TERMINAL_APP_UPDATE_IS_REQUIRED.exception();
    }
    return new JwtAuthenticationToken(jwt, Collections.emptyList());
  }

  private boolean isExemptFromUpgradeCheck(String requestUri) {
    return requestUri.equalsIgnoreCase(DOWNLOAD_APP_ENDPOINT)
        || requestUri.equalsIgnoreCase(UPGRADE_COMPLETED_ENDPOINT);
  }

  private AbstractAuthenticationToken backofficeAuthenticationFlow(Jwt jwt) {
    var userId = jwt.getClaimAsString(USER_CLAIM_KEY_USERNAME);
    boolean isBackOfficeUser =
        authDetailService.isBackOfficeUserActiveWithActiveSession(
            userId, jwt.getClaimAsString("xxt"));

    if (!isBackOfficeUser) {
      throw CommonExceptionOf.Business.Authorization.BACKOFFICE_USER_IS_NOT_ACTIVE.exception();
    }

    boolean isBackOfficeUserUsingDefaultPassword =
        authDetailService.isBackOfficeUserUsingDefaultPassword(userId);

    if (isBackOfficeUserUsingDefaultPassword
        && !request.getRequestURI().equalsIgnoreCase("/api/v1/user/change-default-password")) {
      throw CommonExceptionOf.Business.Authorization.USER_IS_USING_DEFAULT_PASSWORD.exception();
    }

    return new JwtAuthenticationToken(jwt, Collections.emptyList());
  }

  private AbstractAuthenticationToken primaryAuthenticationFlow(Jwt jwt) {
    return new JwtAuthenticationToken(jwt, Collections.emptyList());
  }

  private JwtDecoder primaryJwtDecoderWithAudienceValidator() {
    String resourceIdConfig =
        configInitializer.configCache().get(OAUTH_RESOURCE_SERVER_RESOURCE_IDS);

    List<String> resourceIds =
        Arrays.stream(resourceIdConfig.split(","))
            .map(String::trim)
            .filter(s -> !s.isEmpty())
            .toList();

    return createJwtDecoder(
        configInitializer.configCache().get(OMNI_TOKEN_PUBLIC_KEY),
        new AudienceValidator(resourceIds));
  }

  private JwtDecoder serviceJwtDecoderWithAudienceValidator() {
    String resourceIdConfig =
        configInitializer.configCache().get(OAUTH_RESOURCE_SERVER_RESOURCE_IDS);

    List<String> resourceIds =
        Arrays.stream(resourceIdConfig.split(","))
            .map(String::trim)
            .filter(s -> !s.isEmpty())
            .toList();

    return createJwtDecoder(publicKeyStr, new AudienceValidator(resourceIds));
  }

  private JwtDecoder createJwtDecoder(
      String publicKey, OAuth2TokenValidator<Jwt> additionalValidator) {
    OAuth2TokenValidator<Jwt> defaultValidators = JwtValidators.createDefault();
    NimbusJwtDecoder jwtDecoder =
        NimbusJwtDecoder.withPublicKey((RSAPublicKey) getPublicKey(publicKey)).build();
    jwtDecoder.setJwtValidator(
        new DelegatingOAuth2TokenValidator<>(List.of(defaultValidators, additionalValidator)));
    return jwtDecoder;
  }

  private PublicKey getPublicKey(String publicKeyString) {
    try {
      byte[] byteKey = Base64.decodeBase64(publicKeyString);
      X509EncodedKeySpec x509publicKey = new X509EncodedKeySpec(byteKey);
      return KeyFactory.getInstance("RSA").generatePublic(x509publicKey);
    } catch (Exception ex) {
      throw CommonExceptionOf.System.InternalError.SERVER_ERROR.exception(ex);
    }
  }

  @SneakyThrows
  private ClientType getClientType(String jwtToken) {
    String clientType =
        (String) JWTParser.parse(jwtToken).getJWTClaimsSet().getClaim(CLAIM_KEY_CLIENT_TYPE);

    if (StringUtils.isBlank(clientType)) {
      throw CommonExceptionOf.Business.Authorization.UNAUTHORIZED.exception();
    }

    return switch (ClientType.valueOf(clientType)) {
      case MERCHANT -> ClientType.MERCHANT;
      case BACKOFFICE -> ClientType.BACKOFFICE;
      case TERMINAL -> ClientType.TERMINAL;
      case SERVICE -> ClientType.SERVICE;
      default -> throw CommonExceptionOf.Business.Authorization.UNAUTHORIZED.exception();
    };
  }

  private static AuditLoggableFilter getAuditLogAnnotation(HandlerMethod handlerMethod) {
    AuditLoggableFilter auditLoggableFilter =
        handlerMethod.getMethodAnnotation(AuditLoggableFilter.class);
    if (auditLoggableFilter == null) {
      auditLoggableFilter = handlerMethod.getBeanType().getAnnotation(AuditLoggableFilter.class);
    }
    return auditLoggableFilter;
  }
}
