package com.digicore.omni.starter.lib.encryption;

import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import jakarta.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 18 Fri Apr, 2025
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class PluggableEncryptionService {

  private final Map<String, EncryptionEngine> engineRegistry = new HashMap<>();

  private final List<EncryptionEngine> engines;

  @PostConstruct
  public void initialize() {
    for (EncryptionEngine engine : engines) {
      engineRegistry.put(engine.algorithmName().toUpperCase(), engine);
    }
  }

  public EncryptionEngine getEngine(String algorithm) {
    EncryptionEngine engine = engineRegistry.get(algorithm.toUpperCase());
    if (engine == null) {
      throw CommonExceptionOf.System.InternalError.SERVER_ERROR.exception(
          "No encryption engine found for: " + algorithm);
    }
    return engine;
  }
}
