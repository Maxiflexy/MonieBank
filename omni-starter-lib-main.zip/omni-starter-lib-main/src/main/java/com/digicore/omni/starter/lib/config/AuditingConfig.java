package com.digicore.omni.starter.lib.config;

import com.digicore.omni.starter.lib.context.IExecutionContext;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 19 Sat Apr, 2025
 */
@Configuration
@EnableJpaAuditing(auditorAwareRef = "auditorProvider")
public class AuditingConfig {

  @Autowired private IExecutionContext executionContext;

  @Bean
  public AuditorAware<String> auditorProvider(
      ObjectProvider<IExecutionContext> contextObjectProvider) {
    return new AuditorAwareImpl(contextObjectProvider, executionContext);
  }
}
