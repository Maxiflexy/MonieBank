package com.digicore.omni.starter.lib.model.entity.converter;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 13 Mon Jan, 2025
 */
@Converter
public class StringSetConverter implements AttributeConverter<Set<String>, String> {

  public String convertToDatabaseColumn(Set<String> set) {
    return CollectionUtils.isNotEmpty(set) ? String.join(",", set) : "";
  }

  public Set<String> convertToEntityAttribute(String joined) {
    return StringUtils.isNotBlank(joined)
        ? new HashSet<>(Arrays.asList(joined.split(",")))
        : Collections.emptySet();
  }
}
