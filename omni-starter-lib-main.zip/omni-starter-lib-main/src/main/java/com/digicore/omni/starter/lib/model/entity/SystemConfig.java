package com.digicore.omni.starter.lib.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.SQLRestriction;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 11 Sat Jan, 2025
 */
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@Table(name = "system_configuration")
@EqualsAndHashCode(callSuper = false)
@SQLRestriction("deleted = false")
@SQLDelete(sql = "update system_configuration set deleted = true where id=? and version=?")
public class SystemConfig extends BaseEntity {

  @NotNull @Column(unique = true, nullable = false)
  private String configKey;

  @NotNull @Column(nullable = false, columnDefinition = "TEXT")
  private String configValue;

  private String description;

  private String hidden;

  private Boolean canBeDeleted;

  private Boolean canBeUpdated;

  public Boolean getCanBeDeleted() {
    return Boolean.TRUE.equals(canBeDeleted);
  }

  public Boolean getCanBeUpdated() {
    return Boolean.TRUE.equals(canBeUpdated);
  }
}
