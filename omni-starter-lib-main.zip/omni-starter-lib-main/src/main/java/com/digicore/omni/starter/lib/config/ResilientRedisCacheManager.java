package com.digicore.omni.starter.lib.config;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import java.util.Collection;
import java.util.concurrent.Callable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.cache.RedisCache;
import org.springframework.data.redis.cache.RedisCacheManager;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 01 Wed Oct, 2025
 */
@SuppressWarnings("null")
@Slf4j
public class ResilientRedisCacheManager implements CacheManager {

  private final RedisCacheManager redisCacheManager;
  private final CircuitBreaker circuitBreaker;

  public ResilientRedisCacheManager(
      RedisCacheManager redisCacheManager, CircuitBreaker circuitBreaker) {
    this.redisCacheManager = redisCacheManager;
    this.circuitBreaker = circuitBreaker;
  }

  @Override
  public Cache getCache(String name) {
    var cache = redisCacheManager.getCache(name);

    if (cache instanceof RedisCache redisCache) {
      return new ResilientRedisCache(redisCache, circuitBreaker);
    }

    return cache;
  }

  @Override
  public Collection<String> getCacheNames() {
    return redisCacheManager.getCacheNames();
  }

  private static class ResilientRedisCache implements Cache {

    private final RedisCache redisCache;
    private final CircuitBreaker circuitBreaker;

    public ResilientRedisCache(RedisCache redisCache, CircuitBreaker circuitBreaker) {
      this.redisCache = redisCache;
      this.circuitBreaker = circuitBreaker;
    }

    @Override
    public String getName() {
      return redisCache.getName();
    }

    @Override
    public Object getNativeCache() {
      return redisCache.getNativeCache();
    }

    @Override
    public ValueWrapper get(Object key) {
      try {
        return circuitBreaker.executeCallable(() -> redisCache.get(key));
      } catch (Exception e) {
        return null;
      }
    }

    @Override
    public <T> T get(Object key, Class<T> type) {
      try {
        return circuitBreaker.executeCallable(() -> redisCache.get(key, type));
      } catch (Exception e) {
        throw new Cache.ValueRetrievalException(key, () -> null, e);
      }
    }

    @Override
    public <T> T get(Object key, Callable<T> valueLoader) {
      try {
        return circuitBreaker.executeCallable(() -> redisCache.get(key, valueLoader));
      } catch (Exception e) {
        try {
          return valueLoader.call();
        } catch (Exception ex) {
          throw new Cache.ValueRetrievalException(key, valueLoader, ex);
        }
      }
    }

    @Override
    public void put(Object key, Object value) {
      try {
        circuitBreaker.executeRunnable(() -> redisCache.put(key, value));
      } catch (Exception e) {
        log.info("Failed to put cache", e);
      }
    }

    @Override
    public ValueWrapper putIfAbsent(Object key, Object value) {
      try {
        return circuitBreaker.executeCallable(() -> redisCache.putIfAbsent(key, value));
      } catch (Exception e) {
        return null;
      }
    }

    @Override
    public void evict(Object key) {
      try {
        circuitBreaker.executeRunnable(() -> redisCache.evict(key));
      } catch (Exception e) {
        log.info("Failed to evict cache");
      }
    }

    @Override
    public void clear() {
      try {
        circuitBreaker.executeRunnable(redisCache::clear);
      } catch (Exception e) {
        log.info("Failed to clear cache");
      }
    }
  }
}
