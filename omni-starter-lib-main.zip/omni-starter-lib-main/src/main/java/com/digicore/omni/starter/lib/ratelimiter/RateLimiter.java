package com.digicore.omni.starter.lib.ratelimiter;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD) // This annotation can be used on methods
@Retention(RetentionPolicy.RUNTIME) // Available at runtime for AOP processing
public @interface RateLimiter {
  String name() default "default";
}
