package com.digicore.omni.starter.lib.context;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 30 Tue Sept, 2025
 */
public interface IExecutionContext {

  String getMerchantId();

  String getMerchantIdOrElseThrowErr();

  String getOutletId();

  String getTerminalId();

  String getUserId();

  String getIpAddress();

  String getAppTraceId();

  String getTimeZoneOrDefault();

  String getRoleId();
}
