package com.digicore.omni.starter.lib.datasource;

import java.lang.reflect.Method;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 12 Tue Aug, 2025
 */
@Aspect
@Component
public class RoutingAspect {

  @Around("@annotation(com.digicore.omni.starter.lib.datasource)")
  public Object routeDataSource(ProceedingJoinPoint joinPoint) throws Throwable {
    Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();
    UseDataSource useDataSource = method.getAnnotation(UseDataSource.class);

    try {
      DataSourceContextHolder.set(useDataSource.value());
      return joinPoint.proceed();
    } finally {
      DataSourceContextHolder.clear();
    }
  }
}
