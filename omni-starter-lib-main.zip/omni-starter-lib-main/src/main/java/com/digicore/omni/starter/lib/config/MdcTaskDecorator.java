package com.digicore.omni.starter.lib.config;

import com.digicore.omni.starter.lib.context.ExecutionContextFactory;
import java.util.Map;
import org.slf4j.MDC;
import org.springframework.core.task.TaskDecorator;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 15 Tue Apr, 2025
 */
public class MdcTaskDecorator implements TaskDecorator {

  @Override
  public Runnable decorate(Runnable runnable) {
    Map<String, String> contextMap = MDC.getCopyOfContextMap();

    var securityContext = SecurityContextHolder.getContext();
    var executionContext = ExecutionContextFactory.getContext();

    return () -> {
      if (contextMap != null) {
        MDC.setContextMap(contextMap);
      }
      SecurityContextHolder.setContext(securityContext);
      if (executionContext != null) ExecutionContextFactory.setContext(executionContext);

      try {
        runnable.run();
      } finally {
        MDC.clear();
        SecurityContextHolder.clearContext();
        ExecutionContextFactory.clear();
      }
    };
  }
}
