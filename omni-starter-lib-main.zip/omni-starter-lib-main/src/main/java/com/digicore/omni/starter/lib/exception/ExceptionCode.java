package com.digicore.omni.starter.lib.exception;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 31 Tue Dec, 2024
 */
@Data
public class ExceptionCode {

  private final String code;
  private final String message;

  public ExceptionCode(String code, String message) {
    this.code = code;
    this.message = message;
  }

  public RequestException exception() {
    return new RequestException(new ExceptionCode(code, message));
  }

  public RequestException exception(String message) {
    return new RequestException(new ExceptionCode(code, message));
  }

  public RequestException exceptionWithPlaceholders(String... placeholders) {

    String resolvedMessage = this.message;

    for (String placeholder : placeholders) {
      resolvedMessage = StringUtils.replaceOnce(resolvedMessage, "{}", placeholder);
    }

    return new RequestException(new ExceptionCode(code, resolvedMessage));
  }

  public RequestException exception(Throwable cause) {
    return new RequestException(new ExceptionCode(code, cause.getMessage()), cause);
  }

  public RequestException exception(String message, Throwable cause) {
    return new RequestException(new ExceptionCode(code, message), cause);
  }
}
