package com.digicore.omni.starter.lib.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.parameters.Parameter;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 16 Wed Apr, 2025
 */
@Configuration
public class SpringDocConfig {

  @Value("${swagger.title:API Docs}")
  private String swaggerTitle;

  @Value("${swagger.description:Description}")
  private String swaggerDescription;

  @Value("${swagger.version:v1.0.0}")
  private String swaggerVersion;

  @Bean
  public OpenAPI caseOpenAPI() {
    String schemeName = "bearerAuth";
    String bearerFormat = "JWT";
    String scheme = "bearer";

    return new OpenAPI()
        .info(
            new Info().title(swaggerTitle).description(swaggerDescription).version(swaggerVersion))
        .addSecurityItem(new SecurityRequirement().addList(schemeName))
        .components(
            new Components()
                .addSecuritySchemes(
                    schemeName,
                    new SecurityScheme()
                        .name(schemeName)
                        .type(SecurityScheme.Type.HTTP)
                        .bearerFormat(bearerFormat)
                        .in(SecurityScheme.In.HEADER)
                        .scheme(scheme)));
  }

  @Bean
  public OperationCustomizer customize() {
    return (operation, handlerMethod) -> {
      operation.addParametersItem(
          new Parameter().in("header").description("client-id").name("client-id"));
      operation.addParametersItem(
          new Parameter().in("header").description("business-id").name("business-id"));
      return operation;
    };
  }
}
