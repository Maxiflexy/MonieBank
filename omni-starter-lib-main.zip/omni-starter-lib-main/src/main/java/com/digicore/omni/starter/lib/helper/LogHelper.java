package com.digicore.omni.starter.lib.helper;

import static com.digicore.omni.starter.lib.constant.AppConstants.AGENT;
import static com.digicore.omni.starter.lib.constant.AppConstants.APP_TRACE_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.CLIENT_IP;

import com.digicore.omni.starter.lib.config.MdcTaskWrapper;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 01 Fri Aug, 2025
 */
@UtilityClass
@Slf4j
public class LogHelper {

  private static final ObjectMapper OBJECT_MAPPER;

  private static final Set<String> SENSITIVE_KEYS =
      Set.of(
          "password",
          "pin",
          "token",
          "secret",
          "otp",
          "headers",
          "topic",
          "tokens",
          "x-api-key",
          "api-key",
          "apikey",
          "client",
          "accesstoken",
          "access-token",
          "confirmPassword",
          "defaultpin",
          "rawPin",
          "newPin",
          "pinKey",
          "masterKey",
          "sessionKey",
          "idNumber",
          "IDNumber",
          "DOB",
          "id_number",
          "dateOfBirth",
          "nonce");

  private static final Set<String> SENSITIVE_KEYS_LOWER =
      SENSITIVE_KEYS.stream().map(String::toLowerCase).collect(Collectors.toSet());

  private static final String ANSI_RESET = "\u001B[0m";
  private static final String ANSI_GREEN = "\u001B[32m";
  private static final String ANSI_CYAN = "\u001B[36m";
  private static final String ANSI_YELLOW = "\u001B[33m";

  public static final ExecutorService LOG_EXECUTOR =
      new ThreadPoolExecutor(
          4, // corePoolSize (always kept alive)
          16, // maxPoolSize (burst capacity)
          60L,
          TimeUnit.SECONDS, // idle thread keep-alive time
          new ArrayBlockingQueue<>(1000), // work queue size
          new ThreadPoolExecutor.CallerRunsPolicy() // fallback if full
          );
  public static final String STR = "str";
  public static final String VALUE = "value";

  static {
    OBJECT_MAPPER =
        new ObjectMapper()
            .registerModules(new JavaTimeModule())
            .disable(SerializationFeature.FAIL_ON_EMPTY_BEANS)
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
  }

  public <T> void logObject(T obj) {
    logObject(obj, null, null);
  }

  public <T> void logObject(T obj, String key) {
    logObject(obj, key, null);
  }

  public <T> void logObject(T obj, Map<String, Object> additionalContext) {
    logObject(obj, null, additionalContext);
  }

  public <T> void logObject(T obj, String key, Map<String, Object> additionalContext) {

    // 🧭 Determine the calling class and method
    StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
    String origin = "Unknown::Unknown";
    for (StackTraceElement element : stackTrace) {
      if (!element.getClassName().equals(LogHelper.class.getName())
          && !element.getClassName().startsWith("java.lang.Thread")) {
        String simpleClass =
            element.getClassName().substring(element.getClassName().lastIndexOf('.') + 1);
        origin = simpleClass + "::" + element.getMethodName();
        break;
      }
    }

    String caller = origin;

    LOG_EXECUTOR.submit(
        MdcTaskWrapper.wrap(
            () -> {
              if (obj == null) {
                log.warn(ANSI_YELLOW + "Attempted to log null object." + ANSI_RESET);
                return;
              }
              try {
                Map<String, Object> map = new HashMap<>();
                if (obj instanceof String) {
                  map.put(StringUtils.isBlank(key) ? STR : key, obj);
                } else if (obj instanceof Number
                    || obj instanceof Boolean
                    || obj instanceof Character) {
                  map.put(StringUtils.isBlank(key) ? VALUE : key, obj);
                } else {
                  map = convertToMap(obj);
                }
                map.put("origin", caller);
                map.put(APP_TRACE_ID, MDC.get(APP_TRACE_ID));
                map.put(AGENT, MDC.get(AGENT));
                map.put(CLIENT_IP, MDC.get(CLIENT_IP));
                if (additionalContext != null) map.putAll(additionalContext);
                sanitizeMap(map);
                log.info(
                    ANSI_GREEN + "{}" + ANSI_RESET + ": " + ANSI_CYAN + "{}" + ANSI_RESET,
                    obj.getClass().getSimpleName(),
                    OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(map));
              } catch (Exception e) {
                log.error(ANSI_YELLOW + "Failed to log object: {}" + ANSI_RESET, obj, e);
              }
            }));
  }

  private <T> Map<String, Object> convertToMap(T obj) throws IOException {
    if (obj instanceof String str && isJsonObject(str)) {
      return OBJECT_MAPPER.readValue(str, new TypeReference<>() {});
    }
    return OBJECT_MAPPER.convertValue(obj, new TypeReference<>() {});
  }

  private boolean isJsonObject(String str) {
    String trimmed = str.trim();
    return trimmed.startsWith("{") && trimmed.endsWith("}");
  }

  private boolean isJsonArray(String str) {
    String trimmed = str.trim();
    return trimmed.startsWith("[") && trimmed.endsWith("]");
  }

  public void sanitizeMap(Map<String, Object> map) {
    if (isNullOrEmpty(map)) return;

    for (Map.Entry<String, Object> entry : map.entrySet()) {
      processEntry(entry);
    }
  }

  public String sanitizeString(String rawString) {
    if (rawString == null || rawString.isBlank()) {
      return rawString;
    }

    try {
      if (isJsonObject(rawString)) {
        Map<String, Object> parsedMap =
            OBJECT_MAPPER.readValue(rawString, new TypeReference<Map<String, Object>>() {});
        sanitizeMap(parsedMap);
        return OBJECT_MAPPER.writeValueAsString(parsedMap);
      } else if (isJsonArray(rawString)) {
        List<Object> parsedList =
            OBJECT_MAPPER.readValue(rawString, new TypeReference<List<Object>>() {});
        sanitizeList(parsedList);
        return OBJECT_MAPPER.writeValueAsString(parsedList);
      }
    } catch (Exception e) {
      log.warn(ANSI_YELLOW + "Could not sanitize string payload" + ANSI_RESET, e);
    }

    // fallback: if it’s not JSON but should be sanitized (like plaintext secrets)
    //    if (shouldSanitize(null, rawString)) {
    //      return "***[PROTECTED]";
    //    }

    return rawString;
  }

  private void processEntry(Map.Entry<String, Object> entry) {
    String key = entry.getKey();
    Object value = entry.getValue();

    if (value instanceof Map<?, ?> nestedMap) {
      sanitizeMap(castToMap(nestedMap));
    } else if (value instanceof List<?> list) {
      sanitizeList(list);
    }

    try {
      if (value instanceof String strVal && isJsonObject(strVal)) {
        Map<String, Object> parsedMap =
            OBJECT_MAPPER.readValue(strVal, new TypeReference<Map<String, Object>>() {});
        sanitizeMap(parsedMap);
        entry.setValue(parsedMap);
      } else if (value instanceof Map) {
        @SuppressWarnings("unchecked")
        Map<String, Object> innerMap = (Map<String, Object>) value;
        sanitizeMap(innerMap);
      }
      // Handle Lists of maps or JSON strings if needed
    } catch (Exception e) {
      log.warn(ANSI_YELLOW + "Could not process entry: {}" + ANSI_RESET, key, e);
    }

    if (shouldSanitize(key, value)) {
      entry.setValue("***[PROTECTED]");
    }
  }

  private boolean shouldSanitize(String key, Object value) {
    return SENSITIVE_KEYS_LOWER.contains(key.toLowerCase())
        && value != null
        && (!(value instanceof String s) || !s.isBlank())
        && (!(value instanceof List<?> l) || !l.isEmpty())
        && (!(value instanceof Map<?, ?> m) || !m.isEmpty());
  }

  //  private boolean shouldSanitize(String key, Object value) {
  //    if (value == null) return false;
  //    String str = value.toString().toLowerCase();
  //
  //    return (key != null && SENSITIVE_KEYS.stream().anyMatch(s -> key.toLowerCase().contains(s)))
  //            || SENSITIVE_KEYS.stream().anyMatch(str::contains)
  //            || str.contains("authorization")
  //            || str.contains("bearer ");
  //  }

  @SuppressWarnings("unchecked")
  private Map<String, Object> castToMap(Map<?, ?> map) {
    if (map == null) return Collections.emptyMap();
    return (Map<String, Object>) map;
  }

  private boolean isNullOrEmpty(Map<?, ?> map) {
    return map == null || map.isEmpty();
  }

  @SuppressWarnings("unchecked")
  private void sanitizeList(List<?> list) {
    if (list == null || list.isEmpty()) return;

    for (Object item : list) {
      if (item instanceof Map<?, ?> nestedMap) {
        sanitizeMap((Map<String, Object>) nestedMap);
      } else if (item instanceof List<?> nestedList) {
        sanitizeList(nestedList);
      }
    }
  }
}
