package com.digicore.omni.starter.lib.filter;

import jakarta.servlet.ReadListener;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 02 Tue Sept, 2025
 */
public class CachedBodyHttpServletRequest extends HttpServletRequestWrapper {

  private final byte[] cachedBody;

  public CachedBodyHttpServletRequest(HttpServletRequest request, byte[] decryptedData) {
    super(request);
    this.cachedBody = decryptedData;
  }

  @Override
  public ServletInputStream getInputStream() throws IOException {
    ByteArrayInputStream bodyStream = new ByteArrayInputStream(cachedBody);

    return new ServletInputStream() {
      @Override
      public boolean isFinished() {
        return bodyStream.available() == 0;
      }

      @Override
      public boolean isReady() {
        return true;
      }

      @Override
      public void setReadListener(ReadListener readListener) {
        // Not needed for this use case
      }

      @Override
      public int read() throws IOException {
        return bodyStream.read();
      }
    };
  }

  @Override
  public BufferedReader getReader() throws IOException {
    return new BufferedReader(new InputStreamReader(getInputStream(), StandardCharsets.UTF_8));
  }

  @Override
  public int getContentLength() {
    return cachedBody.length;
  }

  @Override
  public long getContentLengthLong() {
    return cachedBody.length;
  }
}
