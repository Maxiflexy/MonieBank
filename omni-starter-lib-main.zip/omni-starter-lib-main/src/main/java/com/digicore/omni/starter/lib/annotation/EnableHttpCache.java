package com.digicore.omni.starter.lib.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 19 Sat Apr, 2025
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface EnableHttpCache {
  long maxAge() default 3600; // in seconds

  boolean noCache() default false;

  boolean mustRevalidate() default false;

  boolean etag() default false;

  boolean cachePublic() default false;

  boolean cachePrivate() default false;
}
