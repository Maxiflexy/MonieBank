package com.digicore.omni.starter.lib.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 08 Wed Oct, 2025
 */
@UtilityClass
public class PasswordHistoryCheckerUtil {

  public boolean isPasswordInHistory(
      String currentPassword,
      String newPassword,
      String passwordHistory,
      PasswordEncoder passwordEncoder) {

    if (StringUtils.isBlank(passwordHistory)) {
      return false;
    }
    // Check current password
    if (passwordEncoder.matches(newPassword, currentPassword)) {
      return true;
    }

    // Check password history
    String[] previousPasswords = passwordHistory.split(",");
    for (String previousPassword : previousPasswords) {
      if (StringUtils.isNotBlank(previousPassword)
          && passwordEncoder.matches(newPassword, previousPassword.trim())) {
        return true;
      }
    }

    return false;
  }

  public String appendToPasswordHistory(
      String currentHistory, String passwordToAdd, int maxHistory) {
    List<String> passwords = new ArrayList<>();

    if (StringUtils.isNotBlank(currentHistory)) {
      passwords.addAll(Arrays.asList(currentHistory.split(",")));
    }

    // Add new password
    passwords.add(passwordToAdd);

    // Keep only last N passwords
    if (passwords.size() > maxHistory) {
      passwords = passwords.subList(passwords.size() - maxHistory, passwords.size());
    }

    return String.join(",", passwords);
  }
}
