package com.digicore.omni.starter.lib.context;

import com.digicore.omni.starter.lib.config.RequestContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 30 Tue Sept, 2025
 */
@Configuration
public class ExecutionContextFactory {

  private static final ThreadLocal<IExecutionContext> executionContext =
      ThreadLocal.withInitial(() -> null);

  private final RequestContext requestContext;

  public ExecutionContextFactory(RequestContext requestContext) {
    this.requestContext = requestContext;
  }

  public static void setContext(IExecutionContext context) {
    executionContext.set(context);
  }

  public static IExecutionContext getContext() {
    return executionContext.get();
  }

  public static void clear() {
    executionContext.remove();
  }

  @Bean
  @Primary
  @Scope(value = "prototype", proxyMode = ScopedProxyMode.TARGET_CLASS)
  public IExecutionContext executionContext() {
    var context = getContext();

    if (context != null) {
      return context;
    }

    return requestContext;
  }
}
