package com.digicore.omni.starter.lib.constant;

import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 01 Mon Sept, 2025
 */
@Component
public class SystemConfigKeyConstant {

  public static final String OMNI_ENCRYPTION_PUBLIC_KEY = "omni.encryption.public.key";
  public static final String OMNI_ENCRYPTION_PRIVATE_KEY = "omni.encryption.private.key";
  public static final String OMNI_TOKEN_PUBLIC_KEY = "omni.token.public-key";
  public static final String OMNI_TOKEN_SECRET_KEY = "omni.token.secret-key";
  public static final String OAUTH_RESOURCE_SERVER_RESOURCE_ID =
      "oauth.resource-server.resource-id";
  public static final String OAUTH_RESOURCE_SERVER_RESOURCE_IDS =
      "oauth.resource-server.resource-ids";
  public static final String OMNI_ENCRYPTION_DELIMITER = "omni.encryption.delimiter";
  public static final String OMNI_ENCRYPTION_EXCLUDED_PATHS = "omni.encryption.excluded.paths";

  // AI
  public static final String AI_CLIENT_PROVIDER = "ai.client.provider";
  public static final String GEMINI_API_KEY = "gemini.api.key";
}
