package com.digicore.omni.starter.lib.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.SQLRestriction;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 30 Wed Jul, 2025
 */
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@Table(name = "feature_toggle")
@EqualsAndHashCode(callSuper = false)
@SQLRestriction("deleted = false")
@SQLDelete(sql = "update feature_toggle set deleted = true where id=? and version=?")
public class FeatureToggle extends BaseEntity {

  @NotNull @Column(unique = true, nullable = false)
  private String name;

  private boolean enabled;

  private String userIds;

  public List<String> getUserIds() {
    return userIds != null ? Arrays.asList(userIds.split(",")) : Collections.emptyList();
  }

  public void setUserIds(List<String> list) {
    this.userIds = list != null ? String.join(",", list) : null;
  }
}
