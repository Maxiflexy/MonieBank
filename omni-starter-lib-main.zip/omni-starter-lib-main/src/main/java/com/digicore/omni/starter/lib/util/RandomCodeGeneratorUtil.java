package com.digicore.omni.starter.lib.util;

import com.digicore.omni.starter.lib.model.enumeration.OtpFormat;
import java.security.SecureRandom;
import lombok.experimental.UtilityClass;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 07 Tue Oct, 2025
 */
@UtilityClass
public class RandomCodeGeneratorUtil {

  private static final SecureRandom secureRandom = new SecureRandom();

  public String generateCode(int length, OtpFormat format) {
    String charPool =
        switch (format) {
          case NUMERIC -> "0123456789";
          case ALPHABET -> "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
          case ALPHA_NUMERIC -> "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz0123456789@$&#";
          case ALPHA_NUMERIC_NO_SYMBOL ->
              "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz0123456789";
          default -> "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz0123456789@$&£#";
        };

    StringBuilder otp = new StringBuilder(length);
    for (int i = 0; i < length; i++) {
      otp.append(charPool.charAt(secureRandom.nextInt(charPool.length())));
    }
    return otp.toString();
  }
}
