package com.digicore.omni.starter.lib.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.SQLRestriction;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 19 Sat Apr, 2025
 */
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@Table(name = "audit_log")
@EqualsAndHashCode(callSuper = false)
@SQLRestriction("deleted = false")
@SQLDelete(sql = "update audit_log set deleted = true where id=? and version=?")
public class AuditLog extends BaseEntity {

  private String requestId;

  private String action;

  private String requestMethod;

  private String requestPath;

  @Column(columnDefinition = "TEXT")
  private String responseBody;

  @Column(columnDefinition = "TEXT")
  private String requestBody;

  private boolean success;

  private String clientIp;

  private String userAgent;

  private Long requestSize;

  private Long responseSize;

  private String latencyCategory;

  private String actorId;

  private String actor;

  private String duration;
}
