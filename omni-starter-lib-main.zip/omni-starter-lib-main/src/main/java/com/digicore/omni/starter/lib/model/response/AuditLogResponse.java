package com.digicore.omni.starter.lib.model.response;

import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.Setter;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 01 Sat Nov, 2025
 */
@Getter
@Setter
public class AuditLogResponse {

  private String id;
  private String requestId;
  private String action;
  private String actor;
  private String requestMethod;
  private String requestPath;
  private Boolean success;
  private String clientIp;
  private String userAgent;
  private String latencyCategory;
  private String duration;
  private OffsetDateTime createdAt;
}
