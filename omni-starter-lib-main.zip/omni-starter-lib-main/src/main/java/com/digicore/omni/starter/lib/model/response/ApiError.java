package com.digicore.omni.starter.lib.model.response;

import com.digicore.omni.starter.lib.helper.ClientHelper;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApiError {
  private String message;
  private String code;
  private String fieldName;

  public ApiError(String fieldName, String message) {
    this.fieldName = fieldName;
    this.message = message;
  }

  public ApiError(String message, String code, String fieldName) {
    this.message = message;
    this.code = code;
    this.fieldName = fieldName;
  }

  @Override
  public String toString() {
    try {
      return ClientHelper.OBJECT_MAPPER.writeValueAsString(this);
    } catch (Exception e) {
      ClientHelper.cleanForLog(e.getMessage());
    }

    return "";
  }
}
