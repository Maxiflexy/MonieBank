package com.digicore.omni.starter.lib.util;

import java.io.IOException;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 02 Sun Nov, 2025
 */
@Slf4j
@UtilityClass
public class OffsetDateTimeFlexibleDeserializerUtil {

  private static final ZoneId DEFAULT_ZONE = ZoneId.systemDefault();

  private static final DateTimeFormatter[] DATE_TIME_FORMATTERS = {
    DateTimeFormatter.ISO_OFFSET_DATE_TIME, // 2025-10-01T10:00:00+01:00
    DateTimeFormatter.ISO_ZONED_DATE_TIME, // 2025-10-01T10:00:00+01:00[Europe/London]
    DateTimeFormatter.ISO_INSTANT, // 2025-10-01T09:00:00Z
    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
  };

  private static final DateTimeFormatter[] DATE_ONLY_FORMATTERS = {
    DateTimeFormatter.ofPattern("yyyy-MM-dd"),
    DateTimeFormatter.ofPattern("dd-MM-yyyy"),
    DateTimeFormatter.ofPattern("MM/dd/yyyy"),
    DateTimeFormatter.ofPattern("MM-dd-yyyy"),
    DateTimeFormatter.ofPattern("dd/MM/yyyy"),
  };

  public static OffsetDateTime parseString(String text) throws IOException {
    if (text == null || text.isBlank()) {
      return null;
    }

    text = text.trim();

    // ---------- 1. Parse date-time formats ----------
    for (DateTimeFormatter formatter : DATE_TIME_FORMATTERS) {
      try {
        // If formatter supports offsets/zones
        if (formatter == DateTimeFormatter.ISO_OFFSET_DATE_TIME
            || formatter == DateTimeFormatter.ISO_ZONED_DATE_TIME
            || formatter == DateTimeFormatter.ISO_INSTANT) {

          return OffsetDateTime.parse(text, formatter)
              .atZoneSameInstant(DEFAULT_ZONE)
              .toOffsetDateTime();
        }

        // LocalDateTime patterns
        return java.time.LocalDateTime.parse(text, formatter)
            .atZone(DEFAULT_ZONE)
            .toOffsetDateTime();

      } catch (DateTimeParseException ignored) {
      }
    }

    // ---------- 2. Parse date-only formats ----------
    for (DateTimeFormatter formatter : DATE_ONLY_FORMATTERS) {
      try {
        LocalDate date = LocalDate.parse(text, formatter);
        return date.atStartOfDay(DEFAULT_ZONE).toOffsetDateTime();
      } catch (DateTimeParseException ignored) {
      }
    }

    throw new IOException("Util: Unable to parse date/time: " + text);
  }

  public OffsetDateTime toEndExclusive(OffsetDateTime date) {
    if (date == null) return null;
    log.info("Date before: {}", date);
    date = date.plusDays(1).toLocalDate().atStartOfDay(date.getOffset()).toOffsetDateTime();
    log.info("Date after: {}", date);
    return date;
  }
}
