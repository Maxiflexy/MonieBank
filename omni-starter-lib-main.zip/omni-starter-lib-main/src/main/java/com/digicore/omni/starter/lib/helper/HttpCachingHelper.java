package com.digicore.omni.starter.lib.helper;

import com.digicore.omni.starter.lib.annotation.EnableHttpCache;
import com.digicore.omni.starter.lib.constant.AppConstants;
import com.github.f4b6a3.ulid.UlidCreator;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.CacheControl;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerExecutionChain;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 19 Wed Nov, 2025
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class HttpCachingHelper {

  private final RequestMappingHandlerMapping requestMappingHandlerMapping;

  public void applyCaching(HttpServletRequest request, HttpServletResponse response) {

    Optional<EnableHttpCache> policyOpt = resolveCachePolicy(request);
    if (policyOpt.isEmpty()) return;

    EnableHttpCache policy = policyOpt.get();

    String decryptedBody = (String) request.getAttribute(AppConstants.DECRYPTED_RESPONSE_BODY);
    if (decryptedBody == null) return; // encryption filter didn't process body

    // ---------- GENERATE E-TAG ----------
    String etag = generateEtag(decryptedBody);

    response.setHeader("ETag", etag);

    // ---------- CHECK IF CLIENT ALREADY HAS IT ----------
    String incomingEtag = request.getHeader("If-None-Match");

    if (incomingEtag != null && incomingEtag.equals(etag)) {
      // 304 Not Modified
      response.setStatus(HttpServletResponse.SC_NOT_MODIFIED);
      response.setContentLength(0);
      return;
    }

    // ---------- APPLY CACHE-CONTROL ----------
    applyCacheControl(policy, response);
  }

  @SneakyThrows
  private Optional<EnableHttpCache> resolveCachePolicy(HttpServletRequest request) {

    HandlerExecutionChain handlerExecutionChain = requestMappingHandlerMapping.getHandler(request);

    if (handlerExecutionChain != null) {
      HandlerMethod handlerMethod = (HandlerMethod) handlerExecutionChain.getHandler();

      EnableHttpCache ann = handlerMethod.getMethodAnnotation(EnableHttpCache.class);
      if (ann == null) {
        ann = handlerMethod.getBeanType().getAnnotation(EnableHttpCache.class);
      }
      return Optional.ofNullable(ann);
    }
    return Optional.empty();
  }

  private String generateEtag(String body) {
    try {
      MessageDigest digest = MessageDigest.getInstance("SHA-256");
      byte[] hash = digest.digest(body.getBytes(StandardCharsets.UTF_8));

      StringBuilder hex = new StringBuilder();
      for (byte b : hash) {
        hex.append(String.format("%02x", b));
      }
      return "\"" + hex + "\""; // Strong ETag
    } catch (Exception e) {
      return "\"" + UlidCreator.getUlid() + "\""; // fallback
    }
  }

  private void applyCacheControl(EnableHttpCache policy, HttpServletResponse resp) {

    CacheControl cc;

    if (policy.noCache()) {
      cc = CacheControl.noCache();
    } else {
      cc = CacheControl.maxAge(policy.maxAge(), TimeUnit.SECONDS);
      if (policy.cachePublic()) cc = cc.cachePublic();
      if (policy.cachePrivate()) cc = cc.cachePrivate();
      if (policy.mustRevalidate()) cc = cc.mustRevalidate();
    }

    int status = resp.getStatus();

    if (status >= 200 && status < 300) {
      resp.setHeader("Cache-Control", cc.getHeaderValue());
    }
  }
}
