package com.digicore.omni.starter.lib.model.enumeration;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 20 Thu Nov, 2025
 */
public enum UserStatus {
  ACTIVE,
  INACTIVE
}
