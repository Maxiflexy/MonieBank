package com.digicore.omni.starter.lib.config;

import java.util.Map;
import java.util.concurrent.Callable;
import org.slf4j.MDC;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 31 Sun Aug, 2025
 */
public class MdcTaskWrapper {

  public static Runnable wrap(Runnable task) {
    Map<String, String> contextMap = MDC.getCopyOfContextMap();
    return () -> {
      if (contextMap != null) {
        MDC.setContextMap(contextMap);
      }
      try {
        task.run();
      } finally {
        MDC.clear();
      }
    };
  }

  public static <V> Callable<V> wrap(Callable<V> task) {
    Map<String, String> contextMap = MDC.getCopyOfContextMap();
    return () -> {
      if (contextMap != null) {
        MDC.setContextMap(contextMap);
      }
      try {
        return task.call();
      } finally {
        MDC.clear();
      }
    };
  }
}
