package com.digicore.omni.starter.lib.service.api;

import static com.digicore.omni.starter.lib.constant.AppConstants.APP_TRACE_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.USER_ID_HEADER;

import com.digicore.omni.starter.lib.context.IExecutionContext;
import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.digicore.omni.starter.lib.helper.LogHelper;
import jakarta.annotation.PostConstruct;
import java.util.Map;
import java.util.function.Consumer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 20 Mon Oct, 2025
 */
@Slf4j
public abstract class BaseServiceApi {
  protected OmniService service;

  @Value("${omni.services.baseUrl:}")
  protected String baseUrl;

  @Autowired protected WebClient.Builder webClientBuilder;

  @Autowired protected ServiceTokenHelper serviceTokenHelper;

  @Autowired protected IExecutionContext executionContext;

  private WebClient webClient;

  @Autowired private Environment environment;

  public BaseServiceApi(OmniService service) {
    this.service = service;
  }

  @PostConstruct
  private void initWebClient() {
    String finalBaseUrl;

    // Priority 1: Service-specific URL
    String serviceSpecificUrl =
        environment.getProperty("omni.services." + service.getName() + "-service" + ".url");

    if (serviceSpecificUrl != null && !serviceSpecificUrl.isEmpty()) {
      finalBaseUrl = serviceSpecificUrl;
    }
    // Priority 2: Local development (no service name prefix)
    else if (baseUrl.contains("localhost") || baseUrl.contains("127.0.0.1")) {
      finalBaseUrl = baseUrl;
    }
    // Priority 3: Production (with service name prefix)
    else {
      finalBaseUrl = baseUrl + "/" + service.getName();
    }

    this.webClient = webClientBuilder.baseUrl(finalBaseUrl).build();
  }

  protected String getUrl(String endpoint) {
    return "/" + endpoint;
  }

  protected Consumer<HttpHeaders> createHeaders(
      String merchantId, String userId, String outletId, String terminalId) {
    return headers -> {
      headers.setBearerAuth(
          serviceTokenHelper.generateInternalServiceToken(
              merchantId, userId, outletId, terminalId));
      headers.set(USER_ID_HEADER, userId);
      headers.set(APP_TRACE_ID, executionContext.getAppTraceId());
    };
  }

  protected <T> T get(String endpoint, Class<T> responseType) {
    return get(
        endpoint,
        responseType,
        executionContext.getMerchantId(),
        executionContext.getUserId(),
        executionContext.getOutletId(),
        executionContext.getTerminalId());
  }

  protected <T> T get(
      String endpoint,
      Class<T> responseType,
      String merchantId,
      String userId,
      String outletId,
      String terminalId) {
    return webClient
        .get()
        .uri(getUrl(endpoint))
        .headers(createHeaders(merchantId, userId, outletId, terminalId))
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                response
                    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                    .flatMap(
                        errMap -> {
                          LogHelper.logObject(errMap, "SVC_C_ERR");
                          String message =
                              (String) errMap.getOrDefault("responseMessage", "Bad request");
                          return Mono.error(
                              response.statusCode().isSameCodeAs(HttpStatusCode.valueOf(404))
                                  ? CommonExceptionOf.Business.NotFound.NOT_FOUND.exception(message)
                                  : CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception(
                                      message));
                        }))
        .bodyToMono(responseType)
        .block();
  }

  protected <T> T get(String endpoint, ParameterizedTypeReference<T> responseType) {
    return get(
        endpoint,
        responseType,
        executionContext.getMerchantId(),
        executionContext.getUserId(),
        executionContext.getOutletId(),
        executionContext.getTerminalId());
  }

  protected <T> T get(
      String endpoint,
      ParameterizedTypeReference<T> responseType,
      String merchantId,
      String userId,
      String outletId,
      String terminalId) {
    return webClient
        .get()
        .uri(getUrl(endpoint))
        .headers(createHeaders(merchantId, userId, outletId, terminalId))
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                response
                    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                    .flatMap(
                        errMap -> {
                          LogHelper.logObject(errMap, "SVC_C_ERR");
                          String message =
                              (String) errMap.getOrDefault("responseMessage", "Bad request");
                          return Mono.error(
                              response.statusCode().isSameCodeAs(HttpStatusCode.valueOf(404))
                                  ? CommonExceptionOf.Business.NotFound.NOT_FOUND.exception(message)
                                  : CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception(
                                      message));
                        }))
        .bodyToMono(responseType)
        .block();
  }

  protected <T, R> R post(String endpoint, T request, Class<R> responseType) {
    return post(
        endpoint,
        request,
        responseType,
        executionContext.getMerchantId(),
        executionContext.getUserId(),
        executionContext.getOutletId(),
        executionContext.getTerminalId());
  }

  protected <T, R> R post(
      String endpoint,
      T request,
      Class<R> responseType,
      String merchantId,
      String userId,
      String outletId,
      String terminalId) {
    return webClient
        .post()
        .uri(getUrl(endpoint))
        .headers(createHeaders(merchantId, userId, outletId, terminalId))
        .bodyValue(request)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                response
                    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                    .flatMap(
                        errMap -> {
                          LogHelper.logObject(errMap, "SVC_C_ERR");
                          String message =
                              (String) errMap.getOrDefault("responseMessage", "Bad request");
                          return Mono.error(
                              response.statusCode().isSameCodeAs(HttpStatusCode.valueOf(404))
                                  ? CommonExceptionOf.Business.NotFound.NOT_FOUND.exception(message)
                                  : CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception(
                                      message));
                        }))
        .bodyToMono(responseType)
        .block();
  }

  protected <T, R> R post(String endpoint, T request, ParameterizedTypeReference<R> responseType) {
    return post(
        endpoint,
        request,
        responseType,
        executionContext.getMerchantId(),
        executionContext.getUserId(),
        executionContext.getOutletId(),
        executionContext.getTerminalId());
  }

  protected <T, R> R post(
      String endpoint,
      T request,
      ParameterizedTypeReference<R> responseType,
      String merchantId,
      String userId,
      String outletId,
      String terminalId) {
    return webClient
        .post()
        .uri(getUrl(endpoint))
        .headers(createHeaders(merchantId, userId, outletId, terminalId))
        .bodyValue(request)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                response
                    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                    .flatMap(
                        errMap -> {
                          LogHelper.logObject(errMap, "SVC_C_ERR");
                          String message =
                              (String) errMap.getOrDefault("responseMessage", "Bad request");
                          return Mono.error(
                              response.statusCode().isSameCodeAs(HttpStatusCode.valueOf(404))
                                  ? CommonExceptionOf.Business.NotFound.NOT_FOUND.exception(message)
                                  : CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception(
                                      message));
                        }))
        .bodyToMono(responseType)
        .block();
  }

  protected <T> void put(String endpoint, T request) {
    put(
        endpoint,
        request,
        executionContext.getMerchantId(),
        executionContext.getUserId(),
        executionContext.getOutletId(),
        executionContext.getTerminalId());
  }

  protected <T> void put(
      String endpoint,
      T request,
      String merchantId,
      String userId,
      String outletId,
      String terminalId) {
    webClient
        .put()
        .uri(getUrl(endpoint))
        .headers(createHeaders(merchantId, userId, outletId, terminalId))
        .bodyValue(request)
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                response
                    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                    .flatMap(
                        errMap -> {
                          LogHelper.logObject(errMap, "SVC_C_ERR");
                          String message =
                              (String) errMap.getOrDefault("responseMessage", "Bad request");
                          return Mono.error(
                              response.statusCode().isSameCodeAs(HttpStatusCode.valueOf(404))
                                  ? CommonExceptionOf.Business.NotFound.NOT_FOUND.exception(message)
                                  : CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception(
                                      message));
                        }))
        .toBodilessEntity()
        .block();
  }

  protected void delete(String endpoint) {
    delete(
        endpoint,
        executionContext.getMerchantId(),
        executionContext.getUserId(),
        executionContext.getOutletId(),
        executionContext.getTerminalId());
  }

  protected void delete(
      String endpoint, String merchantId, String userId, String outletId, String terminalId) {
    webClient
        .delete()
        .uri(getUrl(endpoint))
        .headers(createHeaders(merchantId, userId, outletId, terminalId))
        .retrieve()
        .onStatus(
            HttpStatusCode::is4xxClientError,
            response ->
                response
                    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                    .flatMap(
                        errMap -> {
                          LogHelper.logObject(errMap, "SVC_C_ERR");
                          String message =
                              (String) errMap.getOrDefault("responseMessage", "Bad request");
                          return Mono.error(
                              response.statusCode().isSameCodeAs(HttpStatusCode.valueOf(404))
                                  ? CommonExceptionOf.Business.NotFound.NOT_FOUND.exception(message)
                                  : CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception(
                                      message));
                        }))
        .toBodilessEntity()
        .block();
  }
}
