package com.digicore.omni.starter.lib.exception;

import lombok.experimental.UtilityClass;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 31 Tue Dec, 2024
 */
@UtilityClass
public class CommonExceptionOf {

  @UtilityClass
  public static class Business {
    // 400xx
    @UtilityClass
    public static class BadRequest {
      public static final ExceptionCode BAD_REQUEST =
          new ExceptionCode(
              "400000",
              "The request could not be completed due to malformed syntax. Please crosscheck and try again.");

      public static final ExceptionCode MERCHANT_ID_REQUIRED_ON_HEADER =
          new ExceptionCode("400001", "Request Header is missing merchant-id");

      public static final ExceptionCode DEVICE_ID_REQUIRED_ON_HEADER =
          new ExceptionCode("400002", "Request Header is missing device-id");

      public static final ExceptionCode SYSTEM_CONFIG_KEY_ALREADY_EXIST =
          new ExceptionCode("400003", "System config already exist with the key provided. {}");

      public static final ExceptionCode REQUIRED_FIELD =
          new ExceptionCode("400004", "Required field: {}");

      public static final ExceptionCode AUTHORIZATION_TOKEN_EMPTY =
          new ExceptionCode("400005", "Authorization header is missing");

      public static final ExceptionCode ROLE_NAME_IN_USE =
          new ExceptionCode(
              "400006", "Role with the given name already exists under this business.");
      public static final ExceptionCode SUPER_ROLE_ONLY_NAME_UPDATE_ALLOWED =
          new ExceptionCode(
              "400007",
              "The request could not be completed because only name update is allowed for super role.");
      public static final ExceptionCode SUPER_ROLE_DELETE_NOT_ALLOWED =
          new ExceptionCode(
              "400008", "The request could not be completed because super role cannot be deleted.");
      public static final ExceptionCode ROLE_LINKED_WITH_USERS =
          new ExceptionCode(
              "400009",
              "The role cannot be deleted because it is associated with one or more users.");
      public static final ExceptionCode ROLE_IS_REQUIRED =
          new ExceptionCode("400010", "Role is required");
      public static final ExceptionCode USER_EMAIL_ALREADY_EXIST =
          new ExceptionCode("400011", "User already exist with the email provided: {}");
      public static final ExceptionCode USER_PHONE_ALREADY_EXIST =
          new ExceptionCode("400012", "User already exist with the phone number provided: {}");
      public static final ExceptionCode BUSINESS_ALREADY_EXIST =
          new ExceptionCode("400013", "Business already exists with the name provided. {}");

      public static final ExceptionCode INVALID_ACTIVATION_CODE =
          new ExceptionCode("400014", "Invalid activation code");
      public static final ExceptionCode UNSUPPORTED_COUNTRY =
          new ExceptionCode("400015", "The system does not recognize the country");

      public static final ExceptionCode UNSUPPORTED_STATE =
          new ExceptionCode("400016", "The system does not recognize the state");

      public static final ExceptionCode UNSUPPORTED_LOCAL_GOVERNMENT =
          new ExceptionCode("400017", "The system does not recognize the local government");

      public static final ExceptionCode COUNTRY_ALREADY_EXIST =
          new ExceptionCode("400018", "Countries already exist");

      public static final ExceptionCode STATE_ALREADY_EXIST =
          new ExceptionCode("400019", "States already exist");

      public static final ExceptionCode LOCAL_GOVERNMENT_ALREADY_EXIST =
          new ExceptionCode("400020", "Local government already exist");
    }

    // 401xx
    @UtilityClass
    public static class Authorization {
      public static final ExceptionCode UNAUTHORIZED =
          new ExceptionCode("401000", "Invalid authentication provided");
      public static final ExceptionCode MERCHANT_USER_IS_NOT_ACTIVE =
          new ExceptionCode(
              "401001",
              "Merchant User is not active for business or login session has been renewed");

      public static final ExceptionCode BACKOFFICE_USER_IS_NOT_ACTIVE =
          new ExceptionCode(
              "401002", "Backoffice is not active for user or login session has been renewed");

      public static final ExceptionCode TERMINAL_IS_NOT_ACTIVE =
          new ExceptionCode("401003", "Terminal is not active or auth session has been renewed");

      public static final ExceptionCode USER_IS_USING_DEFAULT_PASSWORD =
          new ExceptionCode("401004", "Default password must be changed at login");

      public static final ExceptionCode TERMINAL_IS_USING_DEFAULT_PASSWORD =
          new ExceptionCode("401005", "Default pin must be changed on authentication");

      public static final ExceptionCode TERMINAL_APP_UPDATE_IS_REQUIRED =
          new ExceptionCode("40106", "Terminal app update is required");
    }

    // 403xx
    @UtilityClass
    public static class Forbidden {
      public static final ExceptionCode FORBIDDEN =
          new ExceptionCode(
              "403000", "You do not have sufficient permissions to access this resource");

      public static final ExceptionCode NO_ACTIVE_BUSINESS_ASSOCIATED =
          new ExceptionCode(
              "403001", "User is not allowed to login as there is no active business associated.");

      public static final ExceptionCode MERCHANT_COMPLIANCE_NOT_APPROVED =
          new ExceptionCode("403002", "Your compliance profile is not approved yet");
    }

    // 404xx
    @UtilityClass
    public static class NotFound {
      public static final ExceptionCode NOT_FOUND =
          new ExceptionCode("404000", "The requested resource was not found in the system");

      public static final ExceptionCode SYSTEM_CONFIG_VERSION_NOT_FOUND =
          new ExceptionCode("404001", "System config not found with the provided version: {}");

      public static final ExceptionCode SYSTEM_CONFIG_ID_NOT_FOUND =
          new ExceptionCode("404002", "System config not found with the provided id: {}");

      public static final ExceptionCode BUSINESS_NOT_FOUND_BY_ID =
          new ExceptionCode("404003", "Business not found for id: {}");

      public static final ExceptionCode AUTH_USER_NOT_FOUND =
          new ExceptionCode("404004", "Auth user not found");

      public static final ExceptionCode ROLE_NOT_FOUND_BY_ID =
          new ExceptionCode("404005", "Role not found for id: {}");
      public static final ExceptionCode ROLE_VERSION_NOT_FOUND =
          new ExceptionCode("404006", "Role not found with the provided version: {}");

      public static final ExceptionCode ACTIVATION_CODE_NOT_FOUND =
          new ExceptionCode("404007", "Activation code not found");

      public static final ExceptionCode CAMPAIGN_NOT_FOUND =
          new ExceptionCode("404008", "Campaign not found");
    }

    // 409xx
    @UtilityClass
    public static class Conflict {}
  }

  @UtilityClass
  public static class System {

    // 429xx
    @UtilityClass
    public static class RateLimit {
      public static final ExceptionCode RATE_LIMIT_EXCEEDED =
          new ExceptionCode("429000", "Too many requests, please try again later.");

      public static final ExceptionCode BLACK_LISTED =
          new ExceptionCode("429001", "Too many requests, please try again later..");
    }

    // 500xx
    @UtilityClass
    public static class InternalError {
      public static final ExceptionCode SERVER_ERROR =
          new ExceptionCode(
              "500000",
              "An unexpected error occurred while processing your request. Please try again later.");
    }
  }
}
