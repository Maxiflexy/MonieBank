package com.digicore.omni.starter.lib.contract;

import java.util.Map;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 17 Thu Apr, 2025
 */
public interface ConfigInitializer {

  Map<String, String> configCache();

  void reloadCache();
}
