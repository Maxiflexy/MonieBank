package com.digicore.omni.starter.lib.util;

import java.util.List;
import lombok.experimental.UtilityClass;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 23 Thu Oct, 2025
 */
@UtilityClass
public class FilterUtils {

  public <T> List<T> nullIfEmpty(List<T> list) {
    return (list == null || list.isEmpty()) ? null : list;
  }

  public String nullIfBlank(String str) {
    return (str == null || str.isBlank()) ? null : str.trim();
  }
}
