package com.digicore.omni.starter.lib.filter.subfilter;

import static com.digicore.omni.starter.lib.constant.AppConstants.AGENT;
import static com.digicore.omni.starter.lib.constant.AppConstants.APP_TRACE_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.AUDIT_LOG_ACTION;
import static com.digicore.omni.starter.lib.constant.AppConstants.CLIENT_IP;

import com.digicore.omni.starter.lib.config.RequestContext;
import com.digicore.omni.starter.lib.constant.AppConstants;
import com.digicore.omni.starter.lib.filter.SubWebFilter;
import com.digicore.omni.starter.lib.model.entity.AuditLog;
import com.digicore.omni.starter.lib.repository.AuditLogRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.Enumeration;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 05 Sun Oct, 2025
 */
@Slf4j
@Component
@Order(4)
@RequiredArgsConstructor
public class AuditLogSubFilter implements SubWebFilter {

  private final AuditLogRepository auditLogRepository;

  private final RequestContext requestContext;

  @Override
  public void filter(ServletRequest request, ServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {

    filterChain.doFilter(request, response);

    String truncatedRequest = (String) request.getAttribute(AppConstants.AUDIT_LOG_TRUNCATED_REQ);

    String actor = (String) request.getAttribute(AppConstants.AUDIT_LOG_ACTOR_FIELD_VALUE);
    String truncatedResponse = (String) request.getAttribute(AppConstants.AUDIT_LOG_TRUNCATED_RES);
    String action = (String) request.getAttribute(AUDIT_LOG_ACTION);
    String executionTime = (String) request.getAttribute("executionTime");

    if (StringUtils.isNotBlank(action) && StringUtils.isNotBlank(truncatedResponse)) {
      auditAction(
          request, response, truncatedRequest, truncatedResponse, actor, action, executionTime);
    }
  }

  private void auditAction(
      ServletRequest request,
      ServletResponse response,
      String truncatedRequest,
      String truncatedResponse,
      String actor,
      String action,
      String executionTime) {
    HttpServletRequest httpRequest = (HttpServletRequest) request;
    HttpServletResponse httpResponse = (HttpServletResponse) response;
    int statusCode = httpResponse.getStatus();
    boolean success = statusCode >= 200 && statusCode < 400; // ✅ success = true for 2xx and 3xx
    try {

      AuditLog auditLog = new AuditLog();
      auditLog.setAction(action);
      auditLog.setActorId(
          StringUtils.isBlank(requestContext.getUserId()) ? actor : requestContext.getUserId());
      String act =
          StringUtils.isBlank(requestContext.getUserId()) ? actor : requestContext.getUserId();
      auditLog.setActor(actor.equalsIgnoreCase("anonymousUser") ? act : actor);
      auditLog.setRequestMethod(httpRequest.getMethod());
      auditLog.setRequestPath(httpRequest.getRequestURI());
      auditLog.setRequestBody(truncatedRequest);
      auditLog.setResponseBody(truncatedResponse);
      auditLog.setRequestId(MDC.get(APP_TRACE_ID));
      auditLog.setSuccess(success);
      auditLog.setClientIp(MDC.get(CLIENT_IP));
      auditLog.setUserAgent(MDC.get(AGENT));
      auditLog.setRequestSize(estimateRequestSize(httpRequest));
      auditLog.setResponseSize(estimateResponseSize(httpResponse));
      auditLog.setLatencyCategory(
          classifyLatency(Long.parseLong(Objects.requireNonNull(executionTime))));
      auditLog.setCreatedAt(OffsetDateTime.now());
      auditLog.setDuration(String.valueOf(Long.parseLong(executionTime) / 1000.0));

      auditLogRepository.save(auditLog);
      log.info("Audit logged successfully");
    } catch (Exception e) {
      log.info("Err while saving audit: ", e);
    }
  }

  private long estimateRequestSize(HttpServletRequest request) {
    long headerSize = 0;
    Enumeration<String> headerNames = request.getHeaderNames();
    while (headerNames.hasMoreElements()) {
      String headerName = headerNames.nextElement();
      Enumeration<String> headerValues = request.getHeaders(headerName);
      while (headerValues.hasMoreElements()) {
        headerSize += headerName.length() + headerValues.nextElement().length();
      }
    }

    long contentLength = request.getContentLengthLong();
    return (contentLength > 0 ? contentLength : 0) + headerSize;
  }

  private long estimateResponseSize(HttpServletResponse response) {
    long headerSize = 0;
    for (String headerName : response.getHeaderNames()) {
      for (String headerValue : response.getHeaders(headerName)) {
        headerSize += headerName.length() + headerValue.length();
      }
    }

    // No direct way to get response content length unless set explicitly
    String contentLengthHeader = response.getHeader("Content-Length");
    long contentLength = 0;
    if (contentLengthHeader != null) {
      try {
        contentLength = Long.parseLong(contentLengthHeader);
      } catch (NumberFormatException ignored) {
      }
    }

    return contentLength + headerSize;
  }

  private String classifyLatency(long durationMs) {
    if (durationMs < 500) return "SUPER_FAST";
    else if (durationMs < 3000) return "FAST";
    else if (durationMs < 5000) return "NORMAL";
    else if (durationMs < 15000) return "SLOW";
    else return "VERY_SLOW";
  }
}
