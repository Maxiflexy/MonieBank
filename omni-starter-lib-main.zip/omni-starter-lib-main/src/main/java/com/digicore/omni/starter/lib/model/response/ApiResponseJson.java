package com.digicore.omni.starter.lib.model.response;

import static com.digicore.omni.starter.lib.constant.AppConstants.APP_TRACE_ID;

import com.digicore.omni.starter.lib.constant.AppConstants;
import com.digicore.omni.starter.lib.exception.ExceptionCode;
import com.digicore.omni.starter.lib.helper.ClientHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApiResponseJson {
  private String description;
  private String traceId;
  private String responseMessage;
  private boolean success;
  private Object data;
  private Map<String, Object> metadata;
  private List<ApiError> errors;
  private String serviceCode;

  public ApiResponseJson(Object data, String description) {
    this.success = true;
    this.description =
        StringUtils.isBlank(description) ? "Operation completed successfully" : description;
    this.responseMessage =
        StringUtils.isBlank(description) ? "Operation completed successfully" : description;
    this.data = data;
    this.errors = new ArrayList<>();
    this.traceId = MDC.get(APP_TRACE_ID);
    this.serviceCode = AppConstants.getInstance().getServiceCode();
  }

  public ApiResponseJson(ExceptionCode exceptionCode) {
    this.setDescription(exceptionCode.getMessage());
    this.setResponseMessage(exceptionCode.getMessage());
    this.setSuccess(false);
    this.setErrors(List.of(new ApiError(exceptionCode.getMessage(), exceptionCode.getCode(), "")));
    this.traceId = MDC.get(APP_TRACE_ID);
    this.serviceCode = AppConstants.getInstance().getServiceCode();
  }

  public ApiResponseJson(ExceptionCode exceptionCode, String errMsg) {
    this.setDescription(exceptionCode.getMessage());
    this.setResponseMessage(exceptionCode.getMessage());
    this.setSuccess(false);
    this.setErrors(List.of(new ApiError(errMsg, exceptionCode.getCode(), null)));
    this.traceId = MDC.get(APP_TRACE_ID);
    this.serviceCode = AppConstants.getInstance().getServiceCode();
  }

  public ApiResponseJson(String code, String description) {
    this.description = description;
    this.responseMessage = description;
    this.setSuccess(false);
    this.setErrors(List.of(new ApiError(description, code, null)));
    this.traceId = MDC.get(APP_TRACE_ID);
    this.serviceCode = AppConstants.getInstance().getServiceCode();
  }

  @Override
  public String toString() {
    try {
      return ClientHelper.OBJECT_MAPPER.writeValueAsString(this);
    } catch (Exception e) {
      ClientHelper.cleanForLog(e.getMessage());
    }

    return "";
  }
}
