package com.digicore.omni.starter.lib.model.entity.converter;

import com.digicore.omni.starter.lib.util.OffsetDateTimeFlexibleDeserializerUtil;
import java.io.IOException;
import java.time.OffsetDateTime;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 02 Sun Nov, 2025
 */
@Component
public class StringToOffsetDateTimeConverter implements Converter<String, OffsetDateTime> {

  @Override
  public OffsetDateTime convert(String source) {
    // Fix missing '+' in timezone, e.g., "2025-10-01T00:00 01:00" -> "2025-10-01T00:00+01:00"
    String normalized = source.replaceAll(" (\\d{2}:\\d{2})$", "+$1");

    try {
      return OffsetDateTimeFlexibleDeserializerUtil.parseString(normalized);
    } catch (IOException e) {
      throw new IllegalArgumentException("Invalid date: " + source, e);
    }
  }
}
