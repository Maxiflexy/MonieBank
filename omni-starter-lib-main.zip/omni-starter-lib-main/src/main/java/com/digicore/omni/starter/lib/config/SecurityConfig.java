package com.digicore.omni.starter.lib.config;

import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.oauth2.server.resource.web.authentication.BearerTokenAuthenticationFilter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 31 Sun Aug, 2025
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

  @Value("#{'${oauth.resource-server.public-paths:}'.split(',')}")
  private String[] publicPaths;

  private final CustomAuthenticationManager customAuthenticationManager;
  private final CustomAuthorizationFilter customAuthorizationFilter;
  private final GlobalAccessDeniedHandler globalAccessDeniedHandler;
  private final GlobalAuthenticationEntryPoint globalAuthenticationEntryPoint;
  private final ExceptionHandlerFilter exceptionHandlerFilter;

  @Bean
  SecurityFilterChain security(HttpSecurity http) throws Exception {
    http.csrf(AbstractHttpConfigurer::disable) // ✅ disable CSRF for API
        .cors(
            cors ->
                cors.configurationSource(
                    request -> {
                      CorsConfiguration configuration = new CorsConfiguration();
                      configuration.setAllowedOrigins(List.of("*"));
                      configuration.setAllowedMethods(List.of("*"));
                      configuration.setAllowedHeaders(List.of("*"));
                      configuration.setExposedHeaders(List.of("*"));
                      return configuration;
                    }))
        .authorizeHttpRequests(
            auth -> {
              auth.requestMatchers("/health").permitAll();
              auth.requestMatchers(HttpMethod.OPTIONS, "/**").permitAll();
              auth.requestMatchers(HttpMethod.GET, "/actuator/**").permitAll();
              auth.requestMatchers(HttpMethod.POST, "/api/v1/merchant-compliance/smile-callback")
                  .permitAll();
              for (String publicPath : publicPaths) {
                auth.requestMatchers(publicPath).permitAll();
              }
              auth.requestMatchers("/error").permitAll();
              auth.anyRequest().authenticated();
            })
        .addFilterBefore(exceptionHandlerFilter, BearerTokenAuthenticationFilter.class)
        .addFilterAfter(customAuthorizationFilter, BearerTokenAuthenticationFilter.class)
        .oauth2ResourceServer(
            oauth2 -> oauth2.jwt(jwt -> jwt.authenticationManager(customAuthenticationManager)))
        .exceptionHandling(
            ex ->
                ex.accessDeniedHandler(globalAccessDeniedHandler)
                    .authenticationEntryPoint(globalAuthenticationEntryPoint))
        .httpBasic(Customizer.withDefaults());

    return http.build();
  }
}
