package com.digicore.omni.starter.lib.helper;

import com.digicore.omni.starter.lib.constant.SystemConfigKeyConstant;
import com.digicore.omni.starter.lib.contract.ConfigInitializer;
import com.digicore.omni.starter.lib.encryption.HybridEncryptionService;
import com.digicore.omni.starter.lib.exception.ExceptionCode;
import com.digicore.omni.starter.lib.model.dto.EncryptedPayloadDTO;
import com.digicore.omni.starter.lib.model.response.ApiResponseJson;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 23 Wed Apr, 2025
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class RequestResponseEncryptionHelper {

  private final HybridEncryptionService hybridEncryptionService;

  private final ConfigInitializer configInitializer;

  public void writeEncryptedErrorResponse(HttpServletResponse response, String errorMessage) {
    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
    response.setContentType("application/json");

    ExceptionCode exceptionCode = new ExceptionCode("400000", errorMessage);
    ApiResponseJson apiResponseJson = new ApiResponseJson(exceptionCode, errorMessage);

    try (PrintWriter writer = response.getWriter()) {
      String responseBody = ClientHelper.OBJECT_MAPPER.writeValueAsString(apiResponseJson);
      String encryptedResponse = prepareEncryptedResponse(responseBody);

      writer.write(encryptedResponse);
      writer.flush();
    } catch (Exception ex) {
      log.error("Failed to encrypt error response", ex);
      try (PrintWriter writer = response.getWriter()) {
        writer.write("{\"success\":false,\"message\":\"Internal Server Error\"}");
        writer.flush();
      } catch (IOException ioEx) {
        log.error("Failed to write fallback error response", ioEx);
      }
    }
  }

  public void writeEncryptedErrorResponse(
      HttpServletResponse response, ApiResponseJson apiResponseJson) {
    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
    if (CollectionUtils.isNotEmpty(apiResponseJson.getErrors())) {
      var statusAsInt =
          Integer.parseInt(apiResponseJson.getErrors().get(0).getCode().substring(0, 3));
      response.setStatus(statusAsInt);
    }
    response.setContentType("application/json");

    try (PrintWriter writer = response.getWriter()) {
      String responseBody = ClientHelper.OBJECT_MAPPER.writeValueAsString(apiResponseJson);
      String encryptedResponse = prepareEncryptedResponse(responseBody);

      writer.write(encryptedResponse);
      writer.flush();
    } catch (Exception ex) {
      log.error("Failed to encrypt error response", ex);
      try (PrintWriter writer = response.getWriter()) {
        writer.write("{\"success\":false,\"message\":\"Internal Server Error\"}");
        writer.flush();
      } catch (IOException ioEx) {
        log.error("Failed to write fallback error response", ioEx);
      }
    }
  }

  public String prepareEncryptedResponse(String wrappedJson) throws Exception {

    EncryptedPayloadDTO encryptedPayloadDTO =
        hybridEncryptionService.encryptResponse(
            wrappedJson,
            configInitializer
                .configCache()
                .get(SystemConfigKeyConstant.OMNI_ENCRYPTION_PUBLIC_KEY));
    return ClientHelper.OBJECT_MAPPER.writeValueAsString(encryptedPayloadDTO);
  }

  public String prepareDecryptedRequest(EncryptedPayloadDTO encryptedPayloadDTO) throws Exception {

    String decryptedJson =
        hybridEncryptionService.decryptRequest(
            encryptedPayloadDTO,
            configInitializer
                .configCache()
                .get(SystemConfigKeyConstant.OMNI_ENCRYPTION_PRIVATE_KEY));

    return ClientHelper.OBJECT_MAPPER.readValue(decryptedJson, String.class);
  }

  public boolean isExcludedEncryptionDecryption(String path) {
    List<String> defaultExcluded =
        List.of(
            "/index.html",
            "/swagger-ui.html",
            "/swagger-ui/index.css",
            "/swagger-ui/swagger-ui-bundle.js",
            "/swagger-ui/swagger-initializer.js",
            "/swagger-ui/swagger-ui-standalone-preset.js",
            "/swagger-ui/index.html",
            "/v3/api-docs",
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/v3/api-docs.yaml",
            "/v3/api-docs/",
            "/v3/api-docs/swagger-config",
            "/swagger-ui/swagger-ui.css",
            "/swagger-ui/index.css",
            "/swagger-ui/favicon-32x32.png",
            "/swagger-ui/favicon-16x16.png",
            "/api/v1/encrypt",
            "/api/v1/decrypt",
            "/api/v1/actuator/health",
            "/api/v1/stringify",
            "/api/v1/current-timestamp",
            "/favicon.ico",
            "/api/v1/testing/pdf",
            "/api/v1/job/schedule",
            "/api/v1/testing/schedule",
            "/api/v1/terminal/download-latest-app-build",
            "/api/v1/backoffice/terminal-pos-app/upload",
            "/api/v1/backoffice/terminal/download-create-template",
            "/api/v1/backoffice/terminal/bulk",
            "/api/v1/merchant-file/upload",
            "/api/v1/merchant-compliance/smile-callback",
            "/api/v1/testing/ai-prompt");

    String dynamicExcluded =
        configInitializer.configCache().get(SystemConfigKeyConstant.OMNI_ENCRYPTION_EXCLUDED_PATHS);

    if (StringUtils.isBlank(dynamicExcluded) || dynamicExcluded.equalsIgnoreCase("all")) {
      return true;
    }

    List<String> dynamicList =
        StringUtils.isBlank(dynamicExcluded) ? List.of() : List.of(dynamicExcluded.split(","));

    List<String> combined = new ArrayList<>(defaultExcluded);
    combined.addAll(dynamicList);

    return combined.contains(path);
  }

  public boolean isExcludedDecryptionRequest(String path) {
    List<String> defaultExcluded =
        List.of(
            "/index.html",
            "/swagger-ui.html",
            "/swagger-ui/index.css",
            "/swagger-ui/swagger-ui-bundle.js",
            "/swagger-ui/swagger-initializer.js",
            "/swagger-ui/swagger-ui-standalone-preset.js",
            "/swagger-ui/index.html",
            "/v3/api-docs",
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/v3/api-docs.yaml",
            "/v3/api-docs/",
            "/v3/api-docs/swagger-config",
            "/swagger-ui/swagger-ui.css",
            "/swagger-ui/index.css",
            "/swagger-ui/favicon-32x32.png",
            "/swagger-ui/favicon-16x16.png",
            "/api/v1/encrypt",
            "/api/v1/decrypt",
            "/api/v1/actuator/health",
            "/api/v1/stringify",
            "/api/v1/current-timestamp",
            "/favicon.ico",
            "/api/v1/testing/pdf",
            "/api/v1/job/schedule",
            "/api/v1/testing/schedule",
            "/api/v1/terminal/download-latest-app-build",
            "/api/v1/backoffice/terminal-pos-app/upload",
            "/api/v1/backoffice/terminal/download-create-template",
            "/api/v1/backoffice/terminal/bulk",
            "/api/v1/backoffice/terminal/bulk-assign",
            "/api/v1/merchant-file/upload",
            "/api/v1/merchant-compliance/smile-callback",
            "/api/v1/testing/ai-prompt");

    String dynamicExcluded =
        configInitializer.configCache().get(SystemConfigKeyConstant.OMNI_ENCRYPTION_EXCLUDED_PATHS);

    if (StringUtils.isBlank(dynamicExcluded) || dynamicExcluded.equalsIgnoreCase("all")) {
      return true;
    }

    List<String> dynamicList =
        StringUtils.isBlank(dynamicExcluded) ? List.of() : List.of(dynamicExcluded.split(","));

    List<String> combined = new ArrayList<>(defaultExcluded);
    combined.addAll(dynamicList);

    return combined.contains(path);
  }

  public boolean isExcludedEncryptionResponse(String path) {
    List<String> defaultExcluded =
        List.of(
            "/index.html",
            "/swagger-ui.html",
            "/swagger-ui/index.css",
            "/swagger-ui/swagger-ui-bundle.js",
            "/swagger-ui/swagger-initializer.js",
            "/swagger-ui/swagger-ui-standalone-preset.js",
            "/swagger-ui/index.html",
            "/v3/api-docs",
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/v3/api-docs.yaml",
            "/v3/api-docs/",
            "/v3/api-docs/swagger-config",
            "/swagger-ui/swagger-ui.css",
            "/swagger-ui/index.css",
            "/swagger-ui/favicon-32x32.png",
            "/swagger-ui/favicon-16x16.png",
            "/api/v1/encrypt",
            "/api/v1/decrypt",
            "/api/v1/actuator/health",
            "/api/v1/stringify",
            "/api/v1/current-timestamp",
            "/favicon.ico",
            "/api/v1/testing/pdf",
            "/api/v1/job/schedule",
            "/api/v1/testing/schedule",
            "/api/v1/terminal/download-latest-app-build",
            "/api/v1/backoffice/terminal-pos-app/upload",
            "/api/v1/backoffice/terminal/download-create-template",
            "/api/v1/backoffice/terminal/bulk",
            "/api/v1/backoffice/user/export",
            "/api/v1/merchant/export",
            "/api/v1/merchant-file/upload",
            "/api/v1/merchant-file/download",
            "/api/v1/merchant-compliance/smile-callback",
            "/api/v1/backoffice/terminal/download-assign-template",
            "/api/v1/sub-merchant/export",
            "/api/v1/merchant-outlet/export",
            "/api/v1/merchant/terminal/export",
            "/api/v1/backoffice/terminal/export",
            "/api/v1/merchant/settlement/filter/export",
            "/api/v1/merchant/user/export",
            "/api/v1/backoffice/settlement/filter/export",
            "/api/v1/merchant/transaction/filter/export",
            "/api/v1/backoffice/transaction/filter/export",
            "/api/v1/sub-merchant/transaction/export",
            "/api/v1/backoffice/terminal-request/export",
            "/api/v1/merchant/download",
            "/api/v1/merchant/user/export",
            "/api/v1/backoffice/dispute/export",
            "/api/v1/testing/ai-prompt");

    String dynamicExcluded =
        configInitializer.configCache().get(SystemConfigKeyConstant.OMNI_ENCRYPTION_EXCLUDED_PATHS);

    if (StringUtils.isBlank(dynamicExcluded) || dynamicExcluded.equalsIgnoreCase("all")) {
      return true;
    }

    List<String> dynamicList =
        StringUtils.isBlank(dynamicExcluded) ? List.of() : List.of(dynamicExcluded.split(","));

    List<String> combined = new ArrayList<>(defaultExcluded);
    combined.addAll(dynamicList);

    return combined.stream().anyMatch(path::startsWith);
  }

  public boolean isExcludedForLogging(String path) {
    List<String> defaultExcluded =
        List.of(
            "/swagger-ui/index.css",
            "/swagger-ui/swagger-ui-bundle.js",
            "/swagger-ui/swagger-initializer.js",
            "/swagger-ui/swagger-ui-standalone-preset.js",
            "/swagger-ui/favicon-32x32.png",
            "/swagger-ui/favicon-16x16.png",
            "/swagger-ui/swagger-ui.css",
            "/swagger-ui/index.css",
            "/swagger-ui.html",
            "/swagger-ui/index.html",
            "/v3/api-docs",
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/v3/api-docs.yaml",
            "/v3/api-docs/",
            "/v3/api-docs/swagger-config",
            "/favicon.ico",
            "/api/v1/testing/pdf",
            "/api/v1/job/schedule",
            "/api/v1/encrypt",
            "/api/v1/decrypt",
            "/api/v1/actuator/health",
            "/api/v1/stringify");

    List<String> combined = new ArrayList<>(defaultExcluded);

    return combined.contains(path);
  }

  public boolean isExcludedForReplay(String path) {
    List<String> defaultExcluded =
        List.of(
            "/swagger-ui.html",
            "/v3/api-docs",
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/v3/api-docs.yaml",
            "/v3/api-docs/",
            "/v3/api-docs/swagger-config",
            "/api/v1/encrypt",
            "/api/v1/decrypt",
            "/api/v1/stringify",
            "/api/v1/current-timestamp",
            "/favicon.ico");

    String dynamicExcluded =
        configInitializer.configCache().get(SystemConfigKeyConstant.OMNI_ENCRYPTION_EXCLUDED_PATHS);
    List<String> dynamicList =
        StringUtils.isBlank(dynamicExcluded) ? List.of() : List.of(dynamicExcluded.split(","));

    List<String> combined = new ArrayList<>(defaultExcluded);
    combined.addAll(dynamicList);

    return combined.contains(path);
  }

  public boolean isApiResponseJsonOrExcluded(JsonNode originalJson, String requestPath) {
    return originalJson.has("data")
            && originalJson.has("description")
            && originalJson.has("success")
            && originalJson.has("metadata")
            && originalJson.has("responseMessage")
        || requestPath.contains("swagger")
        || requestPath.contains("api-docs")
        || requestPath.contains("/favicon.ico");
  }

  public boolean isApiResponseJsonOrExcluded(Object body, String requestPath) {
    try {
      JsonNode originalJson =
          body instanceof JsonNode ? (JsonNode) body : ClientHelper.OBJECT_MAPPER.valueToTree(body);

      return originalJson.has("data")
          && originalJson.has("description")
          && originalJson.has("success")
          && originalJson.has("metadata")
          && originalJson.has("responseMessage");
    } catch (Exception ignored) {
    }

    return requestPath.contains("swagger")
        || requestPath.contains("api-docs")
        || requestPath.contains("/favicon.ico");
  }
}
