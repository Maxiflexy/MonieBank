package com.digicore.omni.starter.lib.model.enumeration;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 13 Mon Jan, 2025
 */
public enum InviteStatus {
  PENDING,
  ACCEPTED,
  CANCELED
}
