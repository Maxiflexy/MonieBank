package com.digicore.omni.starter.lib.filter.subfilter;

import static com.digicore.omni.starter.lib.constant.AppConstants.AUDIT_LOG_ACTOR_FIELD;
import static com.digicore.omni.starter.lib.constant.AppConstants.AUDIT_LOG_ACTOR_FIELD_VALUE;
import static com.digicore.omni.starter.lib.constant.AppConstants.AUDIT_LOG_TRUNCATED_REQ;
import static com.digicore.omni.starter.lib.constant.AppConstants.AUDIT_LOG_TRUNCATED_RES;
import static com.digicore.omni.starter.lib.constant.AppConstants.MAX_REQUEST_PAYLOAD_LENGTH;
import static com.digicore.omni.starter.lib.constant.AppConstants.MAX_RESPONSE_PAYLOAD_LENGTH;

import com.digicore.omni.starter.lib.config.RequestContext;
import com.digicore.omni.starter.lib.constant.AppConstants;
import com.digicore.omni.starter.lib.filter.SubWebFilter;
import com.digicore.omni.starter.lib.helper.ClientHelper;
import com.digicore.omni.starter.lib.helper.LogHelper;
import com.digicore.omni.starter.lib.helper.RequestResponseEncryptionHelper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 10 Wed Sept, 2025
 */
@Slf4j
@Component
@Order(5)
@RequiredArgsConstructor
public class LoggerSubFilter implements SubWebFilter {

  private static final String REQUEST_PAYLOAD = "request-payload";
  private static final String REQUEST_PATH = "request-path";
  private static final String REQUEST_METHOD = "request-method";
  private static final String XT_USER_ID = "xt-userId";
  public static final String RESPONSE_PAYLOAD = "response-payload";

  private final RequestResponseEncryptionHelper requestResponseEncryptionHelper;
  private final RequestContext requestContext;

  @Override
  public void filter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws ServletException, IOException {

    chain.doFilter(request, response);

    String requestPayload = (String) request.getAttribute(AppConstants.DECRYPTED_REQUEST_BODY);

    String actor =
        ClientHelper.extractAuditActorField(
            requestPayload, (String) request.getAttribute(AUDIT_LOG_ACTOR_FIELD));
    request.setAttribute(
        AUDIT_LOG_ACTOR_FIELD_VALUE, StringUtils.isBlank(actor) ? "anonymousUser" : actor);

    String truncatedRequest =
        ClientHelper.truncatePayload(requestPayload, MAX_REQUEST_PAYLOAD_LENGTH);

    if (!StringUtils.isBlank(truncatedRequest)) {
      request.setAttribute(AUDIT_LOG_TRUNCATED_REQ, LogHelper.sanitizeString(truncatedRequest));
    }

    if (!requestResponseEncryptionHelper.isExcludedForLogging(
        ((HttpServletRequest) request).getRequestURI())) {

      LogHelper.logObject(
          StringUtils.isBlank(requestPayload) ? StringUtils.EMPTY : truncatedRequest,
          REQUEST_PAYLOAD,
          Map.of(
              REQUEST_PATH,
              ((HttpServletRequest) request).getRequestURI(),
              REQUEST_METHOD,
              ((HttpServletRequest) request).getMethod(),
              XT_USER_ID,
              getUserId(actor)));
    }

    String responsePayload = (String) request.getAttribute(AppConstants.DECRYPTED_RESPONSE_BODY);
    if (!StringUtils.isBlank(responsePayload)) {
      String truncatedResponse =
          ClientHelper.truncatePayload(responsePayload, MAX_RESPONSE_PAYLOAD_LENGTH);
      request.setAttribute(AUDIT_LOG_TRUNCATED_RES, LogHelper.sanitizeString(truncatedResponse));
      LogHelper.logObject(truncatedResponse, RESPONSE_PAYLOAD);
    }

    String startTime = (String) request.getAttribute("startTime");

    request.setAttribute(
        "executionTime", String.valueOf(System.currentTimeMillis() - Long.parseLong(startTime)));
  }

  private String getUserId(String actor) {
    String id = actor != null ? actor : "anonymousUser";
    return requestContext.getUserId() == null ? id : requestContext.getUserId();
  }
}
