package com.digicore.omni.starter.lib.filter.subfilter;

import com.digicore.omni.starter.lib.constant.AppConstants;
import com.digicore.omni.starter.lib.filter.CachedBodyHttpServletRequest;
import com.digicore.omni.starter.lib.filter.SubWebFilter;
import com.digicore.omni.starter.lib.helper.ClientHelper;
import com.digicore.omni.starter.lib.helper.RequestResponseEncryptionHelper;
import com.digicore.omni.starter.lib.model.dto.EncryptedPayloadDTO;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerMapping;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 02 Tue Sept, 2025
 */
@Slf4j
@Component
@Order(3)
@RequiredArgsConstructor
public class DecryptionSubFilter implements SubWebFilter {

  private final RequestResponseEncryptionHelper requestResponseEncryptionHelper;

  @Override
  public void filter(
      ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
      throws ServletException, IOException {

    HttpServletRequest request = (HttpServletRequest) servletRequest;
    HttpServletResponse response = (HttpServletResponse) servletResponse;

    String path = request.getRequestURI();
    String method = request.getMethod();

    String isService = Optional.ofNullable((String) request.getAttribute("isService")).orElse("");

    Map<String, String[]> parameterMap = request.getParameterMap();
    Map<String, Object> flattenedParams = new HashMap<>();
    parameterMap.forEach(
        (k, v) -> flattenedParams.put(k, (v != null && v.length == 1) ? v[0] : Arrays.asList(v)));

    @SuppressWarnings("unchecked")
    Map<String, String> pathVariables =
        (Map<String, String>) request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);

    if (pathVariables == null) {
      pathVariables = Collections.emptyMap();
    }

    byte[] requestBody = request.getInputStream().readAllBytes();

    if (requestResponseEncryptionHelper.isExcludedDecryptionRequest(path)
        || isService.equalsIgnoreCase("yeah")
        || !(HttpMethod.POST.matches(method)
            || HttpMethod.PUT.matches(method)
            || HttpMethod.PATCH.matches(method))
        || (requestBody.length == 0)) {

      String requestBodyString = new String(requestBody, StandardCharsets.UTF_8);

      CachedBodyHttpServletRequest wrappedRequest =
          new CachedBodyHttpServletRequest(request, requestBody);

      Map<String, Object> requestData = new LinkedHashMap<>();
      requestData.put("parameters", flattenedParams);
      requestData.put("pathVariables", pathVariables);
      requestData.put("body", requestBodyString);

      wrappedRequest.setAttribute(
          AppConstants.DECRYPTED_REQUEST_BODY,
          ClientHelper.OBJECT_MAPPER.writeValueAsString(requestData));

      filterChain.doFilter(wrappedRequest, response);
      return;
    }

    try {

      String requestBodyString = new String(requestBody, StandardCharsets.UTF_8);
      EncryptedPayloadDTO encryptedPayloadDTO = null;

      try {
        encryptedPayloadDTO =
            ClientHelper.OBJECT_MAPPER.readValue(requestBodyString, EncryptedPayloadDTO.class);
      } catch (Exception _) {
        requestResponseEncryptionHelper.writeEncryptedErrorResponse(
            response, "Invalid encrypted payload format");
        return;
      }

      String decryptedObject =
          requestResponseEncryptionHelper.prepareDecryptedRequest(encryptedPayloadDTO);

      CachedBodyHttpServletRequest decryptedRequest =
          new CachedBodyHttpServletRequest(
              request, decryptedObject.getBytes(StandardCharsets.UTF_8));

      Map<String, Object> requestData = new LinkedHashMap<>();
      requestData.put("parameters", flattenedParams);
      requestData.put("pathVariables", pathVariables);
      requestData.put("body", ClientHelper.OBJECT_MAPPER.readValue(decryptedObject, Object.class));

      decryptedRequest.setAttribute(
          AppConstants.DECRYPTED_REQUEST_BODY,
          ClientHelper.OBJECT_MAPPER.writeValueAsString(requestData));

      filterChain.doFilter(decryptedRequest, response);

    } catch (IOException e) {
      log.warn("IOException: ", e);
      requestResponseEncryptionHelper.writeEncryptedErrorResponse(
          response, "Failed to read request body");
    } catch (Exception e) {
      log.warn("Exception: ", e);
      requestResponseEncryptionHelper.writeEncryptedErrorResponse(
          response, "Failed to process request");
    }
  }
}
