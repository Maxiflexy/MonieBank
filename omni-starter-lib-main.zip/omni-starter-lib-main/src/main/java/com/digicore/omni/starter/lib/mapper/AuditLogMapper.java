package com.digicore.omni.starter.lib.mapper;

import com.digicore.omni.starter.lib.model.response.AuditLogResponse;
import com.digicore.omni.starter.lib.projection.AuditLogProjection;
import java.sql.Timestamp;
import java.time.ZoneId;
import java.time.ZoneOffset;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 01 Sat Nov, 2025
 */
@Component
public class AuditLogMapper {

  public AuditLogResponse toAuditLogResponse(AuditLogProjection projection) {
    if (projection == null) return null;

    AuditLogResponse response = new AuditLogResponse();
    response.setId(projection.getId());
    response.setRequestId(projection.getRequestId());
    response.setAction(projection.getAction());
    response.setActor(projection.getActor());
    response.setRequestMethod(projection.getRequestMethod());
    response.setRequestPath(projection.getRequestPath());
    response.setSuccess(projection.getSuccess());
    response.setClientIp(projection.getClientIp());
    response.setUserAgent(projection.getUserAgent());
    response.setLatencyCategory(projection.getLatencyCategory());
    response.setDuration(projection.getDuration());

    Timestamp createdAt = projection.getCreatedAt();
    if (createdAt != null) {
      response.setCreatedAt(
          createdAt
              .toInstant()
              .atOffset(ZoneOffset.UTC)
              .atZoneSameInstant(ZoneId.systemDefault())
              .toOffsetDateTime());
    }
    return response;
  }
}
