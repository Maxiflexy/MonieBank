package com.digicore.omni.starter.lib.datasource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 12 Tue Aug, 2025
 */
public class CustomRoutingDataSource extends AbstractRoutingDataSource {
  @Override
  protected Object determineCurrentLookupKey() {
    DataSourceType dataSourceType = DataSourceContextHolder.get();
    return dataSourceType == null ? DataSourceType.PRIMARY : dataSourceType;
  }
}
