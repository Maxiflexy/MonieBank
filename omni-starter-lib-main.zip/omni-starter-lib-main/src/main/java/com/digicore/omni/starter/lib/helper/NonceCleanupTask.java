package com.digicore.omni.starter.lib.helper;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 02 Sun Feb, 2025
 */
@Component
@Slf4j
public class NonceCleanupTask {

  private final Map<String, Long> nonceStore = new ConcurrentHashMap<>();

  private static final long NONCE_EXPIRATION_MILLIS = 5 * 60 * 1000;

  public boolean isNonceUsed(String nonce) {
    cleanUp();
    return nonceStore.containsKey(nonce);
  }

  public void storeNonce(String nonce) {
    nonceStore.put(nonce, Instant.now().toEpochMilli());
  }

  private void cleanUp() {
    long now = Instant.now().toEpochMilli();
    nonceStore.entrySet().removeIf(entry -> (now - entry.getValue()) > NONCE_EXPIRATION_MILLIS);
  }
}
