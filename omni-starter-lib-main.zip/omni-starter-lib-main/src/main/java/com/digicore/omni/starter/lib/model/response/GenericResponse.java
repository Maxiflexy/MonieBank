package com.digicore.omni.starter.lib.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

/**
 * @author Onyekachi Ejemba
 * @createdOn Aug-18(Mon)-2025
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GenericResponse<T> {
  private String description;
  private String responseMessage;
  private boolean success;
  private T data;
  private Object metadata;
  private List<ApiError> errors;
}
