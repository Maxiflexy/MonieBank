package com.digicore.omni.starter.lib.model.entity.converter.enumeration;

import com.digicore.omni.starter.lib.model.entity.converter.StringEnumConverter;
import com.digicore.omni.starter.lib.model.enumeration.InviteStatus;
import jakarta.persistence.Converter;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 13 Mon Jan, 2025
 */
@Converter
public class InviteStatusConverter extends StringEnumConverter<InviteStatus> {
  public InviteStatusConverter() {
    super(InviteStatus.class);
  }
}
