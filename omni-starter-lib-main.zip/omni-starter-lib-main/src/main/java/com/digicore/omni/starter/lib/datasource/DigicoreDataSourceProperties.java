package com.digicore.omni.starter.lib.datasource;

import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 12 Tue Aug, 2025
 */
@Configuration
@ConditionalOnProperty(name = "omni.datasource.read-replica-enabled", havingValue = "true")
@ConfigurationProperties(prefix = "omni.datasource")
@Getter
@Setter
public class DigicoreDataSourceProperties {

  private Map<String, String> properties;
}
