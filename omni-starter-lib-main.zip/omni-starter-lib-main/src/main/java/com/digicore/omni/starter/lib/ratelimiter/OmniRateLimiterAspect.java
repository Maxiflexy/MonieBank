package com.digicore.omni.starter.lib.ratelimiter;

import static com.digicore.omni.starter.lib.constant.AppConstants.AUDIT_LOG_ACTOR_FIELD;

import com.digicore.omni.starter.lib.constant.AppConstants;
import com.digicore.omni.starter.lib.context.IExecutionContext;
import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.digicore.omni.starter.lib.helper.ClientHelper;
import jakarta.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class OmniRateLimiterAspect {

  private final HttpServletRequest request;
  private final IExecutionContext requestContext;
  private final RateLimiterConfig rateLimiterConfig;
  private final RedisTemplate<String, Object> redisTemplate;

  public OmniRateLimiterAspect(
      IExecutionContext requestContext,
      HttpServletRequest request,
      RateLimiterConfig rateLimiterConfig,
      RedisTemplate<String, Object> redisTemplate) {
    this.requestContext = requestContext;
    this.request = request;
    this.rateLimiterConfig = rateLimiterConfig;
    this.redisTemplate = redisTemplate;
  }

  @Around("@annotation(RateLimiter)")
  public Object rateLimited(ProceedingJoinPoint joinPoint) throws Throwable {
    MethodSignature signature = (MethodSignature) joinPoint.getSignature();
    Method method = signature.getMethod();

    var rateLimiter = method.getAnnotation(RateLimiter.class);
    var config = rateLimiterConfig.getRateLimiterConfig(rateLimiter.name());

    String key = getRateLimitKey(request, rateLimiter.name());

    String blacklistKey = "ratelimit:blacklist:" + key;

    if (isBlacklisted(blacklistKey)) {
      throw CommonExceptionOf.System.RateLimit.BLACK_LISTED.exception();
    }

    if (!isAllowed(key, blacklistKey, config)) {
      throw CommonExceptionOf.System.RateLimit.RATE_LIMIT_EXCEEDED.exception();
    }

    return joinPoint.proceed();
  }

  private String getRateLimitKey(HttpServletRequest request, String limiterName) {
    String key = request.getHeader("Authorization");

    if (key == null || key.isEmpty()) {

      String requestPayload = (String) request.getAttribute(AppConstants.DECRYPTED_REQUEST_BODY);

      String actor =
          ClientHelper.extractAuditActorField(
              requestPayload, (String) request.getAttribute(AUDIT_LOG_ACTOR_FIELD));
      if (StringUtils.isNotBlank(actor)) key = requestContext.getIpAddress() + "::" + actor;
      else key = requestContext.getIpAddress();
    }
    String hashed = DigestUtils.sha256Hex(key);

    return String.format("ratelimit:%s:%s", limiterName, hashed);
  }

  private boolean isAllowed(
      String key, String blacklistKey, RateLimiterConfig.RateLimiterConfigInstance config) {
    Long count = redisTemplate.opsForValue().increment(key);

    if (count == null) {
      log.warn("Rate limiter skipped — Redis unavailable for key {}", key);
      return true;
    }

    if (count == 1L) {
      redisTemplate.expire(key, config.getTimeWindow(), TimeUnit.SECONDS);
    }

    if (count > config.getBlackListThreshold()) {
      blacklist(blacklistKey, config.getBlackListDuration());
      log.warn(
          "Blacklisting key {} for {}s due to abuse", blacklistKey, config.getBlackListDuration());
      return false;
    }

    return count <= config.getMaxRequests();
  }

  private boolean isBlacklisted(String blacklistKey) {
    Boolean exists = redisTemplate.hasKey(blacklistKey);
    return exists != null && exists;
  }

  private void blacklist(String blacklistKey, int durationSecs) {
    redisTemplate.opsForValue().set(blacklistKey, "1", durationSecs, TimeUnit.SECONDS);
  }
}
