package com.digicore.omni.starter.lib.model.enumeration;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 01 Wed Oct, 2025
 */
public enum OtpFormat {
  NUMERIC,
  ALPHA_NUMERIC,
  ALPHA_NUMERIC_NO_SYMBOL,
  ALPHABET
}
