package com.digicore.omni.starter.lib.config;

import static com.digicore.omni.starter.lib.constant.AppConstants.APP_TRACE_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.CLAIM_KEY_CLIENT_TYPE;
import static com.digicore.omni.starter.lib.constant.AppConstants.MERCHANT_ID_HEADER;
import static com.digicore.omni.starter.lib.constant.AppConstants.TERMINAL_CLAIM_KEY_MERCHANT_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.TERMINAL_CLAIM_KEY_OUTLET_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.USER_CLAIM_KEY_MERCHANT_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.USER_CLAIM_KEY_ROLE;
import static com.digicore.omni.starter.lib.constant.AppConstants.USER_CLAIM_KEY_USERNAME;

import com.digicore.omni.starter.lib.context.IExecutionContext;
import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.digicore.omni.starter.lib.helper.ClientHelper;
import com.digicore.omni.starter.lib.model.enumeration.ClientType;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 30 Tue Sept, 2025
 */
@Slf4j
@Component
@RequestScope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@RequiredArgsConstructor
public class RequestContext implements IExecutionContext {

  public static final String X_TIMEZONE = "X-Timezone";
  protected final HttpServletRequest request;
  protected final HttpServletResponse response;

  @Override
  public String getMerchantId() {
    var clientType = getClientType();
    if (clientType == ClientType.MERCHANT) {
      return getJwtClaim(USER_CLAIM_KEY_MERCHANT_ID);
    } else if (clientType == ClientType.SERVICE) {
      return request.getHeader(MERCHANT_ID_HEADER);
    } else if (clientType == ClientType.TERMINAL) {
      return getJwtClaim(TERMINAL_CLAIM_KEY_MERCHANT_ID);
    }

    return null;
  }

  @Override
  public String getMerchantIdOrElseThrowErr() {
    var merchantId = getMerchantId();

    if (StringUtils.isBlank(merchantId)) {
      throw CommonExceptionOf.Business.BadRequest.MERCHANT_ID_REQUIRED_ON_HEADER.exception();
    }
    return merchantId;
  }

  @Override
  public String getOutletId() {
    var clientType = getClientType();

    if (clientType == ClientType.TERMINAL) {
      return getJwtClaim(TERMINAL_CLAIM_KEY_OUTLET_ID);
    }
    return null;
  }

  @Override
  public String getTerminalId() {
    var clientType = getClientType();

    if (clientType == ClientType.TERMINAL) {
      return getJwtClaim(USER_CLAIM_KEY_USERNAME);
    }
    return null;
  }

  @Override
  public String getUserId() {
    return getJwtClaim(USER_CLAIM_KEY_USERNAME);
  }

  @Override
  public String getIpAddress() {
    return ClientHelper.extractClientIp(request);
  }

  @Override
  public String getAppTraceId() {
    return MDC.get(APP_TRACE_ID);
  }

  @Override
  public String getTimeZoneOrDefault() {
    return getHeader(X_TIMEZONE).orElse("UTC");
  }

  @Override
  public String getRoleId() {
    return getJwtClaim(USER_CLAIM_KEY_ROLE);
  }

  public ClientType getClientType() {
    var clientType = getJwtClaim(CLAIM_KEY_CLIENT_TYPE);

    if (StringUtils.isBlank(clientType)) {
      return null;
    }

    return ClientType.valueOf(clientType);
  }

  private String getJwtClaim(String claimName) {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication != null && authentication.getPrincipal() instanceof Jwt jwt) {
      return jwt.getClaimAsString(claimName);
    }

    return null;
  }

  public Optional<String> getHeader(String headerName) {
    return Optional.ofNullable(request.getHeader(headerName));
  }
}
