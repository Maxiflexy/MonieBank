package com.digicore.omni.starter.lib.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 18 Fri Apr, 2025
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JsonStringWrapper {
  private String message;
}
