package com.digicore.omni.starter.lib.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 02 Sun Nov, 2025
 */
@Slf4j
public class OffsetDateTimeFlexibleDeserializer extends JsonDeserializer<OffsetDateTime> {

  private static final ZoneId DEFAULT_ZONE = ZoneId.systemDefault();

  private static final List<DateTimeFormatter> DATE_FORMATTERS =
      List.of(
          DateTimeFormatter.ofPattern("yyyy-MM-dd"),
          DateTimeFormatter.ofPattern("dd/MM/yyyy"),
          DateTimeFormatter.ofPattern("dd-MM-yyyy"),
          DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
          DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
          DateTimeFormatter.ofPattern("MM/dd/yyyy"),
          DateTimeFormatter.ofPattern("MM-dd-yyyy"),
          DateTimeFormatter.ISO_OFFSET_DATE_TIME,
          DateTimeFormatter.ISO_ZONED_DATE_TIME,
          DateTimeFormatter.ISO_INSTANT,
          DateTimeFormatter.ISO_LOCAL_DATE_TIME);

  @Override
  public OffsetDateTime deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
    String raw = p.getText();

    if (raw == null || raw.isBlank()) {
      return null;
    }

    raw = raw.trim();

    // ---------- 1. Parse Epoch (seconds or milliseconds) ----------
    if (raw.matches("^[0-9]+(\\.[0-9]+)?$")) {
      try {
        double doubleValue = Double.parseDouble(raw);

        Instant instant;
        if (doubleValue > 100000000000L) {
          // milliseconds (including decimal millis)
          instant = Instant.ofEpochMilli((long) doubleValue);
        } else {
          // seconds (including decimal seconds)
          long seconds = (long) doubleValue;
          long nanos = (long) ((doubleValue - seconds) * 1_000_000_000);
          instant = Instant.ofEpochSecond(seconds, nanos);
        }

        return instant.atZone(DEFAULT_ZONE).toOffsetDateTime();
      } catch (Exception ignored) {
      }
    }

    // ---------- 2. Normalize missing timezone offset ----------
    // "2025-10-01T00:00 01:00" → "2025-10-01T00:00+01:00"
    String normalized = raw.replaceAll(" (\\d{2}:\\d{2})$", "+$1");

    // ---------- 3. Parse Formats ----------
    for (DateTimeFormatter formatter : DATE_FORMATTERS) {
      log.info("Formatter: {}", formatter);
      log.info("Formatter: {}", DATE_FORMATTERS.indexOf(formatter));
      try {
        if (formatter == DateTimeFormatter.ISO_OFFSET_DATE_TIME
            || formatter == DateTimeFormatter.ISO_ZONED_DATE_TIME
            || formatter == DateTimeFormatter.ISO_INSTANT) {

          return OffsetDateTime.parse(normalized, formatter)
              .atZoneSameInstant(DEFAULT_ZONE)
              .toOffsetDateTime();
        }

        if (formatter == DateTimeFormatter.ISO_LOCAL_DATE_TIME
            || formatter.toString().contains("H")) {

          return LocalDateTime.parse(normalized, formatter).atZone(DEFAULT_ZONE).toOffsetDateTime();
        }

        // Date only
        LocalDate date = LocalDate.parse(normalized, formatter);
        return date.atStartOfDay(DEFAULT_ZONE).toOffsetDateTime();

      } catch (DateTimeParseException ignored) {
      }
    }

    // ---------- 4. Fail if no match ----------
    throw new IOException("Unable to parse date/time: " + raw);
  }
}
