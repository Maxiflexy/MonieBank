package com.digicore.omni.starter.lib.service.api;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 20 Mon Oct, 2025
 */
public enum OmniService {
  BACKOFFICE("backoffice"),
  MERCHANT("merchant"),
  TERMINAL("terminal"),
  TRANSACTION("transaction");

  private final String name;

  OmniService(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
