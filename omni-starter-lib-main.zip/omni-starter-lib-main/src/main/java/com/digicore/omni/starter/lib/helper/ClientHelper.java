package com.digicore.omni.starter.lib.helper;

import static com.digicore.omni.starter.lib.constant.AppConstants.APP_TRACE_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.TRUNCATION_SUFFIX;

import com.digicore.omni.starter.lib.constant.AppConstants;
import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.digicore.omni.starter.lib.model.response.ApiError;
import com.digicore.omni.starter.lib.model.response.ApiResponseJson;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.servlet.http.HttpServletRequest;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Entities;
import org.slf4j.MDC;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 17 Thu Apr, 2025
 */
@UtilityClass
@Slf4j
public class ClientHelper {

  public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
  public static final String X_FORWARDED_FOR_HEADER = "X-Forwarded-For";

  static {
    OBJECT_MAPPER
        .registerModules(
            new JavaTimeModule()
            //                        ,
            //                        new Jdk8Module()
            )
        .disable(SerializationFeature.FAIL_ON_EMPTY_BEANS)
        .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
        .writerWithDefaultPrettyPrinter();
  }

  public static String cleanForLog(String rawInput) {
    if (StringUtils.isBlank(rawInput)) {
      return "";
    } else {
      String cleaned = StringEscapeUtils.escapeHtml4(cleanString(rawInput));
      if (!rawInput.equals(cleaned)) {
        cleaned = cleaned + " (Encoded)";
      }

      return cleaned;
    }
  }

  private static String cleanString(String rawInput) {
    return rawInput.replace("\n", "_").replace("\r", "_");
  }

  public String extractClientIp(HttpServletRequest httpServletRequest) {
    HttpServletRequest request = httpServletRequest != null ? httpServletRequest : currentRequest();
    if (request == null) return "httpServletRequest not found";
    String forwardedFor = request.getHeader(X_FORWARDED_FOR_HEADER);
    if (forwardedFor != null && !forwardedFor.isBlank()) {
      return forwardedFor.split(",")[0].trim();
    }
    return request.getRemoteAddr();
  }

  public String getUserAgent(HttpServletRequest httpServletRequest) {
    HttpServletRequest request = httpServletRequest != null ? httpServletRequest : currentRequest();
    if (request == null) return "httpServletRequest not found";
    return Optional.ofNullable(request.getHeader("User-Agent")).orElse("unknown");
  }

  public String cleanHtmlToXhtml(String htmlContent) {
    Document document = Jsoup.parse(htmlContent);
    document
        .outputSettings()
        .syntax(Document.OutputSettings.Syntax.xml)
        .escapeMode(Entities.EscapeMode.xhtml)
        .charset(StandardCharsets.UTF_8)
        .prettyPrint(true);

    document.select("meta[charset]").attr("charset", "UTF-8");
    document.outputSettings().indentAmount(2);

    document.select("html").attr("xmlns", "http://www.w3.org/1999/xhtml");

    return document.toString();
  }

  public String getOrCreateAbsolutePath(String path) {
    File file = new File(path);
    if (!file.exists()) {
      boolean created = file.mkdirs();
      if (!created) {
        throw new IllegalStateException("Failed to create directory: " + file.getAbsolutePath());
      }
    } else if (!file.isDirectory()) {
      throw new IllegalStateException(
          "Path exists but is not a directory: " + file.getAbsolutePath());
    }
    return file.getAbsolutePath();
  }

  public ApiResponseJson buildResponse(
      Object responseData, String message, String description, boolean success) {
    return ApiResponseJson.builder()
        .success(success)
        .description(message)
        .responseMessage(message)
        .data(responseData)
        .traceId(MDC.get(APP_TRACE_ID))
        .metadata(null)
        .serviceCode(AppConstants.getInstance().getServiceCode())
        .errors(success ? Collections.emptyList() : List.of(new ApiError(message, "400", "")))
        .build();
  }

  private HttpServletRequest currentRequest() {
    RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();

    if (requestAttributes instanceof ServletRequestAttributes servletRequestAttributes) {
      return servletRequestAttributes.getRequest();
    }
    return null;
  }

  private String truncateJsonPayload(String jsonPayload, int maxLength) {
    if (StringUtils.isBlank(jsonPayload) || jsonPayload.length() <= maxLength) {
      return jsonPayload;
    }

    int availableLength = maxLength - TRUNCATION_SUFFIX.length();

    try {
      // Parse JSON into a generic map or list
      Object jsonNode = OBJECT_MAPPER.readValue(jsonPayload, Object.class);

      // Convert back to compact JSON and check length
      String compact = OBJECT_MAPPER.writeValueAsString(jsonNode);
      if (compact.length() <= maxLength) {
        return compact;
      }

      // 🟢 If still too long, recursively trim string values
      Object truncatedJson = trimJsonRecursively(jsonNode, availableLength);

      String result = OBJECT_MAPPER.writeValueAsString(truncatedJson);
      if (result.length() > availableLength) {
        result = result.substring(0, availableLength) + TRUNCATION_SUFFIX;
      }

      return result;
    } catch (Exception e) {
      // Fallback: cut safely by JSON boundaries
      String truncated = jsonPayload.substring(0, availableLength);
      int lastBrace = Math.max(truncated.lastIndexOf('}'), truncated.lastIndexOf(']'));
      if (lastBrace > availableLength * 0.5) {
        truncated = truncated.substring(0, lastBrace + 1);
      }
      return truncated + TRUNCATION_SUFFIX;
    }
  }

  /** Recursively shortens long string values inside a JSON map or list. */
  @SuppressWarnings("unchecked")
  private Object trimJsonRecursively(Object node, int maxTotalLength) {
    if (node instanceof Map<?, ?> map) {
      Map<String, Object> copy = new LinkedHashMap<>();
      for (var entry : map.entrySet()) {
        Object value = entry.getValue();
        if (value instanceof String str && str.length() > 100) {
          copy.put(String.valueOf(entry.getKey()), str.substring(0, 100) + TRUNCATION_SUFFIX);
        } else {
          copy.put(String.valueOf(entry.getKey()), trimJsonRecursively(value, maxTotalLength));
        }
      }
      return copy;
    } else if (node instanceof List<?> list) {
      List<Object> truncatedList = new ArrayList<>();
      for (Object item : list) {
        truncatedList.add(trimJsonRecursively(item, maxTotalLength));
      }
      return truncatedList;
    }
    return node;
  }

  /** Simple heuristic to detect JSON-like content */
  private boolean isJsonLike(String payload) {
    String trimmed = payload.trim();
    return (trimmed.startsWith("{") && trimmed.endsWith("}"))
        || (trimmed.startsWith("[") && trimmed.endsWith("]"));
  }

  /** Truncates payload to specified maximum length while preserving JSON structure when possible */
  public String truncatePayload(String payload, int maxLength) {
    if (StringUtils.isBlank(payload) || payload.length() <= maxLength) {
      return payload;
    }

    // For JSON payloads, try to preserve structure
    if (isJsonLike(payload)) {
      return truncateJsonPayload(payload, maxLength);
    }

    try {
      JsonNode node = OBJECT_MAPPER.readTree(payload);

    } catch (Exception e) {
    }

    // Simple truncation for non-JSON
    return payload.substring(0, maxLength - TRUNCATION_SUFFIX.length()) + TRUNCATION_SUFFIX;
  }

  public String extractAuditActorField(String payload, String actorField) {
    if (payload == null || payload.isBlank() || actorField == null) {
      return null;
    }

    try {
      JsonNode rootNode = ClientHelper.OBJECT_MAPPER.readTree(payload);

      List<String> priorityLocations = Arrays.asList("body", "parameters", "pathVariables");

      for (String location : priorityLocations) {
        JsonNode targetNode = rootNode.path(location).path(actorField);

        if (!targetNode.isMissingNode() && !targetNode.isNull()) {
          return targetNode.asText();
        }
      }

      JsonNode rootTarget = rootNode.path(actorField);
      if (!rootTarget.isMissingNode() && !rootTarget.isNull()) {
        return rootTarget.asText();
      }

    } catch (Exception e) {
      log.debug("Failed to extract actor field '{}' from payload: {}", actorField, e.getMessage());
    }

    return null;
  }

  public String formatNigerianPhoneNumber(String phoneNumber) {

    if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
      return phoneNumber;
    }

    // Remove all non-digit characters (spaces, +, -, etc.)
    String digitsOnly = phoneNumber.replaceAll("\\D", "");

    // Validate length
    if (digitsOnly.length() < 10) {
      log.error("Phone number has less than 10 digits: {}", phoneNumber);
      throw CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception(
          "Invalid phone number format");
    }

    // Nigerian phone numbers typically have 10 digits after the leading 0 or country code
    String last10Digits = digitsOnly.substring(digitsOnly.length() - 10);

    return "+234" + last10Digits;
  }
}
