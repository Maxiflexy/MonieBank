package com.digicore.omni.starter.lib.model.response;

import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.Setter;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 12 Sun Jan, 2025
 */
@Getter
@Setter
public class BaseResponse {

  private String id;

  private OffsetDateTime version;

  private OffsetDateTime createdAt;

  private OffsetDateTime updatedAt;

  private Boolean deleted;

  private String createdBy;

  private String createdByName;

  private String updatedBy;

  private String updatedByName;
}
