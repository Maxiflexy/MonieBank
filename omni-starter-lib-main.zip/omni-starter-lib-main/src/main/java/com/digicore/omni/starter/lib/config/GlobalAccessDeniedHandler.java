package com.digicore.omni.starter.lib.config;

import com.digicore.omni.starter.lib.helper.ClientHelper;
import com.digicore.omni.starter.lib.helper.RequestResponseEncryptionHelper;
import com.digicore.omni.starter.lib.model.response.ApiResponseJson;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 05 Tue Aug, 2025
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class GlobalAccessDeniedHandler implements AccessDeniedHandler {

  private final RequestResponseEncryptionHelper requestResponseEncryptionHelper;

  @Override
  public void handle(
      HttpServletRequest request,
      HttpServletResponse response,
      AccessDeniedException accessDeniedException) {

    try {
      log.error(
          "Access denied for path: {}, message: {}",
          request.getRequestURI(),
          accessDeniedException.getMessage());

      ApiResponseJson body = new ApiResponseJson("403", accessDeniedException.getMessage());

      response.setContentType("application/json");
      response.setStatus(HttpServletResponse.SC_FORBIDDEN);
      String responseBody = ClientHelper.OBJECT_MAPPER.writeValueAsString(body);

      response
          .getWriter()
          .write(requestResponseEncryptionHelper.prepareEncryptedResponse(responseBody));
    } catch (Exception e) {
      log.info("Excep: {}", e.getMessage());
    }
  }
}
