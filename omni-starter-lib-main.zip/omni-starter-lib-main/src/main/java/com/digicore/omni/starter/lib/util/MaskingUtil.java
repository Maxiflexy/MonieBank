package com.digicore.omni.starter.lib.util;

import java.util.regex.Pattern;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 02 Thu Oct, 2025
 */
public class MaskingUtil {

  private static final Pattern EMAIL_PATTERN =
      Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

  private static final Pattern PHONE_PATTERN = Pattern.compile("^\\+?[0-9]{10,15}$");

  /**
   * Masks an email address Examples: - john.doe@example.com -> j***e@example.com - ab@test.com ->
   * a*@test.com - a@test.com -> a*@test.com
   */
  public static String maskEmail(String email) {
    if (email == null || email.isBlank()) {
      return email;
    }

    if (!EMAIL_PATTERN.matcher(email).matches()) {
      return email; // Return as-is if not valid email
    }

    String[] parts = email.split("@");
    if (parts.length != 2) {
      return email;
    }

    String localPart = parts[0];
    String domain = parts[1];

    String maskedLocal = maskLocalPart(localPart);
    return maskedLocal + "@" + domain;
  }

  /**
   * Masks phone number Examples: - +2348012345678 -> +234***5678 - 08012345678 -> 080***5678 -
   * +14155552671 -> +141***2671
   */
  public static String maskPhone(String phone) {
    if (phone == null || phone.isBlank()) {
      return phone;
    }

    // Remove spaces and dashes for validation
    String cleanPhone = phone.replaceAll("[\\s-]", "");

    if (!PHONE_PATTERN.matcher(cleanPhone).matches()) {
      return phone; // Return as-is if not valid phone
    }

    // Keep first 3-4 chars and last 4 chars, mask middle
    int length = cleanPhone.length();

    if (length <= 6) {
      return cleanPhone.charAt(0) + "***" + cleanPhone.charAt(length - 1);
    }

    // For international format (+234...)
    if (cleanPhone.startsWith("+")) {
      if (length <= 8) {
        return cleanPhone.substring(0, 4) + "***" + cleanPhone.substring(length - 2);
      }
      return cleanPhone.substring(0, 4) + "***" + cleanPhone.substring(length - 4);
    }

    // For local format (080...)
    if (length <= 8) {
      return cleanPhone.substring(0, 3) + "***" + cleanPhone.substring(length - 2);
    }
    return cleanPhone.substring(0, 3) + "***" + cleanPhone.substring(length - 4);
  }

  /** Masks the local part of email (before @) */
  private static String maskLocalPart(String localPart) {
    if (localPart.length() <= 1) {
      return localPart + "*";
    }

    if (localPart.length() == 2) {
      return localPart.charAt(0) + "*";
    }

    if (localPart.length() <= 4) {
      return localPart.charAt(0) + "***" + localPart.charAt(localPart.length() - 1);
    }

    // For longer emails, show first char, mask middle, show last char
    return localPart.charAt(0)
        + "*".repeat(Math.min(localPart.length() - 2, 5))
        + localPart.charAt(localPart.length() - 1);
  }

  /** Masks either email or phone based on input format */
  public static String maskContact(String contact) {
    if (contact == null || contact.isBlank()) {
      return contact;
    }

    if (contact.contains("@")) {
      return maskEmail(contact);
    }

    return maskPhone(contact);
  }

  /** Masks a name (useful for logs) Example: John Doe -> J*** D*** */
  public static String maskName(String name) {
    if (name == null || name.isBlank()) {
      return name;
    }

    String[] parts = name.trim().split("\\s+");
    StringBuilder masked = new StringBuilder();

    for (int i = 0; i < parts.length; i++) {
      String part = parts[i];
      if (part.length() > 0) {
        masked.append(part.charAt(0)).append("***");
        if (i < parts.length - 1) {
          masked.append(" ");
        }
      }
    }

    return masked.toString();
  }

  /** Masks BVN (Bank Verification Number) Example: 12345678901 -> 123***901 */
  public static String maskBVN(String bvn) {
    if (bvn == null || bvn.isBlank()) {
      return bvn;
    }

    if (bvn.length() != 11) {
      return "***"; // Invalid BVN
    }

    return bvn.substring(0, 3) + "***" + bvn.substring(8);
  }

  /** Masks account number Example: 1234567890 -> 123***890 */
  public static String maskAccountNumber(String accountNumber) {
    if (accountNumber == null || accountNumber.isBlank()) {
      return accountNumber;
    }

    int length = accountNumber.length();

    if (length <= 6) {
      return accountNumber.substring(0, 2) + "***";
    }

    return accountNumber.substring(0, 3) + "***" + accountNumber.substring(length - 3);
  }

  /** Masks card number (PAN) Example: 1234567890123456 -> 1234 **** **** 3456 */
  public static String maskCardNumber(String cardNumber) {
    if (cardNumber == null || cardNumber.isBlank()) {
      return cardNumber;
    }

    String cleaned = cardNumber.replaceAll("[\\s-]", "");

    if (cleaned.length() < 12 || cleaned.length() > 19) {
      return "****";
    }

    return cleaned.substring(0, 4) + " **** **** " + cleaned.substring(cleaned.length() - 4);
  }
}
