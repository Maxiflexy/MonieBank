package com.digicore.omni.starter.lib.filter;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 18 Fri Apr, 2025
 */
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;

public interface SubWebFilter {
  void filter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws ServletException, IOException;
}
