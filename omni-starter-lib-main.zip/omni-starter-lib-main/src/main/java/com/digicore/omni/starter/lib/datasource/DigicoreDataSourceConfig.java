package com.digicore.omni.starter.lib.datasource;

import com.zaxxer.hikari.HikariDataSource;
import jakarta.persistence.EntityManagerFactory;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 12 Tue Aug, 2025
 */
@Configuration
@AllArgsConstructor
@ConditionalOnProperty(name = "omni.datasource.read-replica-enabled", havingValue = "true")
@EnableJpaRepositories(
    basePackages = "com.digicore",
    entityManagerFactoryRef = "digicoreDBEntityManagerFactory",
    transactionManagerRef = "digicoreDBTransactionManager")
@EntityScan(basePackages = "com.digicore")
public class DigicoreDataSourceConfig {

  private final DigicoreDataSourceProperties digicoreDataSourceProperties;

  @Bean(name = "routingDataSource")
  @Primary
  public DataSource routingDataSource(
      @Qualifier("primaryDataSource") DataSource main,
      @Qualifier("replicaDataSource") DataSource replica) {
    Map<Object, Object> targets = new HashMap<>();
    targets.put(DataSourceType.PRIMARY, main);
    targets.put(DataSourceType.READ_REPLICA, replica);

    CustomRoutingDataSource routingDataSource = new CustomRoutingDataSource();
    routingDataSource.setDefaultTargetDataSource(main);
    routingDataSource.setTargetDataSources(targets);

    return routingDataSource;
  }

  @Bean(name = "primaryDataSource")
  @ConfigurationProperties(prefix = "omni.datasource.sources.primary")
  public DataSource primaryDataSource() {
    var dataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
    var isolation =
        digicoreDataSourceProperties
            .getProperties()
            .getOrDefault("hikari.transaction-isolation", "TRANSACTION_READ_COMMITTED");
    dataSource.setTransactionIsolation(isolation);

    return dataSource;
  }

  @Bean(name = "replicaDataSource")
  @ConfigurationProperties(prefix = "omni.datasource.sources.read-replica")
  public DataSource replicaDataSource() {
    var dataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
    var isolation =
        digicoreDataSourceProperties
            .getProperties()
            .getOrDefault("hikari.transaction-isolation", "TRANSACTION_READ_COMMITTED");
    dataSource.setTransactionIsolation(isolation);

    return dataSource;
  }

  @Bean(name = "digicoreDBEntityManagerFactory")
  @Primary
  public LocalContainerEntityManagerFactoryBean digicoreDBEntityManagerFactory(
      EntityManagerFactoryBuilder builder,
      @Qualifier("routingDataSource") DataSource routingDataSource) {

    return builder
        .dataSource(routingDataSource)
        .packages("com.digicore")
        .properties(digicoreDataSourceProperties.getProperties())
        .build();
  }

  @Bean(name = "digicoreDBTransactionManager")
  @Primary
  public PlatformTransactionManager digicoreDBTransactionManager(
      @Qualifier("digicoreDBEntityManagerFactory") EntityManagerFactory emf) {

    return new JpaTransactionManager(emf);
  }

  @Bean(name = "digicoreDBJdbcTemplate")
  @Primary
  public JdbcTemplate digicoreDBJdbcTemplate(
      @Qualifier("routingDataSource") DataSource routingDataSource) {

    return new JdbcTemplate(routingDataSource);
  }
}
