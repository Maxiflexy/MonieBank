package com.digicore.omni.starter.lib.filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 02 Tue Sept, 2025
 */
@RequiredArgsConstructor
@Slf4j
@Component
public class CompositeWebFilter implements Filter, Ordered {

  private final List<SubWebFilter> subFilters;

  @Override
  public int getOrder() {
    return 2;
  }

  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws IOException, ServletException {

    request.setAttribute("startTime", String.valueOf(System.currentTimeMillis()));
    // Build composed chain of subfilters
    FilterChain composedChain = chain;
    for (SubWebFilter subFilter : reverse(subFilters)) {
      FilterChain finalChain = composedChain;
      composedChain = (req, res) -> subFilter.filter(req, res, finalChain);
    }
    composedChain.doFilter(request, response);
  }

  private List<SubWebFilter> reverse(List<SubWebFilter> list) {
    List<SubWebFilter> reversed = new ArrayList<>(list);
    java.util.Collections.reverse(reversed);
    return reversed;
  }
}
