package com.digicore.omni.starter.lib.service.api;

import static com.digicore.omni.starter.lib.constant.AppConstants.CLAIM_KEY_AUDIENCE;
import static com.digicore.omni.starter.lib.constant.AppConstants.CLAIM_KEY_CLIENT_TYPE;
import static com.digicore.omni.starter.lib.constant.AppConstants.CLAIM_KEY_SERVICE_CODE;
import static com.digicore.omni.starter.lib.constant.AppConstants.TERMINAL_CLAIM_KEY_MERCHANT_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.TERMINAL_CLAIM_KEY_OUTLET_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.USER_CLAIM_KEY_MERCHANT_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.USER_CLAIM_KEY_USERNAME;
import static com.digicore.omni.starter.lib.constant.AppConstants.USER_CLAIM_KEY_USER_ID;

import com.digicore.omni.starter.lib.constant.SystemConfigKeyConstant;
import com.digicore.omni.starter.lib.context.IExecutionContext;
import com.digicore.omni.starter.lib.contract.ConfigInitializer;
import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.digicore.omni.starter.lib.model.enumeration.ClientType;
import io.jsonwebtoken.Jwts;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import java.util.HashMap;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 20 Mon Oct, 2025
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ServiceTokenHelper {

  @Value(
      "${omni.token.secret-key:MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDuEXjPE+jqaU/Zqw0fjyHckKzXggaf9acj+2kTgCcFgh5RVKJegufil3Y6LgkTFkDMSgR4/TcbkYEI1MwC5lKeVsfsDjqfCTGCY8hvfAeAWaDgOkmiT0Uzl20bON2oCVHmue0/kPZPAD2NRNWqOsnI9puo8t+YdQglAYf3QhS7yH4bdNUIbK+irpxPiSOSXwF1YkjXF6Revyo/GePWtO0YcRVBu5K4d5y5/Uk0HINkvisgMrgiOZe4y2SEWhoooGfeB3f0JeFufTMOZeuDINZbl2ksI7LS+tazX+dsQXen5uv6gu/8bahBwnvYTkNZULdko/ZXvD+PjWl26v31wi/lAgMBAAECggEAaNulPIBmfKk6FIO02guvPHk0yA9rX5VRsxWPaJlvlouDUwtWIQ7DmBhiaKnSMWgBznljku7lEO17yioAWd6c0UUj9aMmytm/xtCwffpBS5UuuNSzjhwgPOMbmXvolZTVUCzghLkS5CUU9140RjBypGOKmFWxinMxzSrpekzO2Q5ScUOct5mAkB3mjKTgrKisSOoisw96vSTxmso6wR7XTIhmuStRlhBf1REC76Ms+b/4x5VQnaOPQE2E+s7T1dgTZXEBwrZ4m9d4bVF+F3YQZnbIJCpNbLF3Rq5jcG+oi5gZKcqxO1R/KRIUyW3ebov9NaugehVic46FRedTosMLGQKBgQD/vDAoKwZ3XMAqPF8JsRKn58stRyXuaEOdNvwzcL78S36qzfSF3vTAvZBTKOMyO+ueSfCnUBR/7f5IF70uaZu3w44m6c3EPuVf9SzLZSlvBcVkcJyXrsUsG4sWn/v3nIQHvMTJrcj0tkPnCu2PKeBLXTGM6QKnkOIJ966TqXq7jwKBgQDuUJljUOJBDnIRIvkrnw5MBffrm7PK0O+ZKpAdhdsMI5hxJJk/CJFwrm2QbAzGDoKIg1YNvm/4oRgpxwVVawQb/CPLkixPLyGWJZGjk4JN6cpweimZeWSm/bvt6jzM3uDM/SCwJGnl/j4gM+R98QS5a1E5cDveQs6OX1tn9LRzSwKBgQCMwx/arDwF7VaUqOBC7GVxaCOsi3H0dQ1qdr6A7fkh08gn6e9C1ILxqCXNsD7GArdhTB+baHewJuaE9hQafOTKVGhlQOISt+/3TnNWjRsuUgXhkB6RWxCKg6qeTHcbRtphi+ThgbeQAtcDUD+MQqeDtAs3HXZpl1Tj2aINAwdcPwKBgQCgZTTnqE+vc5aIPB6yIkpQFpBHTjNTJQ6t6vy2Mho88FQwim5uA0lIKs3pLx/lyWxHjwXDGFJqZ5pIu/+1/uH0J967q7UQ0mrrkHuWObiw0dKDo2UOO6rnzczHkyi6xqNMtG1kwA1aU6TirapyrV39oeI4I3bX3+T/4+Q0cnllQwKBgGOwDh23beRX8wJLfiz3/voP4g6B4tEP4+liq5HQz+4AFfXLQWqLDnfHHd+NrAINpPgz5dDh77v/0HliIIeecctabrhzsI5Pi8lSYzVrgeq0aXNIJpWV593Tzo0oWg/B4DpEntk+tyCS0QN68noLuR4g7kX4ptguQPW2z1WSqNfo}")
  private String privateKeyStr;

  @Value("${omni.service.code}")
  private String serviceCode;

  @Autowired IExecutionContext executionContext;

  private final ConfigInitializer configInitializer;

  public String generateInternalServiceToken() {
    return generateInternalServiceToken(
        executionContext.getMerchantId(),
        executionContext.getUserId(),
        executionContext.getOutletId(),
        executionContext.getTerminalId());
  }

  public String generateInternalServiceToken(
      String merchantId, String userId, String outletId, String terminalId) {

    var claims = new HashMap<String, Object>();
    claims.put(CLAIM_KEY_CLIENT_TYPE, ClientType.SERVICE.name());
    claims.put(CLAIM_KEY_SERVICE_CODE, serviceCode);
    claims.put(USER_CLAIM_KEY_USER_ID, userId);
    claims.put(
        CLAIM_KEY_AUDIENCE,
        configInitializer
            .configCache()
            .get(SystemConfigKeyConstant.OAUTH_RESOURCE_SERVER_RESOURCE_ID));

    if (StringUtils.isNotBlank(merchantId)) {
      claims.put(USER_CLAIM_KEY_MERCHANT_ID, merchantId);
      claims.put(TERMINAL_CLAIM_KEY_MERCHANT_ID, merchantId);
    }

    if (StringUtils.isNotBlank(outletId)) {
      claims.put(TERMINAL_CLAIM_KEY_OUTLET_ID, outletId);
    }

    if (StringUtils.isNotBlank(terminalId)) {
      claims.put(USER_CLAIM_KEY_USERNAME, outletId);
    }

    return Jwts.builder()
        .claims(claims)
        .issuedAt(new Date())
        .signWith(getSigningKey(), Jwts.SIG.RS256)
        .compact();
  }

  @SneakyThrows
  private PrivateKey getSigningKey() {
    try {
      var privateKeyBytes = Base64.decodeBase64(privateKeyStr);
      var keySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
      var keyFactory = KeyFactory.getInstance("RSA");
      return keyFactory.generatePrivate(keySpec);
    } catch (Exception e) {
      throw CommonExceptionOf.System.InternalError.SERVER_ERROR.exception(
          "Failed to get private key", e);
    }
  }
}
