package com.digicore.omni.starter.lib.exception;

import com.digicore.omni.starter.lib.constant.AppConstants;
import lombok.EqualsAndHashCode;
import lombok.Getter;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 31 Tue Dec, 2024
 */
@Getter
@EqualsAndHashCode(callSuper = false)
public class RequestException extends RuntimeException {

  private final String code;
  private final String actualMessage;
  private final String serviceCode;

  public RequestException(ExceptionCode exceptionCode) {
    super(
        exceptionCode.getCode().startsWith("5")
            ? CommonExceptionOf.System.InternalError.SERVER_ERROR.getMessage()
            : exceptionCode.getMessage());

    this.code = exceptionCode.getCode();
    this.actualMessage = exceptionCode.getMessage();
    this.serviceCode = AppConstants.getInstance().getServiceCode();
  }

  public RequestException(ExceptionCode exceptionCode, Throwable cause) {
    super(
        exceptionCode.getCode().startsWith("5")
            ? CommonExceptionOf.System.InternalError.SERVER_ERROR.getMessage()
            : exceptionCode.getMessage(),
        cause);

    this.code = exceptionCode.getCode();
    this.actualMessage = exceptionCode.getMessage();
    this.serviceCode = AppConstants.getInstance().getServiceCode();
  }
}
