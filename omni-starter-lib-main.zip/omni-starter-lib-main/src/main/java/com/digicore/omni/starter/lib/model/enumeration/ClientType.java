package com.digicore.omni.starter.lib.model.enumeration;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 02 Thu Jan, 2025
 */
public enum ClientType {
  BACKOFFICE,
  MERCHANT,
  TERMINAL,
  SERVICE;
}
