package com.digicore.omni.starter.lib.constant;

import jakarta.annotation.PostConstruct;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 17 Thu Apr, 2025
 */
@Component
public class AppConstants {

  @Getter
  @Value("${omni.service.code:}")
  private String serviceCode;

  @Getter
  @Value("${omni.service.name:}")
  private String serviceName;

  @Getter private static AppConstants instance;

  public static final String APP_TRACE_ID = "appTraceId";

  public static final String AGENT = "agent";
  public static final String CLIENT_IP = "clientIp";

  public static final String MERCHANT_ID_HEADER = "merchant-id";
  public static final String CLIENT_TYPE_FILTER_ATTRIBUTE = "clientTypeFilterAttribute";
  public static final String AUDIT_LOG_ACTION = "auditLogAction";
  public static final String AUDIT_LOG_ACTOR_FIELD = "auditLogActorField";
  public static final String AUDIT_LOG_ACTOR_FIELD_VALUE = "auditLogActorFieldValue";
  public static final String AUDIT_LOG_TRUNCATED_REQ = "auditLogTruncatedReq";
  public static final String AUDIT_LOG_TRUNCATED_RES = "auditLogTruncatedRes";
  public static final String USER_ID_HEADER = "user-id";
  public static final String OUTLET_ID_HEADER = "outlet-id";
  public static final String TERMINAL_ID_HEADER = "terminal-id";

  public static final String CLAIM_KEY_USERNAME = "user-name";
  public static final String USER_CLAIM_KEY_USER_ID = "userId";
  public static final String USER_CLAIM_KEY_MERCHANT_ID = "merchantId";
  public static final String CLAIM_KEY_USER_ID = "user-id";
  public static final String CLAIM_KEY_SERVICE_CODE = "service-code";
  public static final String CLAIM_KEY_CLIENT_TYPE = "clientType";
  public static final String CLAIM_KEY_AUDIENCE = "aud";

  public static final String USER_CLAIM_KEY_USERNAME = "user_name";

  public static final String USER_CLAIM_KEY_ROLE = "r_id";

  public static final String TERMINAL_CLAIM_KEY_TERMINAL_ID = "terminalId";
  public static final String TERMINAL_CLAIM_KEY_OUTLET_ID = "outletId";
  public static final String TERMINAL_CLAIM_KEY_MERCHANT_ID = "merchantId";

  // Filters
  public static final String DECRYPTED_REQUEST_BODY = "DECRYPTED_REQUEST_BODY";
  public static final String DECRYPTED_RESPONSE_BODY = "DECRYPTED_RESPONSE_BODY";

  public static final int MAX_REQUEST_PAYLOAD_LENGTH = 1000; // 0.5KB
  public static final int MAX_RESPONSE_PAYLOAD_LENGTH = 1000; // 0.5KB
  public static final String TRUNCATION_SUFFIX = "... [TRUNCATED]";

  @PostConstruct
  public void init() {
    instance = this;
  }
}
