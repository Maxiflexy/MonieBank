package com.digicore.omni.starter.lib.service;

import static com.digicore.omni.starter.lib.constant.AppConstants.AGENT;
import static com.digicore.omni.starter.lib.constant.AppConstants.APP_TRACE_ID;
import static com.digicore.omni.starter.lib.constant.AppConstants.CLIENT_IP;
import static com.digicore.omni.starter.lib.constant.AppConstants.MAX_REQUEST_PAYLOAD_LENGTH;
import static com.digicore.omni.starter.lib.constant.AppConstants.MAX_RESPONSE_PAYLOAD_LENGTH;

import com.digicore.omni.starter.lib.helper.ClientHelper;
import com.digicore.omni.starter.lib.model.entity.AuditLog;
import com.digicore.omni.starter.lib.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 07 Tue Oct, 2025
 */
@RequiredArgsConstructor
@Service
@Slf4j
public class AuditService {

  private final AuditLogRepository auditLogRepository;

  public void logInternalAction(
      String action,
      String actor,
      boolean success,
      Object request,
      Object response,
      long executionTime,
      String methodName) {

    AuditLog auditLog = new AuditLog();
    auditLog.setAction(action);
    auditLog.setActorId(actor);
    auditLog.setActor(actor);
    auditLog.setSuccess(success);
    auditLog.setRequestId(MDC.get(APP_TRACE_ID));
    auditLog.setUserAgent(MDC.get(AGENT));
    auditLog.setClientIp(MDC.get(CLIENT_IP));

    String serializedReq =
        ClientHelper.truncatePayload(serialize(request), MAX_REQUEST_PAYLOAD_LENGTH);
    //        if (serializedReq != null && serializedReq.length() > 500) {
    //            serializedReq = serializedReq.substring(0, 500) + "...";
    //        }
    auditLog.setRequestBody(serializedReq);

    String serializedRes =
        ClientHelper.truncatePayload(serialize(response), MAX_RESPONSE_PAYLOAD_LENGTH);
    //        if (serializedRes != null && serializedRes.length() > 500) {
    //            serializedRes = serializedRes.substring(0, 500) + "...";
    //        }
    auditLog.setResponseBody(serializedRes);
    auditLog.setDuration(String.valueOf(executionTime / 1000.0));
    auditLog.setRequestMethod(methodName);
    auditLog.setRequestPath(methodName);
    auditLog.setLatencyCategory(classifyLatency(executionTime));
    auditLog.setRequestSize(serializedReq != null ? serializedReq.length() : 0L);
    auditLog.setResponseSize(serializedRes != null ? serializedRes.length() : 0L);

    auditLogRepository.save(auditLog);
  }

  private String serialize(Object obj) {
    try {
      return obj == null ? null : ClientHelper.OBJECT_MAPPER.writeValueAsString(obj);
    } catch (Exception e) {
      return "SerializationError: " + e.getMessage();
    }
  }

  private String classifyLatency(long durationMs) {
    if (durationMs < 500) return "SUPER_FAST";
    else if (durationMs < 3000) return "FAST";
    else if (durationMs < 5000) return "NORMAL";
    else if (durationMs < 15000) return "SLOW";
    else return "VERY_SLOW";
  }
}
