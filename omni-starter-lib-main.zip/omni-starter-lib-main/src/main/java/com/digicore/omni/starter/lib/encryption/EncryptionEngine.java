package com.digicore.omni.starter.lib.encryption;

import org.apache.commons.lang3.tuple.Pair;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 17 Thu Apr, 2025
 */
public interface EncryptionEngine {

  String algorithmName();

  String encrypt(String clearData, String secretKey) throws Exception;

  String decrypt(String cipher, String secretKey) throws Exception;

  Pair<String, String> generateKey() throws Exception;
}
