package com.digicore.omni.starter.lib.util;

import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.opencsv.CSVReader;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvException;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.core.io.InputStreamResource;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 24 Mon Feb, 2025
 */
@Slf4j
public class CsvUtil {

  public static <R> Pair<String, InputStreamResource> exportToCsv(
      Class<R> csvModelClass,
      String fileTitleName,
      OffsetDateTime startDate,
      OffsetDateTime endDate,
      Consumer<StatefulBeanToCsv<R>> writeData) {

    try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintWriter writer = new PrintWriter(outputStream)) {

      String headerLine = CsvUtil.getHeaderLine(csvModelClass);
      writer.println(headerLine);

      StatefulBeanToCsv<R> beanToCsv =
          new StatefulBeanToCsvBuilder<R>(writer)
              .withApplyQuotesToAll(false)
              .withOrderedResults(true)
              .build();

      writeData.accept(beanToCsv);

      writer.flush();
      InputStreamResource resource =
          new InputStreamResource(new ByteArrayInputStream(outputStream.toByteArray()));
      String fileName = CsvUtil.getDefaultDateFileName(fileTitleName, startDate, endDate);

      return Pair.of(fileName, resource);
    } catch (IOException e) {
      throw CommonExceptionOf.System.InternalError.SERVER_ERROR.exception(e);
    }
  }

  public static <T> String getHeaderLine(Class<T> type) {
    return Arrays.stream(type.getDeclaredFields())
        .map(
            field -> {
              CsvBindByName annotation = field.getAnnotation(CsvBindByName.class);
              return (annotation != null) ? annotation.column() : field.getName();
            })
        .collect(Collectors.joining(","));
  }

  public static String getDefaultDateFileName(
      String fileName, OffsetDateTime startDate, OffsetDateTime endDate) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    if (startDate == null || endDate == null) {
      return String.format("%s-%s", fileName, OffsetDateTime.now().format(formatter));
    }
    return String.format(
        "%s-%s-%s", fileName, startDate.format(formatter), endDate.format(formatter));
  }

  public static <T> List<T> parseCsvToBean(MultipartFile file, Class<T> csvModelClass) {
    try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {

      CsvToBean<T> csvToBean =
          new CsvToBeanBuilder<T>(reader)
              .withType(csvModelClass)
              .withIgnoreLeadingWhiteSpace(true)
              .build();

      return csvToBean.parse();
    } catch (IOException e) {
      throw CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception();
    }
  }

  public static void parseCsvAdaptive(
      MultipartFile file, Consumer<Map<String, String>> rowProcessor)
      throws IOException, CsvException {
    int SMALL_CSV_THRESHOLD = 1000; // Define a threshold for small CSVs

    try (CSVReader reader = new CSVReader(new InputStreamReader(file.getInputStream()))) {
      List<String[]> rows = reader.readAll();

      String[] headers = rows.remove(0); // First row is headers

      if (rows.isEmpty())
        throw CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception("CSV file is empty!");

      // ✅ Filter out empty rows
      rows.removeIf(CsvUtil::isEmptyRow);

      if (rows.size() <= SMALL_CSV_THRESHOLD) {
        // Small CSV: Use parallel stream (lightweight)
        rows.parallelStream().forEach(row -> processRow(headers, row, rowProcessor));
      } else {
        // Large CSV: Use ExecutorService (better memory control)
        processCsvWithThreadPool(headers, rows, rowProcessor);
      }
    }
  }

  public static void parseCsvAdaptive(
      InputStream fileInputStream, Consumer<Map<String, String>> rowProcessor)
      throws IOException, CsvException {
    int SMALL_CSV_THRESHOLD = 1000; // Define a threshold for small CSVs

    try (CSVReader reader = new CSVReader(new InputStreamReader(fileInputStream))) {
      List<String[]> rows = reader.readAll();

      String[] headers = rows.remove(0); // First row is headers

      if (rows.isEmpty())
        throw CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception("CSV file is empty!");

      // ✅ Filter out empty rows
      rows.removeIf(CsvUtil::isEmptyRow);

      if (rows.size() <= SMALL_CSV_THRESHOLD) {
        // Small CSV: Use parallel stream (lightweight)
        rows.parallelStream().forEach(row -> processRow(headers, row, rowProcessor));
      } else {
        // Large CSV: Use ExecutorService (better memory control)
        processCsvWithThreadPool(headers, rows, rowProcessor);
      }
    }
  }

  public static void parseCsvAdaptive(String filePath, Consumer<Map<String, String>> rowProcessor)
      throws IOException, CsvException {

    int SMALL_CSV_THRESHOLD = 1000; // Define a threshold for small CSVs
    File file = new File(filePath);

    try (CSVReader reader = new CSVReader(new FileReader(file))) {
      List<String[]> rows = new ArrayList<>();
      String[] headers = reader.readNext(); // Read header row

      if (headers == null) throw new IllegalArgumentException("CSV file is empty!");

      String[] row;
      while ((row = reader.readNext()) != null) {
        if (!isEmptyRow(row)) {
          rows.add(row);
        }
      }

      if (rows.size() <= SMALL_CSV_THRESHOLD) {
        // Small CSV: Use parallel stream
        rows.parallelStream().forEach(r -> processRow(headers, r, rowProcessor));
      } else {
        // Large CSV: Use ExecutorService (better memory control)
        processCsvWithThreadPool(headers, rows, rowProcessor);
      }
    }
  }

  // ✅ Helper method to check if a row is empty
  private static boolean isEmptyRow(String[] row) {
    return row == null
        || Arrays.stream(row).allMatch(value -> value == null || value.trim().isEmpty());
  }

  // Helper: Process CSV using ThreadPool (for large CSVs)
  private static void processCsvWithThreadPool(
      String[] headers, List<String[]> rows, Consumer<Map<String, String>> rowProcessor) {
    ExecutorService executor = Executors.newFixedThreadPool(10);
    List<Future<?>> futures = new ArrayList<>();

    for (String[] row : rows) {
      futures.add(executor.submit(() -> processRow(headers, row, rowProcessor)));
    }

    // Ensure all tasks complete
    for (Future<?> future : futures) {
      try {
        future.get();
      } catch (Exception e) {
        throw new RuntimeException("Error processing CSV", e);
      }
    }

    executor.shutdown();
  }

  // Helper: Convert row to map and process it
  private static void processRow(
      String[] headers, String[] row, Consumer<Map<String, String>> rowProcessor) {

    Map<String, String> rowMap = new LinkedHashMap<>();
    for (int j = 0; j < headers.length; j++) {
      rowMap.put(headers[j], j < row.length ? row[j] : "");
    }

    rowProcessor.accept(rowMap);
  }

  public static <T> List<T> parseCsvToBeanChunked(MultipartFile file, Class<T> csvModelClass) {
    try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
      CsvToBean<T> csvToBean =
          new CsvToBeanBuilder<T>(reader)
              .withType(csvModelClass)
              .withIgnoreLeadingWhiteSpace(true)
              .build();

      return csvToBean.parse();
    } catch (IOException e) {
      throw CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception();
    }
  }
}
