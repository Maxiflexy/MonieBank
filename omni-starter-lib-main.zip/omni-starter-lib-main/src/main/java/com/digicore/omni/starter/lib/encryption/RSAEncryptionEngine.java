package com.digicore.omni.starter.lib.encryption;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import javax.crypto.Cipher;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Component;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 17 Thu Apr, 2025
 */
@Component
public class RSAEncryptionEngine implements EncryptionEngine {

  private static final String ALGORITHM = "RSA";

  @Override
  public String algorithmName() {
    return ALGORITHM;
  }

  public Pair<String, String> generateKey() throws Exception {
    KeyPairGenerator keyGen = KeyPairGenerator.getInstance(ALGORITHM);
    keyGen.initialize(2048);
    KeyPair pair = keyGen.generateKeyPair();

    return new ImmutablePair<>(
        Base64.getEncoder().encodeToString(pair.getPublic().getEncoded()),
        Base64.getEncoder().encodeToString(pair.getPrivate().getEncoded()));
  }

  public String encrypt(String data, String publicKeyStr) throws Exception {
    PublicKey publicKey = getPublicKeyFromString(publicKeyStr);
    Cipher cipher = Cipher.getInstance(ALGORITHM);
    cipher.init(Cipher.ENCRYPT_MODE, publicKey);
    byte[] encryptedBytes = cipher.doFinal(data.getBytes());
    return Base64.getEncoder().encodeToString(encryptedBytes);
  }

  public String decrypt(String data, String privateKeyStr) throws Exception {
    PrivateKey privateKey = getPrivateKeyFromString(privateKeyStr);
    Cipher cipher = Cipher.getInstance(ALGORITHM);
    cipher.init(Cipher.DECRYPT_MODE, privateKey);
    byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(data));
    return new String(decryptedBytes);
  }

  private static PublicKey getPublicKeyFromString(String key) throws Exception {
    byte[] byteKey = Base64.getDecoder().decode(key);
    X509EncodedKeySpec X509publicKey = new X509EncodedKeySpec(byteKey);
    KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
    return keyFactory.generatePublic(X509publicKey);
  }

  private static PrivateKey getPrivateKeyFromString(String key) throws Exception {
    byte[] byteKey = Base64.getDecoder().decode(key);
    PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(byteKey);
    KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
    return keyFactory.generatePrivate(keySpec);
  }
}
