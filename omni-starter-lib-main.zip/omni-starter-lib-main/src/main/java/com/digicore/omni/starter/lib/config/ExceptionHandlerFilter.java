package com.digicore.omni.starter.lib.config;

import com.digicore.omni.starter.lib.exception.RequestException;
import com.digicore.omni.starter.lib.helper.ClientHelper;
import com.digicore.omni.starter.lib.helper.RequestResponseEncryptionHelper;
import com.digicore.omni.starter.lib.model.response.ApiResponseJson;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 07 Tue Oct, 2025
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ExceptionHandlerFilter extends OncePerRequestFilter {

  private final GlobalAccessDeniedHandler globalAccessDeniedHandler;
  private final GlobalAuthenticationEntryPoint globalAuthenticationEntryPoint;
  private final RequestResponseEncryptionHelper requestResponseEncryptionHelper;

  @SneakyThrows
  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {

    try {
      filterChain.doFilter(request, response);
    } catch (AccessDeniedException e) {
      log.error(
          "AccessDeniedException caught: path={}, message={}",
          request.getRequestURI(),
          e.getMessage());
      globalAccessDeniedHandler.handle(request, response, e);

    } catch (AuthenticationException e) {
      log.error(
          "AuthenticationException caught: path={}, message={}",
          request.getRequestURI(),
          e.getMessage());
      globalAuthenticationEntryPoint.commence(request, response, e);

    } catch (RequestException e) {
      log.info(
          "RequestException: caught: path={}, message={}", request.getRequestURI(), e.getMessage());

      response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
      response.setContentType("application/json");
      response.setCharacterEncoding("UTF-8");

      ApiResponseJson body = new ApiResponseJson(e.getCode(), e.getMessage());
      String responseBody = ClientHelper.OBJECT_MAPPER.writeValueAsString(body);

      response
          .getWriter()
          .write(requestResponseEncryptionHelper.prepareEncryptedResponse(responseBody));
    } catch (Exception e) {
      log.info("Exception: caught: path={}, message={}", request.getRequestURI(), e.getMessage());

      response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
      response.setContentType("application/json");
      response.setCharacterEncoding("UTF-8");

      ApiResponseJson body = new ApiResponseJson(response.getStatus(), e.getMessage());
      String responseBody = ClientHelper.OBJECT_MAPPER.writeValueAsString(body);

      response
          .getWriter()
          .write(requestResponseEncryptionHelper.prepareEncryptedResponse(responseBody));
    }
  }
}
