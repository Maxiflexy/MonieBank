package com.digicore.omni.starter.lib.service;

import com.digicore.omni.starter.lib.constant.SystemConfigKeyConstant;
import com.digicore.omni.starter.lib.contract.ConfigInitializer;
import com.digicore.omni.starter.lib.encryption.HybridEncryptionService;
import com.digicore.omni.starter.lib.exception.CommonExceptionOf;
import com.digicore.omni.starter.lib.helper.ClientHelper;
import com.digicore.omni.starter.lib.model.dto.EncryptedPayloadDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Service;

/**
 * @author mosh
 * @role software engineer
 * @createdOn 18 Fri Apr, 2025
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ExposedEncryptionService {

  private final HybridEncryptionService hybridEncryptionService;
  private final ConfigInitializer configInitializer;

  public EncryptedPayloadDTO encrypt(String clearJsonText) {

    try {

      return hybridEncryptionService.encryptResponse(
          clearJsonText,
          configInitializer.configCache().get(SystemConfigKeyConstant.OMNI_ENCRYPTION_PUBLIC_KEY));
    } catch (Exception e) {
      throw CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exceptionWithPlaceholders(
          "Could not encrypt: {}", e.getMessage());
    }
  }

  public Object decrypt(EncryptedPayloadDTO encryptedRequest) {

    try {
      if (encryptedRequest != null && !StringUtils.isBlank(encryptedRequest.getBody())) {
        String body =
            hybridEncryptionService.decryptRequest(
                encryptedRequest,
                configInitializer
                    .configCache()
                    .get(SystemConfigKeyConstant.OMNI_ENCRYPTION_PRIVATE_KEY));
        return ClientHelper.OBJECT_MAPPER.readValue(body, Object.class);
      }

    } catch (Exception e) {
      log.info("Err: {}", e.getMessage());
      throw CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception(e.getMessage());
    }
    throw CommonExceptionOf.Business.BadRequest.BAD_REQUEST.exception();
  }

  public Pair<String, String> reconstructKeys(String exposedKey, String delimiter) {
    String[] parts = exposedKey.split(delimiter);

    if (parts.length != 4) {
      throw new IllegalArgumentException("Invalid exposed key format");
    }

    String reconstructedPublicKey = parts[3] + parts[0];
    String reconstructedPrivateKey = parts[2] + parts[1];

    return new ImmutablePair<>(reconstructedPublicKey, reconstructedPrivateKey);
  }

  public String stringifyJson(Object jsonObject) throws JsonProcessingException {
    return new ObjectMapper().writeValueAsString(jsonObject);
  }

  public Pair<String, String> encodeExposedKey() {
    String publicKey =
        configInitializer.configCache().get(SystemConfigKeyConstant.OMNI_ENCRYPTION_PUBLIC_KEY);
    String privateKey =
        configInitializer.configCache().get(SystemConfigKeyConstant.OMNI_ENCRYPTION_PRIVATE_KEY);
    if (50 >= publicKey.length() || 50 >= privateKey.length()) {
      throw new IllegalArgumentException("Invalid split index");
    }
    String pubStr1 = publicKey.substring(0, 50);
    String pubStr2 = publicKey.substring(50);
    String prStr1 = privateKey.substring(0, 50);
    String prStr2 = privateKey.substring(50);

    String delimiter =
        configInitializer.configCache().get(SystemConfigKeyConstant.OMNI_ENCRYPTION_DELIMITER);

    return new ImmutablePair<>(
        delimiter,
        pubStr2.concat(delimiter) + prStr2.concat(delimiter) + prStr1.concat(delimiter) + pubStr1);
  }
}
