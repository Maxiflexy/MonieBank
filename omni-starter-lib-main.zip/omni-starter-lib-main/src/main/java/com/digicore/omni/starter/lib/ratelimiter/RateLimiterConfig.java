package com.digicore.omni.starter.lib.ratelimiter;

import java.util.Map;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "omni")
@Getter
@Setter
public class RateLimiterConfig {
  private Map<String, RateLimiterConfigInstance> rateLimiters;

  public RateLimiterConfigInstance getRateLimiterConfig(String name) {
    if (rateLimiters == null || !rateLimiters.containsKey(name)) {
      return new RateLimiterConfigInstance();
    }

    return rateLimiters.get(name);
  }

  @Getter
  @Setter
  @NoArgsConstructor
  public static class RateLimiterConfigInstance {
    private Integer maxRequests = 2;
    private Integer timeWindow = 60;
    private Integer blackListThreshold = 5; // e.g. exceed 5 requests within window → blacklist
    private Integer blackListDuration = 900;
  }
}
